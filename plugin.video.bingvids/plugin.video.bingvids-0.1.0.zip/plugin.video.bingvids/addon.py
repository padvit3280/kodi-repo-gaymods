# -*- coding: utf-8 -*-
from kodiswift import Plugin, xbmc
from urllib import quote_plus as Quote, unquote_plus as Unquote
import webutil
import sys, os.path as path
import json
plugin = Plugin()
APIKEY=plugin.get_setting('apikey')
searchq = "( aula | escuela | biblioteca | publico ) AND ( novinho | chico | amigo | chavo | chavolito | hermano | cofrade ) AND paja"
cpath = path.join(xbmc.translatePath('special://userdata'), 'cookies.lwp')
dl = webutil.DemystifiedWebRequest(cookiePath=cpath)

@plugin.route('/')
def index():
    item = {
        'label': 'Bing Video Search!',
        'path': plugin.url_for(endpoint=query),
        'is_playable': False
    }
    litems = [item]
    return litems

@plugin.route('/search/<query>')
def search(query=''):
    litems = []
    query += ' -site:youtube.com -site:dailymotion.com'
    burl = 'https://api.cognitive.microsoft.com/bing/v7.0/videos/search?safeSearch=Off&subscription-key=a2bbbe20b19543b9ab6dee3bac81d3da&q={0}'.format(Quote(query))
    jresults = dl.getSource(url=burl)
    results = json.JSONDecoder(encoding='utf-8').decode(jresults)
    for v in results.get('value', []):
        img = v.get('thumbnailUrl', 'defaultvideo.png')
        lbl2 = v.get('description', v.get('hostPageUrl', v.get('contentUrl', '')))
        #playpath = plugin.url_for(endpoint=play, vurl=v.get('contentUrl', v.get('hostPageUrl', '')))
        playpath = "plugin://plugin.video.wsonline/play/" + Quote(v.get('contentUrl', v.get('hostPageUrl', '')))
        item = {'label': v.get('name', ''), 'label2': lbl2, 'thumbnail': img, 'icon': img, 'path': playpath, 'is_folder': 'false', 'is_playable': 'true'}
        litems.append(item)
    return litems

@plugin.route('/query')
def query():
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = plugin.keyboard(searchtxt, 'Bing Video Search', False)
    res = []
    if len(searchtxt) > 1:
        plugin.set_setting(key='lastsearch', val=searchtxt)
        res = search(searchtxt)
    return res

@plugin.route('/play/<vurl>')
def play(vurl=None):
    if vurl is None:
        return []
    if vurl.find("%20") != -1 or vurl.find("+") != -1:
        vurl = Unquote(vurl)
    plugin.notify(msg=vurl)

    return [vurl]


if __name__ == '__main__':
    plugin.run()

