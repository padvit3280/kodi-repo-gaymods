# -*- coding: utf-8 -*-
# https://docs.microsoft.com/en-us/rest/api/cognitiveservices/bing-web-api-v7-reference
from kodiswift import Plugin, xbmc
from urllib import quote_plus as Quote, unquote_plus as Unquote
import webutil
import sys, os, os.path as path
import json
plugin = Plugin()
APIKEY=plugin.get_setting('apikey')
searchq = '( publica OR biblioteca OR aula OR "en clase" OR escuela OR classroom ) AND ( masturba OR masturbandose OR masturbandose OR batendo OR paja OR pajero ) AND ( novinho OR chavito OR amigo OR chico OR chavo ) '
cpath = path.join(xbmc.translatePath('special://userdata'), 'cookies.lwp')
dl = webutil.DemystifiedWebRequest(cookiePath=cpath)
__addondir__ = xbmc.translatePath(plugin.addon.getAddonInfo('path'))
__resdir__ = os.path.join(__addondir__, 'resources')
__imgdir__ = os.path.join(__resdir__, 'images')
__imgsearch__ = os.path.join(__imgdir__, 'search.png')
__imgnext__ = os.path.join(__imgdir__, 'next.png')
__imgback__ = os.path.join(__imgdir__, 'back.png')
__imgtumblr__ = os.path.join(__imgdir__, 'tumblr.png')

@plugin.route('/')
def index():
    item = {
        'label': 'Bing Video Search!',
        'icon': __imgsearch__, 'thumbnail': __imgsearch__,
        'path': plugin.url_for(endpoint=query),
        'is_playable': False
    }
    litems = [item]
    return litems

@plugin.route('/search/<query>/<offset>')
def search(query='', offset=0):
    litems = []
    query += ' -site:youtube.com -site:dailymotion.com'
    burl = 'https://api.cognitive.microsoft.com/bing/v7.0/videos/search?count=50&offset={0}&safeSearch=Off&subscription-key=a2bbbe20b19543b9ab6dee3bac81d3da&q={1}'.format(offset, Quote(query))
    jresults = dl.getSource(url=burl)
    results = json.JSONDecoder(encoding='utf-8').decode(jresults)
    nextoff = results.get('nextOffset', 0)
    totalresults = results.get('totalEstimatedMatches', 0)
    for v in results.get('value', []):
        img = v.get('thumbnailUrl', 'defaultvideo.png')
        lbl2 = v.get('description', v.get('hostPageUrl', v.get('contentUrl', '')))
        #playpath = plugin.url_for(endpoint=play, vurl=v.get('contentUrl', v.get('hostPageUrl', '')))
        playpath = "plugin://plugin.video.wsonline/play/" + Quote(v.get('contentUrl', v.get('hostPageUrl', '')))
        item = {'label': v.get('name', ''), 'label2': lbl2, 'thumbnail': img, 'icon': img, 'path': playpath, 'is_folder': 'false', 'is_playable': 'true'}
        litems.append(item)
    nextlbl = "Next -> {0}-{1} of {2}".format(nextoff, str(nextoff+50), totalresults)
    squery = query.replace(' -site:youtube.com -site:dailymotion.com', '')
    nextitem = {'label': nextlbl, 'icon': __imgnext__, 'thumbnail': __imgnext__, 'path': plugin.url_for(endpoint=search, query=squery, offset=nextoff)}
    litems.append(nextitem)
    return litems

@plugin.route('/query')
def query():
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = plugin.keyboard(searchtxt, 'Bing Video Search', False)
    res = []
    if len(searchtxt) > 1:
        plugin.set_setting(key='lastsearch', val=searchtxt)
        res = search(searchtxt, 0)
    return res

@plugin.route('/play/<vurl>')
def play(vurl=None):
    if vurl is None:
        return []
    if vurl.find("%20") != -1 or vurl.find("+") != -1:
        vurl = Unquote(vurl)
    plugin.notify(msg=vurl)

    return [vurl]


if __name__ == '__main__':
    plugin.run()
    plugin.set_content(content='movies')
    viewmode = 500
    viewmode = int(plugin.get_setting('viewmode'))
    plugin.set_view_mode(viewmode)
