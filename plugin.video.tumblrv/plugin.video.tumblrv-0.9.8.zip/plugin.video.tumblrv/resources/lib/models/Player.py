#!/usr/bin/python

class Player:
	def __init__(self, embed_code, __type__, __name__, width, __class__):
		self.embed_code = embed_code
		self.__type__ = __type__
		self.__name__ = __name__
		self.width = width
		self.__class__ = __class__

