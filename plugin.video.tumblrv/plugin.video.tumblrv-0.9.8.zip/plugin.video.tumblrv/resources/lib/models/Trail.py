#!/usr/bin/python

class Trail:
	def __init__(self, content_raw, post, blog, content):
		self.content_raw = content_raw
		self.post = post
		self.blog = blog
		self.content = content

