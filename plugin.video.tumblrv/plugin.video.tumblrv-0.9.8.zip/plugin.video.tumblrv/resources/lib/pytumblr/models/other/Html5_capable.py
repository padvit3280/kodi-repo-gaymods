#!/usr/bin/python

class Html5_capable:
	def __init__(self, type):
		self.type = type

