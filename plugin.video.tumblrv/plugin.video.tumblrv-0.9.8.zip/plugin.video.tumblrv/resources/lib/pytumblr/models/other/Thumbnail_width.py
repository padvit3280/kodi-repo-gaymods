#!/usr/bin/python

class Thumbnail_width:
	def __init__(self, type):
		self.type = type

