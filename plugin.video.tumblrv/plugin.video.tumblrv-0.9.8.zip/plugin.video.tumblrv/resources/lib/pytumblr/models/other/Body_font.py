#!/usr/bin/python

class Body_font:
	def __init__(self, type):
		self.type = type

