#!/usr/bin/python

class Updated:
	def __init__(self, type):
		self.type = type

