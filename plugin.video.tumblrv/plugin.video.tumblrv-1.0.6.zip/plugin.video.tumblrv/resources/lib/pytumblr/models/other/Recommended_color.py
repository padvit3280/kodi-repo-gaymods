#!/usr/bin/python

class Recommended_color:
	def __init__(self, type):
		self.type = type

