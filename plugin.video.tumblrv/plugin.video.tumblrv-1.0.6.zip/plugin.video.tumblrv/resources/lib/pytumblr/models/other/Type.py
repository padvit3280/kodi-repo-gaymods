#!/usr/bin/python

class Type:
	def __init__(self, type):
		self.type = type

