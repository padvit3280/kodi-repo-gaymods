#!/usr/bin/python

class Recommended_source:
	def __init__(self, type):
		self.type = type

