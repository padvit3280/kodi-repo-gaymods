#!/usr/bin/python

class Tree_html:
	def __init__(self, type):
		self.type = type

