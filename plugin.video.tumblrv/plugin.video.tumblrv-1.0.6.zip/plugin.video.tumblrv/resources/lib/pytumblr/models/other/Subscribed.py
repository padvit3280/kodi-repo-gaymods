#!/usr/bin/python

class Subscribed:
	def __init__(self, type):
		self.type = type

