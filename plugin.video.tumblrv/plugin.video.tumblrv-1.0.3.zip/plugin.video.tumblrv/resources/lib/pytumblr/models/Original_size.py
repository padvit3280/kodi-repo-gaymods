#!/usr/bin/python

class Original_size(object):
	def __init__(self, width, url, height):
		self.width = width
		self.url = url
		self.height = height

