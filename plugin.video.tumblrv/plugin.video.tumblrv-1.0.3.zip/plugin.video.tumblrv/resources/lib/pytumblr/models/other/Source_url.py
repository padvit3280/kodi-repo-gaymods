#!/usr/bin/python

class Source_url:
	def __init__(self, type):
		self.type = type

