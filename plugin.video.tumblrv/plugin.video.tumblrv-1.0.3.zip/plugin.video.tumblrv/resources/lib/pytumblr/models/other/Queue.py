#!/usr/bin/python

class Queue:
	def __init__(self, type):
		self.type = type

