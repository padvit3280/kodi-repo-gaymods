#!/usr/bin/python

class Is_nsfw:
	def __init__(self, type):
		self.type = type

