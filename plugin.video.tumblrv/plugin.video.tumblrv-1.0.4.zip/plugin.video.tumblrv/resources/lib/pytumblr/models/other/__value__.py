#!/usr/bin/python

class __value__:
	def __init__(self, type, items):
		self.type = type
		self.items = items

