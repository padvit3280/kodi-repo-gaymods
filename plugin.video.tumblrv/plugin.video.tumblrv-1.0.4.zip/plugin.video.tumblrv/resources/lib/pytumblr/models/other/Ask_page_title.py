#!/usr/bin/python

class Ask_page_title:
	def __init__(self, type):
		self.type = type

