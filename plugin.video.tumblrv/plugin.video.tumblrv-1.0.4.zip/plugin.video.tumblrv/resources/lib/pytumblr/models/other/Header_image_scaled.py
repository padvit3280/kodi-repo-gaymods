#!/usr/bin/python

class Header_image_scaled:
	def __init__(self, type):
		self.type = type

