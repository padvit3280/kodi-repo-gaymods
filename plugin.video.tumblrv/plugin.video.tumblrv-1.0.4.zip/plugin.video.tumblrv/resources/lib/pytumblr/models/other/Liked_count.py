#!/usr/bin/python

class Liked_count:
	def __init__(self, type):
		self.type = type

