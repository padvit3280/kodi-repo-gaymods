#!/usr/bin/python

class Blog:
	def __init__(self, type, properties):
		self.type = type
		self.properties = properties

