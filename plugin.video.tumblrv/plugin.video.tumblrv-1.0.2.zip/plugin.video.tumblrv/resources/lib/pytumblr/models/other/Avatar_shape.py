#!/usr/bin/python

class Avatar_shape:
	def __init__(self, type):
		self.type = type

