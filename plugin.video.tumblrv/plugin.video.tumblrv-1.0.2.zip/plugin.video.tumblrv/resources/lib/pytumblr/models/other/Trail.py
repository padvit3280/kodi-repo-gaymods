#!/usr/bin/python

class Trail:
	def __init__(self, type, properties):
		self.type = type
		self.properties = properties

