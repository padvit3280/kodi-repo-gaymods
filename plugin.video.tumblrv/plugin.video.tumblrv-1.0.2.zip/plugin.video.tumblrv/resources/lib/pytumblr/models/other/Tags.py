#!/usr/bin/python

class Tags:
	def __init__(self, type, items):
		self.type = type
		self.items = items

