#!/usr/bin/python

class __class__:
	def __init__(self, type):
		self.type = type

