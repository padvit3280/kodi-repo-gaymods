#!/usr/bin/python

class Can_send_fan_mail:
	def __init__(self, type):
		self.type = type

