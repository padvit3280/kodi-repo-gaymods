#!/usr/bin/python

class Summary:
	def __init__(self, type):
		self.type = type

