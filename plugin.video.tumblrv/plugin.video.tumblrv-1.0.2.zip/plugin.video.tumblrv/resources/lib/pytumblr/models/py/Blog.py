#!/usr/bin/python

class Blog:
	def __init__(self, share_likes, name, can_be_followed, active, theme, share_following):
		self.share_likes = share_likes
		self.name = name
		self.can_be_followed = can_be_followed
		self.active = active
		self.theme = theme
		self.share_following = share_following

