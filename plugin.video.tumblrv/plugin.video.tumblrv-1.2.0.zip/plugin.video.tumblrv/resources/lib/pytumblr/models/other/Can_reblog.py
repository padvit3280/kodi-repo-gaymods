#!/usr/bin/python

class Can_reblog:
	def __init__(self, type):
		self.type = type

