#!/usr/bin/python

class Timestamp:
	def __init__(self, type):
		self.type = type

