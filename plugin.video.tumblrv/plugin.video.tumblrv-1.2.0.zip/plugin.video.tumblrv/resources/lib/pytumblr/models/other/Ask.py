#!/usr/bin/python

class Ask:
	def __init__(self, type):
		self.type = type

