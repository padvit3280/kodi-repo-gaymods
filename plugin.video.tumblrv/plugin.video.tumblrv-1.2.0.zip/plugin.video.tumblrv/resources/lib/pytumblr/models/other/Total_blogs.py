#!/usr/bin/python

class Total_blogs:
	def __init__(self, type):
		self.type = type

