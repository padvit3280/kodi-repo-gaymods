## plugin.video.tumblrV
### Kodi/XBMC Addon for Video's on Tumblr
This is an in development addon to watch and download video's from tumblr blogs.
### GayMods Repo for Kodi/XBMC Gay Adult Addons
**https://github.com/moedje/kodi-repo-gaymods**

### OAUTH Help DEVELOPERS I NEED HELP
This works for my account as a geek as I know how to register the app and go to website and put in the keys. Have I done this right and is there a better way? I would love to find a way to do this from inside Kodi if anyone knows how I could implement this please help!!

### REQUIRED TO WORK: OAuth from Tumblr
You need to authorize the app with Tumblr to your account so we can retrieve your following, liked, dashboard, etc. I do not have an easy way to do this in Kodi yet and I am working on this. For now you have to do this with a browser that you are logged into tumblr simply visit:

#### https://api.tumblr.com/console/calls/user/info
- Consumer Key:
**5wEwFCF0rbiHXYZQQeQnNetuwZMmIyrUxIePLqUMcZlheVXwc4**
- Consumer Secret:
**GCLMI2LnMZqO2b5QheRvUSYY51Ujk7nWG2sYroqozW06x4hWch**

Tumblr will give you back an **OAUTH_TOKEN and OAUTH_SECRET** you need to put this into the addon's settings and then it will work. If anyone knows how to make this work easier from within Kodi that would be most helpful!!
### Features and Status 
*updated June 2017*

- [x] OAuth2 login to Tumblr: Give URL to enter displayed CONSUMER KEY and SECRET to generate OAUTH Token and Secret
- [ ] OAuth2 Can we make this easier to get OAUTH Token and Secret? Within Kodi and not browser?
- [x] Dashboard Video's
- [x] List of Following Blogs
- [x] List of Video's from a blog
- [x] List More/Older Video's from a blog
- [x] Collect TAGS from any video's as you use addon
- [x] List all collected tags and display video's with this tag
- [x] Display Liked Videos
- [x] Ability to Like/save a video
- [x] Download A Video
- [ ] Download All Liked/Dash/Category Videos
- [ ] Download based on dates
- [ ] Search Tumblr / Search a Blog / Other types of searches?
- [ ] Handle Picture Posts?

## ABOUT ME
- Author: Jeremy j@alljer.com
- http://www.2my.cc/ 
- Founder: [CryptoCoins.Com] Physical CryptoCurrency Worth Holding Onto