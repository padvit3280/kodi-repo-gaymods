#!/usr/bin/python

class Twitter_enabled:
	def __init__(self, type):
		self.type = type

