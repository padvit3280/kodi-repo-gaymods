#!/usr/bin/python

class Title_font_weight:
	def __init__(self, type):
		self.type = type

