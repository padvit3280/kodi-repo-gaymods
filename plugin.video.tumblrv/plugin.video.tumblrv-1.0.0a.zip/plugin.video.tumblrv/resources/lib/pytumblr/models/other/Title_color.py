#!/usr/bin/python

class Title_color:
	def __init__(self, type):
		self.type = type

