#!/usr/bin/python

class Video:
	def __init__(self, type):
		self.type = type

