#!/usr/bin/python

class Show_description:
	def __init__(self, type):
		self.type = type

