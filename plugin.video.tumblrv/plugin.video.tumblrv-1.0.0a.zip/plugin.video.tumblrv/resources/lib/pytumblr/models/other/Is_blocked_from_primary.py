#!/usr/bin/python

class Is_blocked_from_primary:
	def __init__(self, type):
		self.type = type

