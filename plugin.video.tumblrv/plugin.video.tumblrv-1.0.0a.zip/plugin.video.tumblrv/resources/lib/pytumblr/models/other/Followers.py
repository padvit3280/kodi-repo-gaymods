#!/usr/bin/python

class Followers:
	def __init__(self, type):
		self.type = type

