#!/usr/bin/python

class Tumblr-schema:
	def __init__(self, $schema, type, properties):
		self.$schema = $schema
		self.type = type
		self.properties = properties

	def load(self):
		#TODO: Needs to be implemented.

