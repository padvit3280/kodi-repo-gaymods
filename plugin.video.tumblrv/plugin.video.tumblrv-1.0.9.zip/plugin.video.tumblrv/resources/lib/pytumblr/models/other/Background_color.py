#!/usr/bin/python

class Background_color:
	def __init__(self, type):
		self.type = type

