#!/usr/bin/python

class Show_title:
	def __init__(self, type):
		self.type = type

