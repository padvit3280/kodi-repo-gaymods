#!/usr/bin/python

class Header_stretch:
	def __init__(self, type):
		self.type = type

