#!/usr/bin/python

class Thumbnail_height:
	def __init__(self, type):
		self.type = type

