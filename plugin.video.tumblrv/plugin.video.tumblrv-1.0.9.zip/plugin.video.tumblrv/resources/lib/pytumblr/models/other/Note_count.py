#!/usr/bin/python

class Note_count:
	def __init__(self, type):
		self.type = type

