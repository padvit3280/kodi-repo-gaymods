#!/usr/bin/python

class Reblog:
	def __init__(self, comment, tree_html):
		self.comment = comment
		self.tree_html = tree_html

