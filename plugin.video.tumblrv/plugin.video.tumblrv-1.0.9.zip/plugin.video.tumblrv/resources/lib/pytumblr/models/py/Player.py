#!/usr/bin/python

class Player:
	def __init__(self, embed_code, width):
		self.embed_code = embed_code
		self.width = width

