#!/usr/bin/python

class Properties:
	def __init__(self, tumblr):
		self.tumblr = tumblr

