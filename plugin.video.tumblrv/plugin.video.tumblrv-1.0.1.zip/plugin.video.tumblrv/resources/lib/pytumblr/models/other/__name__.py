#!/usr/bin/python

class __name__:
	def __init__(self, type):
		self.type = type

