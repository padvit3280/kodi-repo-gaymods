#!/usr/bin/python

class Posts:
	def __init__(self, type):
		self.type = type

