#!/usr/bin/python

class Liked:
	def __init__(self, type):
		self.type = type

