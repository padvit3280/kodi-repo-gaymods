#!/usr/bin/python

class Header_focus_width:
	def __init__(self, type):
		self.type = type

