#!/usr/bin/python

class Url:
	def __init__(self, type):
		self.type = type

