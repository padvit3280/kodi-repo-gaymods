#!/usr/bin/python

class Audio:
	def __init__(self, type):
		self.type = type

