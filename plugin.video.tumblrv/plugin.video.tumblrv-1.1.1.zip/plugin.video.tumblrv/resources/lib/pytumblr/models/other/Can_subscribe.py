#!/usr/bin/python

class Can_subscribe:
	def __init__(self, type):
		self.type = type

