#!/usr/bin/python

class Primary:
	def __init__(self, type):
		self.type = type

