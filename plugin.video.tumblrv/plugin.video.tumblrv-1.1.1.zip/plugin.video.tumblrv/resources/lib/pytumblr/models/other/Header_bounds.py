#!/usr/bin/python

class Header_bounds:
	def __init__(self, type):
		self.type = type

