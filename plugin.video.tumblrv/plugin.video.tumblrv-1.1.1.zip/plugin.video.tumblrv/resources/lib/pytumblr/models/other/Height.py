#!/usr/bin/python

class Height:
	def __init__(self, type):
		self.type = type

