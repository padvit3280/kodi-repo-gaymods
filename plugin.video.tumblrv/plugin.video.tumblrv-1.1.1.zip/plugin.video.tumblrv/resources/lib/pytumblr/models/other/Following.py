#!/usr/bin/python

class Following:
	def __init__(self, type):
		self.type = type

