#!/usr/bin/python

class Image_permalink:
	def __init__(self, type):
		self.type = type

