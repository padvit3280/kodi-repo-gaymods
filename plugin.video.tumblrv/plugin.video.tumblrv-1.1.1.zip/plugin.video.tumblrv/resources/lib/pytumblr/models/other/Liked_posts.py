#!/usr/bin/python

class Liked_posts:
	def __init__(self, type, items):
		self.type = type
		self.items = items

