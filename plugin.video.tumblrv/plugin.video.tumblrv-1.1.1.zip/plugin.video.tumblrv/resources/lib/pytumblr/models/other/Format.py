#!/usr/bin/python

class Format:
	def __init__(self, type):
		self.type = type

