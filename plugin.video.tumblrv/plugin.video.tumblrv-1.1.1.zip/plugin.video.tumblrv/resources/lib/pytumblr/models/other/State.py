#!/usr/bin/python

class State:
	def __init__(self, type):
		self.type = type

