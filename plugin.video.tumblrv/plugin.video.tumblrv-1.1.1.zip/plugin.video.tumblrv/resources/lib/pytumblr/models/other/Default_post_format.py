#!/usr/bin/python

class Default_post_format:
	def __init__(self, type):
		self.type = type

