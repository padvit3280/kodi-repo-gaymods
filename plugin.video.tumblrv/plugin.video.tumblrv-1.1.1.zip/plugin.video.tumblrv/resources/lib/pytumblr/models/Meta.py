#!/usr/bin/python

class Meta(object):
	def __init__(self, msg, status):
		self.msg = msg
		self.status = status

