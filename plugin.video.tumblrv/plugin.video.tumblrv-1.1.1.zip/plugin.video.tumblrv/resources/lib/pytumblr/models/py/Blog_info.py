#!/usr/bin/python

class Blog_info:
	def __init__(self, meta, response):
		self.meta = meta
		self.response = response

	def load(self):
		#TODO: Needs to be implemented.

