#!/usr/bin/python

class Blogs:
	def __init__(self, type, items):
		self.type = type
		self.items = items

