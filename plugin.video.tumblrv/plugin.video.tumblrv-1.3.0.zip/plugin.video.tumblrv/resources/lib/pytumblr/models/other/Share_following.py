#!/usr/bin/python

class Share_following:
	def __init__(self, type):
		self.type = type

