#!/usr/bin/python

class Comment:
	def __init__(self, type):
		self.type = type

