#!/usr/bin/python

class Header_image_focused:
	def __init__(self, type):
		self.type = type

