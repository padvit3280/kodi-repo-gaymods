#!/usr/bin/python

class Followed:
	def __init__(self, type):
		self.type = type

