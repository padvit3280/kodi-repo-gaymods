#!/usr/bin/python

class Title:
	def __init__(self, type):
		self.type = type

