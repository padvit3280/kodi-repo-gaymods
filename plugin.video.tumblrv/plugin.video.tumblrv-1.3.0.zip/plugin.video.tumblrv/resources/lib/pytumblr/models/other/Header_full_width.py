#!/usr/bin/python

class Header_full_width:
	def __init__(self, type):
		self.type = type

