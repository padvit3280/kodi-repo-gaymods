#!/usr/bin/python

class Source_title:
	def __init__(self, type):
		self.type = type

