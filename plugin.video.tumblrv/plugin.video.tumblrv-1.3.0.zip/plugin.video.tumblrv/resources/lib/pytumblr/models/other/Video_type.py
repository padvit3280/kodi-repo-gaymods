#!/usr/bin/python

class Video_type:
	def __init__(self, type):
		self.type = type

