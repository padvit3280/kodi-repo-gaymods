#!/usr/bin/python

class Tumblr:
	def __init__(self, type, properties):
		self.type = type
		self.properties = properties

