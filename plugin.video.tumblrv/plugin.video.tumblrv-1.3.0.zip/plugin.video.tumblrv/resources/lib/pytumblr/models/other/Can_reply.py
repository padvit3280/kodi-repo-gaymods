#!/usr/bin/python

class Can_reply:
	def __init__(self, type):
		self.type = type

