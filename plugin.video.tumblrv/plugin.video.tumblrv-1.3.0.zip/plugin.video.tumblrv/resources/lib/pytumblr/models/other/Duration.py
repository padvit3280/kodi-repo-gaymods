#!/usr/bin/python

class Duration:
	def __init__(self, type):
		self.type = type

