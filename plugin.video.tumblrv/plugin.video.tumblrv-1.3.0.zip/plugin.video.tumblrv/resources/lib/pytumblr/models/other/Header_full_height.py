#!/usr/bin/python

class Header_full_height:
	def __init__(self, type):
		self.type = type

