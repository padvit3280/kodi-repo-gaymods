#!/usr/bin/python

class Content:
	def __init__(self, type):
		self.type = type

