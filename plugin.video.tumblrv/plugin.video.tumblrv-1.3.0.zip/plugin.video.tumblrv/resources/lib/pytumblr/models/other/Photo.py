#!/usr/bin/python

class Photo:
	def __init__(self, type):
		self.type = type

