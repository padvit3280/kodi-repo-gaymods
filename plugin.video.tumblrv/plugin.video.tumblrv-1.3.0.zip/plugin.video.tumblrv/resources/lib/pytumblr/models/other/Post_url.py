#!/usr/bin/python

class Post_url:
	def __init__(self, type):
		self.type = type

