#!/usr/bin/python

class Embed_code:
	def __init__(self, type):
		self.type = type

