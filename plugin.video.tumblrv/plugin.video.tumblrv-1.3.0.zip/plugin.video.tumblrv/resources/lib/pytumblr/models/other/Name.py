#!/usr/bin/python

class Name:
	def __init__(self, type):
		self.type = type

