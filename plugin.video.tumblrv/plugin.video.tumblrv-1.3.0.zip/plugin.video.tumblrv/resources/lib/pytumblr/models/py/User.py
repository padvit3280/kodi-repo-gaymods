#!/usr/bin/python

class User:
	def __init__(self, following, name, updated, url):
		self.following = following
		self.name = name
		self.updated = updated
		self.url = url

