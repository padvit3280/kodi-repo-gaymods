#!/usr/bin/python

class Is_adult:
	def __init__(self, type):
		self.type = type

