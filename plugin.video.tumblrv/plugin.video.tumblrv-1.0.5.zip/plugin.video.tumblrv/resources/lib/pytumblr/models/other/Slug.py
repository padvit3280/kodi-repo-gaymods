#!/usr/bin/python

class Slug:
	def __init__(self, type):
		self.type = type

