from . import tv4u, simpleplugin, urlquick
#Plugin = simpleplugin.Plugin
