from . import tv4u, simpleplugin, webutil, gifmaker
try:
    from . import urlquick, htmlelement
    Get = urlquick.get
except:
    Get = None
Plugin = simpleplugin.Plugin