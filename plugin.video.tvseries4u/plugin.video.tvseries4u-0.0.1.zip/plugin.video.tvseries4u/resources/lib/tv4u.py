from webutil import *
import os.path as Path
import re
import simpleplugin

class Tv4u:

    def __init__(self, path='.', plugin=None):
        self.plug = simpleplugin.Plugin
        if plugin is not None:
            self.plug = plugin
        try:
            assert isinstance(self.plug, simpleplugin.Plugin)
        except:
            from xbmcaddon import Addon
            __addon__ = Addon()
            self.plug = simpleplugin.Plugin(__addon__.getAddonInfo('id'))
            assert isinstance(self.plug, simpleplugin.Plugin)
        self.BASEURL = "http://tvseries4u.com"
        self.URL_latest = "/last-350-posts/"
        self.URL_search = "/?s={0}"
        self.URL_category = "/category/{0}"
        self.PATH = Path.realpath(path)
        self.COOKIES = Path.join(self.PATH, 'cookies.dat')
        self.getWeb = DemystifiedWebRequest(cookiePath=self.COOKIES)

    def DL(self, url):
        html = u''
        try:
            html = to_unicode(
                self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False,
                                      ignoreCache=False, demystify=True).encode('latin-1', errors='ignore'))
        except:
            try:
                html = wsgi_decoding_dance(
                    self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False))
            except:
                html = wsgi_encoding_dance(
                    self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False))
        try:
            if html is None or len(html) < 1:
                html = try_coerce_native(self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False,
                                                          mobile=False))  # .encode('latin', errors='ignore')
        except:
            return self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False).encode(
                'latin-1', errors='ignore')
        return html

    def get_sources(self, url_episode=""):
        litems = []
        catitem = None
        if url_episode is not None and len(url_episode) > 0:
            if url_episode[0] != '/':
                url = self.BASEURL + '/' + url_episode
            else:
                url = self.BASEURL + url_episode
        else:
            return None
        src = self.DL(url)
        category = re.split('v:Breadcrumb">.*?href="http://tvseries4u.com/', src)
        if len(category) > 2:
            category = category[-1].split('</a>', 1)[0]
            showname = category.partition('>')[-1].split('<',1)[0]
            caturl = category.split('"', 1)[0]
            path = self.plug.get_url(action='list_category', name=showname, category=caturl)
            catitem = {'name': "CATEGORY: [B]{0}[/B]".format(showname), 'path': path, 'url': caturl}
        else:
            category = None
        html = src.split('class="filmicerik linkcontent"', 1)[-1]
        shtml = html.split('</div>',1)[0]
        reSources = re.compile('href="(.+?)"')
        matches = reSources.findall(shtml)
        if matches is not None and len(matches) > 0:
            for vidurl in matches:
                sourcename = vidurl #.partition('//')[-1].split('/', 1)[0]
                #sourcename = sourcename.replace('www.', '')
                #sourcename = sourcename.title()
                item = {'video': vidurl, 'path': self.plug.get_url(action="play", url=vidurl), 'name': sourcename, 'url': vidurl}
                litems.append(item)
        if catitem is not None:
            litems.append(catitem)
        return litems

    def get_catepisodes(self, url_category=""):
        litems = []
        src = self.DL(url_category)
        html = src.split('class="wt-cat"', 1)[-1]
        matches = re.compile('href="(.+?)">(.+?)</a>').findall(html)
        if matches is not None and len(matches) > 0:
            for eplink, epname in matches:
                path = self.plug.get_url(action='get_sources', name=epname, video=eplink, url=eplink)
        return litems

    def get_latest(self):
        litems = []
        url = self.BASEURL + self.URL_latest
        src = self.DL(url)
        html = src.split('class="lcp_catlist" id="lcp_instance_0">', 1)[-1]
        reLatest = re.compile('<li.+?<a href="(http://tvseries4u.com/.+?)" title="(.+?)".+?</li>', re.DOTALL)
        matches = reLatest.findall(html)
        showthumb = 'DefaultVideo.png'
        if matches is not None and len(matches) > 0:
            for showlink, showname in matches:
                showpath = self.plug.get_url(action='get_sources', name=showname, url=showlink)
                item = {'name': showname, 'url': showlink, 'path': showpath}
                litems.append(item)
        return litems
