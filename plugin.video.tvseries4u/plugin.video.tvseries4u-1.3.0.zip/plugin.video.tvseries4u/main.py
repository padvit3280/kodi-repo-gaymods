# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Github: https://github.com/moedje/
# Updated on: June 23, 2019
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import ssl, re, datetime, time
import sys, os
import base64
try:
    import xbmc, xbmcplugin
except:
    import Kodistubs.xbmc as xbmc
    import Kodistubs.xbmcplugin as xbmcplugin
try:
     # Python 2.6-2.7
     from HTMLParser import HTMLParser
except ImportError:
     # Python 3
     from html.parser import HTMLParser
h = HTMLParser()
from resources import lib as Lib
try:
    import urllib, urllib2
except:
    import urllib3.util as urllib2
path = os.path
ssl._create_default_https_context = ssl._create_unverified_context
Get = Lib.urlquick.get
quote = Lib.urlquick.quote
unquote = Lib.urlquick.unquote
def quote_plus(text): return quote(text.replace(' ', '+'))

plugin = Lib.simpleplugin.Plugin()

__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
__next__ = path.join(xbmc.translatePath('special://home/addons/plugin.video.tvseries4u/resources/'), 'next.png')
Tv = Lib.tv4u.Tv4u(cookiepath=__cookie__)

@plugin.action()
@plugin.mem_cached(10)
def root():
    imgWs = __next__.replace('next', 'watchseries')
    lblTpl = '[COLOR green]{0}[/COLOR] ([COLOR white][I]{1}[/I][/COLOR])\n[COLOR yellow]{2}[/COLOR]'
    lblWs = lblTpl.format("Watch Series", "Latest", "")
    lblWsAll = lblTpl.format("Watch Series", "Full List", "")
    rootmenu = {
        "Home": [
            {'label': lblWs, 'url': plugin.get_url(action='home_ws'), 'thumb': imgWs,
             'is_folder': True, 'is_playable': False},
            {'label': lblWsAll, 'url': plugin.get_url(action='latest_ws', page=1), 'thumb': imgWs,
             'is_folder': True, 'is_playable': False},
            {'label': 'Search', 'url': plugin.get_url(action='show_searchbox', site='ws'), 'thumb': __next__.replace('next', 'search'),
             'is_folder': True, 'is_playable': False}
        ]
    }
    return rootmenu["Home"]


@plugin.action()
@plugin.mem_cached(10)
def home_ws():
    items = []
    xitems = []
    urlrss = 'https://watchseries.ovh/rss/newest-episodes'
    resp = Lib.urlquick.get(urlrss)
    for item in resp.xml().iter('item'):
        xitems.append(item)
    for item in xitems:
        litem = {'is_folder': True, 'is_playable': False}
        for kid in item.getchildren():
            if kid.tag == 'link':
                litem.update({'url': plugin.get_url(action='sources_ws', vurl=kid.text)}) #{'url': plugin.get_url(action=sources_ws, url=kid.text)})
            elif kid.tag == 'title':
                name = kid.text.encode('latin', 'ignore')
                epname, epdetails = name.split(',',1)
                litem.update({'label': "[COLOR white][B]{0}[/B][/COLOR] [I]{1}[/I]".format(epname.strip(), epdetails.strip())})
            elif kid.tag == 'description':
                img = kid.text.rpartition('src="')[-1].split('"')[0]
                lbl2 = kid.text.rpartition('/>')[-1].strip()
                litem.update({'thumb': img, 'icon': img, 'label2': lbl2})
        items.append(litem)
    return items


@plugin.action()
#@plugin.mem_cached(10)
def latest_ws(params):
    items = []
    page = 1
    if params.page is not None:
        page = params.page
    url_base = 'https://watchseries.ovh/latest/'
    nextpage = int(page) + 10
    nextlbl = 'Next -> {0}'.format(nextpage.__str__())
    nextitem = {'label': nextlbl, 'url': plugin.get_url(action='latest_ws', page=nextpage), 'thumb': __next__,
             'icon': __next__, 'is_folder': True, 'is_playable': False}
    for p in range(1, 10):
        url = url_base + p.__str__()
        items.extend(get_episodelists(url))
    items.append(nextitem)
    return items


def get_episodelists(url):
    epname = ""
    epseason = ""
    resp = Lib.urlquick.get(url)
    src = resp.content
    html = src.rpartition('<ul class="listings">')[-1].split('<ul class="pagination">')[0]
    litems = []
    results = re.compile('<li.+?href="(.+?)" title="(.+?)".+?epnum">(.+?)</span>').findall(html)
    for link,title,date in results:
        sepchar = '-'
        if title.find('-') == -1:
            sepchar = ','
        epname, epseason = title.split(sepchar,1)
        lbl = "[COLOR white][B]{0}[/B][/COLOR] [COLOR grey]{1}[/COLOR] [COLOR yellow]{2}[/COLOR]".format(epname.strip(), epseason.strip(), date)
        item = {'label': title, 'label2': date,'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action='sources_ws', vurl=link)}
        litems.append(item)
    return litems


def get_seriesepisodelists(url):
    epname = ""
    epseason = ""
    resp = Lib.urlquick.get(url)
    src = resp.content
    html = src.rpartition('<ul class="listings')[-1].split('<ul class="pagination">')[0]
    litems = []
    results = re.findall(r'href="(.+?)".+?"name" >(.+?)</.+?"datepublished">(.+?)</', string=html, flags=re.MULTILINE)
    for link,title,date in results:
        try:
            char = u'&nbsp;'
            epname = title.replace(char, ' ')
            lbl = "[COLOR white][B]{0}[/B][/COLOR] [COLOR yellow]{1}[/COLOR]".format(epname.strip(), date)
            item = {'label': epname, 'label2': date,'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action='sources_ws', vurl=link)}
            litems.append(item)
        except:
            try:
                p1,p2 = title.split(' ', 1)
                epname = p1 + ' ' + p2[0]
            except:
                epname = url.rpartition('/')[-1].replace('_', ' ').title()
            lbl = "[COLOR white][B]{0}[/B][/COLOR] [COLOR yellow]{1}[/COLOR]".format(epname.strip(), date)
            item = {'label': epname, 'label2': date,'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action='sources_ws', vurl=link)}
            litems.append(item)
    return litems


@plugin.action()
#@plugin.mem_cached(10)
def sources_ws(params):
    items = []
    vurl = "https://watchseries.ovh/episode/"
    epurl = ""
    if params.vurl is not None:
        epurl = params.vurl
    items = get_sourceslist(epurl)
    return items


def get_sourceslist(url):
    litems = []
    name = ""
    link = ""
    img = "https://static.swatchseries.to/templates/default/images/favicons/{0}.png)"
    name = url.rpartition('/')[-1]
    epfullname = name.replace('_', ' ').split('.htm', 1)[0].title()
    showname = re.split(" S\d+ E\d+", epfullname, 1)[0]
    epnum = epfullname.replace(showname, '').strip()
    noepnum = False
    m = re.findall("S\d+ E\d+", epnum)
    if len(epnum) < 2 or len(m) < 1:
        epnum = ''
        showname = epfullname
    resp = Lib.urlquick.get(url)
    src = resp.content
    html = src.rpartition('<div id="linktable">')[-1].split('</table>')[0]
    hhtml = html.replace('\t', '').replace('\n', '')
    matches = re.findall('class="host"><img src="(.+?)".+?href="http.+?watchseries.ovh/link.php\?r=(.+?)".+?title="(.+?)"', hhtml)
    for img, link, name in matches:
        host = unicode(name).capitalize()
        vurl = base64.b64decode(link)
        id = vurl.rpartition('/')[-1]
        num = epnum
        playtitle = "{0} @ {1} ({2})".format(epfullname, host, id)
        if len(epnum) == 0:
            num = id
        lbl = "[COLOR green]{0}[/COLOR] [COLOR yellow][I]({1})[/I][/COLOR]\n[COLOR white]{2}[/COLOR] [COLOR yellow]{3}[/COLOR]".format(host, id, showname, epnum)
        lbl2 = "[B]{0}[/B] [I]({1})[/I]\nURL: {2} Video Link: {3}".format(showname, num, url, vurl)
        playpath = 'plugin://plugin.video.resolveurl-tester/?action=play&url={0}&title={1}'.format(quote(vurl), quote(playtitle))
        item = {'label': lbl, 'label2': lbl2, 'is_playable': True, 'is_folder': False, 'thumb': img, 'icon': img, 'url': playpath, 'properties': {'videourl': vurl, 'sourceurl': url}}
        litem = add_ContextDL(item)
        litems.append(litem)
    return litems


@plugin.action()
def play(params):
    if params.video is not None:
        urlvid = params.video
    else:
        return None
    url = 'plugin://plugin.video.resolveurl-tester/?action=play&url={0}'.format(quote(urlvid))
    xbmc.Player().play(url)


def showMessage(header='', msg=''):
    try:
        header = str(header.encode('utf-8', 'ignore'))
        msg = str(msg.encode('utf-8', 'ignore'))
        xbmc.executebuiltin('Notification({0},{1})'.format(header, msg))
    except:
        print(header + '\n' + msg)


@plugin.action()
def show_latest():
    return list_latest()


def search_ws(query):
    items = []
    url = "https://watchseries.ovh/serie/" + query.replace(' ', '_')
    items = get_seriesepisodelists(url)
    return items


@plugin.action()
#@plugin.mem_cached(10)
def show_searchbox(params):
    site = params.site
    searchtxt = ''
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = get_input(searchtxt)
    querytext = searchtxt.replace(' ', '_')
    plugin.set_setting('lastsearch', searchtxt)
    searchurl = plugin.get_url(action='show_search', searchterm=querytext)
    #xbmc.executebuiltin("RunPlugin({0})".format(searchurl))
    #show_search(params={'searchterm': querytext})
    if site == 'ws':
        return search_ws(query=querytext)
    else:
        latestshows = list_searchepisodes(query=querytext)
        litems = []
        #latestshows = Tv.get_latest()
        for show in latestshows:
            showlink = show.get('url', '')
            showpath = plugin.get_url(action='get_sources', episode=showlink)
            item = {
                'label': show.get('name', ''),
                'thumb': "DefaultVideo.png",
                'url': plugin.get_url(action='show_sources', episode=showlink)
            }
            litems.append(item)
        return litems


@plugin.action()
#@plugin.mem_cached(10)
def show_search(params):
    return list_searchepisodes(query=params.searchterm)


@plugin.action()
#@plugin.mem_cached(10)
def show_sources(params):
    return list_sources(episode=params.episode)


@plugin.action()
#@plugin.mem_cached(10)
def show_category():
    searchtxt = ''
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = get_input(searchtxt)
    querytext = searchtxt.replace(' ', '+')
    plugin.set_setting('lastsearch', searchtxt)
    return list_category(category=searchtxt)


#@plugin.action()
#@plugin.mem_cached(10)
def list_latest():
    litems = []
    latestshows = Tv.latest()
    for show in latestshows:
        showname = show.get('name', '')
        showlink = show.get('video', '')
        showpath = plugin.get_url(action='show_sources', episode=showlink)
        item = {
            'label': showname,
            'label2': showlink,
            'is_folder': True,
            'thumb': "DefaultVideo.png",
            'url': showpath
        }
        litems.append(item)
    return litems


#@plugin.action()
#@plugin.mem_cached(10)
def list_sources(episode=''):
    litems = []
    videos = Tv.get_sources(episode)
    for video in videos:
        item = {
            'label': video['name'],
            'label2': "{0}: {1}".format(video['hoster'], video['videoid']),
            'thumb': 'defaultfolder.png',
            'url': plugin.get_url(action='play', video=video['video']),
            'is_folder': False }
        litems.append(item)
    return litems


#@plugin.action()
#@plugin.mem_cached(10)
def list_searchepisodes(query=''):
    litems = []
    #eplist = Tv.get_searchresults(query=query)
    eplist = Tv.dosearch(url="http://tvseries4u.com/?s="+query)
    for show in eplist:        
        showlink = show.get('video', '')
        showname = show.get('name', '')
        showthumb = show.get('thumb', 'DefaultVideo.png')
        showpath = plugin.get_url(action='show_sources', episode=showlink)
        item = {
            'label': showname,
            'thumb': showthumb,
            'url': showpath,
            'is_folder': True
        }
        litems.append(item)
    return litems


#@plugin.action()
#@plugin.mem_cached(10)
def list_category(category=''):
    VIDEOS = Tv.get_catepisodes(category)
    litems = []
    for show in VIDEOS:        
        showlink = show.get('video', '')
        showname = show.get('name', '')
        showthumb = 'DefaultVideo.png'
        showpath = plugin.get_url(action='show_sources', episode=showlink)
        item = {
            'label': showname,
            'thumb': showthumb,
            'url': showpath,
            'is_folder': True
        }
        litems.append(item)
    return litems


def add_ContextDL(item):
    ctxlist = []
    ctxlist = item.get('context_menu', [])
    name = item.get('label', item.get('label2', ''))
    hurl = item.get('url', '')
    if item.has_key('properties'):
        itemp = item.get('properties', {})
        if itemp.has_key("videourl"):
            hurl = unquote(itemp.get('videourl', ''))
    else:
        uq = hurl.split('&url=',1)[-1]
        hurl = unquote(uq.split('&', 1)[0])
    ctx = ("[COLOR green]Download[/COLOR]", 'RunPlugin("{0}")'.format(plugin.get_url(action="download", video=hurl)),)
    ctxlist.append(ctx)
    item.update({"context_menu": ctxlist})
    return item


@plugin.action()
def download(params):
    vurl = ''
    allok = False
    if params.video is not None:
        vurl = params.video
    else:
        return None
    try:
        from YDStreamExtractor import getVideoInfo
        from YDStreamExtractor import handleDownload
        info = getVideoInfo(vurl, resolve_redirects=True)
        dlpath = plugin.get_setting('downloadpath')
        if not path.exists(dlpath):
            dlpath = xbmc.translatePath("home://")
        handleDownload(info, bg=True, path=dlpath)
        allok = True
    except:
        allok = False
        xbmc.executebuiltin('Notification({0},{1})'.format("FAILED to Download", vurl))
    if allok:
        xbmc.executebuiltin('Notification({0},{1})'.format("OK! Download Started", vurl))


def get_input(default=''):
    kb = xbmc.Keyboard(default, 'Search TVSeries4u')
    kb.setDefault(default)
    kb.setHeading('TVSeries4u Search')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term = kb.getText()
        return(search_term)
    else:
        return None

if __name__ == '__main__':
    # Run our plugin
    plugin.run()
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
