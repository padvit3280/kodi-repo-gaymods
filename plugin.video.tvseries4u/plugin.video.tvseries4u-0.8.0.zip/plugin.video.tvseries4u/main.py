# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Created on: 3.12.2017
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import sys, base64, re, os.path as path
try:
    import xbmc
except:
    import Kodistubs.xbmc as xbmc
try:
     # Python 2.6-2.7
     from HTMLParser import HTMLParser
except ImportError:
     # Python 3
     from html.parser import HTMLParser
h = HTMLParser()
from resources import lib as Lib
try:
    import urllib, urllib2
except:
    import urllib3.util as urllib2
quote_plus = urllib.quote_plus
quote = urllib.quote

plugin = Lib.simpleplugin.Plugin()
__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
__next__ = path.join(xbmc.translatePath('special://home/addons/plugin.video.tvseries4u/resources/'), 'next.png')
Tv = Lib.tv4u.Tv4u(cookiepath=__cookie__)

@plugin.action()
@plugin.mem_cached(10)
def root():
    imgWs = __next__.replace('next', 'watchseries')
    imgVidster = imgWs.replace('watchseries', 'myvidster')
    rootmenu = {
        "Home": [
            {'label': 'Watch Series', 'url': plugin.get_url(action='home_ws'), 'thumb': imgWs,
             'is_folder': True, 'is_playable': False},
            {'label': 'Watch Series [I](Long List)[/I]', 'url': plugin.get_url(action='latest_ws', page=1), 'thumb': imgWs,
             'is_folder': True, 'is_playable': False},
            {'label': 'Search', 'url': plugin.get_url(action='show_searchbox', site='ws'), 'thumb': __next__.replace('next', 'search'),
             'is_folder': True, 'is_playable': False},
            {'label': 'MyVidster', 'url': plugin.get_url(action='home_myvidster'), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False} #,
            #{'label': 'Latest', 'url': plugin.get_url(action='show_latest'), 'thumb': 'DefaultVideo.png', 'is_folder': True, 'is_playable': False},
            #{'label': 'Search by Showname', 'url': plugin.get_url(action='show_category', site='tvseries4u'), 'thumb': 'DefaultVideo.png', 'is_folder': True, 'is_playable': False},
            #{'label': 'Search by Keyword', 'url': plugin.get_url(action='show_searchbox', site='tvseries4u'), 'thumb': 'DefaultVideo.png', 'is_folder': True, 'is_playable': False}
        ]
    }
    return rootmenu["Home"]

def home_myvidster():
    items = []
    litems = []
    urlrss = 'https://www.myvidster.com/rss/channel/1533786'
    resp = Lib.urlquick.get(urlrss)
    for item in resp.xml().iter('item'):
        items.append(item)
    for item in items:
        litem = {'is_folder': False, 'is_playable': True}
        for kid in item.getchildren():
            if kid.tag == 'link':
                litem.update({'url': plugin.get_url(action='play', video=kid.text)})  # {'url': plugin.get_url(action=sources_ws, url=kid.text)})
            elif kid.tag == 'title':
                name = kid.text.encode('latin', 'ignore')
                litem.update({'label': name.strip()})
            if kid.tag == '{http://search.yahoo.com/mrss/}thumbnail':
                    attr = kid.attrib
                    img = attr.get('url')
                    litem.update({'thumb': img, 'icon': img})
            elif kid.tag == 'description':
                lbl2 = kid.text.strip() + '\n' + litem.get('label2', '')
                litem.update({'label2': lbl2})
            elif kid.tag == 'pubdate':
                lbl2 = kid.text.strip() + '\n' + litem.get('label2', '')
                litem.update({'label2': lbl2})
        litems.append(litem)
    return litems

@plugin.action()
@plugin.mem_cached(10)
def home_ws():
    items = []
    xitems = []
    urlrss = 'https://watchseries.ovh/rss/newest-episodes'
    resp = Lib.urlquick.get(urlrss)
    for item in resp.xml().iter('item'):
        xitems.append(item)
    for item in xitems:
        litem = {'is_folder': True, 'is_playable': False}
        for kid in item.getchildren():
            if kid.tag == 'link':
                litem.update({'url': plugin.get_url(action='sources_ws', vurl=kid.text)}) #{'url': plugin.get_url(action=sources_ws, url=kid.text)})
            elif kid.tag == 'title':
                name = kid.text.encode('latin', 'ignore')
                epname, epdetails = name.split(',',1)
                litem.update({'label': "[COLOR white][B]{0}[/B][/COLOR] [I]{1}[/I]".format(epname.strip(), epdetails.strip())})
            elif kid.tag == 'description':
                img = kid.text.rpartition('src="')[-1].split('"')[0]
                lbl2 = kid.text.rpartition('/>')[-1].strip()
                litem.update({'thumb': img, 'icon': img, 'label2': lbl2})
        items.append(litem)
    return items


@plugin.action()
#@plugin.mem_cached(10)
def latest_ws(params):
    items = []
    page = 1
    if params.page is not None:
        page = params.page
    url_base = 'https://watchseries.ovh/latest/'
    nextpage = int(page) + 10
    nextlbl = 'Next -> {0}'.format(nextpage.__str__())
    nextitem = {'label': nextlbl, 'url': plugin.get_url(action='latest_ws', page=nextpage), 'thumb': __next__,
             'icon': __next__, 'is_folder': True, 'is_playable': False}
    for p in range(1, 10):
        url = url_base + p.__str__()
        items.extend(get_episodelists(url))
    items.append(nextitem)
    return items


def get_episodelists(url):
    epname = ""
    epseason = ""
    resp = Lib.urlquick.get(url)
    src = resp.content
    html = src.rpartition('<ul class="listings">')[-1].split('<ul class="pagination">')[0]
    litems = []
    results = re.compile('<li.+?href="(.+?)" title="(.+?)".+?epnum">(.+?)</span>').findall(html)
    for link,title,date in results:
        sepchar = '-'
        if title.find('-') == -1:
            sepchar = ','
        epname, epseason = title.split(sepchar,1)
        lbl = "[COLOR white][B]{0}[/B][/COLOR] [COLOR grey]{1}[/COLOR] [COLOR yellow]{2}[/COLOR]".format(epname.strip(), epseason.strip(), date)
        item = {'label': title, 'label2': date,'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action='sources_ws', vurl=link)}
        litems.append(item)
    return litems


def get_seriesepisodelists(url):
    epname = ""
    epseason = ""
    resp = Lib.urlquick.get(url)
    src = resp.content
    html = src.rpartition('<ul class="listings')[-1].split('<ul class="pagination">')[0]
    litems = []
    results = re.findall(r'href="(.+?)".+?"name" >(.+?)</.+?"datepublished">(.+?)</', string=html, flags=re.MULTILINE)
    for link,title,date in results:
        try:
            char = u'&nbsp;'
            epname = title.replace(char, ' ')
            lbl = "[COLOR white][B]{0}[/B][/COLOR] [COLOR yellow]{1}[/COLOR]".format(epname.strip(), date)
            item = {'label': epname, 'label2': date,'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action='sources_ws', vurl=link)}
            litems.append(item)
        except:
            try:
                p1,p2 = title.split(' ', 1)
                epname = p1 + ' ' + p2[0]
            except:
                epname = url.rpartition('/')[-1].replace('_', ' ').title()
            lbl = "[COLOR white][B]{0}[/B][/COLOR] [COLOR yellow]{1}[/COLOR]".format(epname.strip(), date)
            item = {'label': epname, 'label2': date,'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action='sources_ws', vurl=link)}
            litems.append(item)
    return litems



@plugin.action()
#@plugin.mem_cached(10)
def sources_ws(params):
    items = []
    vurl = "https://watchseries.ovh/episode/"
    epurl = params.vurl
    items = get_sourceslist(epurl)
    return items


def get_sourceslist(url):
    litems = []
    name = ""
    link = ""
    resp = Lib.urlquick.get(url)
    src = resp.content
    html = src.rpartition('<div id="linktable">')[-1].split('</table>')[0]
    matches = re.findall('href="https://watchseries.ovh/link.php\?r=(.+?)" class="watchlink" title="(.+?)"', html)
    for link, name in matches:
        vurl = base64.b64decode(link)
        host = vurl.replace('https://', '').split('/')[0]
        img = "https://static.swatchseries.to/templates/default/images/favicons/{0}.png)".format(host)
        id = vurl.replace('https://'+host+'/','').split('/')[0]
        lbl2 = "{0} {1}".format(url, vurl)
        lbl = "[COLOR white]{0}[/COLOR] [COLOR yellow]({1})[/COLOR]".format(name.title(), id)
        item = {'label': lbl, 'label2': lbl2, 'is_folder': False, 'thumb': img, 'icon': img, 'url': plugin.get_url(action='play', video=vurl)}
        litems.append(item)
    return litems


@plugin.action()
def play(params):
    urlvid = params.video
    resolvedurl = urlvid
    url = "plugin://plugin.video.wsonline/play/{0}".format(quote_plus(urlvid))
    try:
        xbmc.executebuiltin("Notification({0}, {1})".format("Trying To Play...", urlvid))
        resolvedurl = Tv.resolve(urlvid)
        plugin.log_notice(resolvedurl)
        xbmc.executebuiltin("Notification({0}, {1})".format(urlvid, resolvedurl))
    except:
        plugin.log_notice("ERROR RESOLVING " + url)
        #xbmc.executebuiltin("RunPlugin({0})".format(str(url)))
    #xbmc.executebuiltin('Notification({0}, {1})'.format(str(url2.partition('://')[-1]), str(url.partition('://')[-1])))
    #showMessage('play', url)
    #return url
    #url2 = plugin.resolve_url(url, succeeded=True)
    #showMessage(url, url2)
    #print(str(url) + ' ' + str(url2))
    item = {'label': urlvid, 'label2': resolvedurl, 'thumb': 'DefaultVideo.png', 'is_folder': False, 'is_playable': True, 'url': resolvedurl}
    #item = {'label': urlvid, 'url': url, 'thumb': 'DefaultVideo.png', 'is_folder': False, 'is_playable': True, 'path': url}
    #xbmc.Player().play(url)
    #return item
    #return Lib.simpleplugin.Plugin.resolve_url(str(url), succeeded=True)
    #return url
    #return plugin.resolve_url(path=str(urlvid), play_item=item, succeeded=True)
    #return [item]
    #xbmc.log(msg=resolvedurl, level='DEBUG')
    plugin.resolve_url(resolvedurl, item)
    xbmc.Player().play(resolvedurl)
    return [item]


def showMessage(self, header='', msg=''):
    try:
        header = str(header.encode('utf-8', 'ignore'))
        msg = str(msg.encode('utf-8', 'ignore'))
        xbmc.executebuiltin('Notification({0},{1})'.format(header, msg))
    except:
        print(header + '\n' + msg)


@plugin.action()
def show_latest():
    return list_latest()

def search_ws(query):
    items = []
    url = "https://watchseries.ovh/serie/" + query.replace(' ', '_')
    items = get_seriesepisodelists(url)
    return items

@plugin.action()
#@plugin.mem_cached(10)
def show_searchbox(params):
    site = params.site
    searchtxt = ''
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = get_input(searchtxt)
    querytext = searchtxt.replace(' ', '_')
    plugin.set_setting('lastsearch', searchtxt)
    searchurl = plugin.get_url(action='show_search', searchterm=querytext)
    #xbmc.executebuiltin("RunPlugin({0})".format(searchurl))
    #show_search(params={'searchterm': querytext})
    if site == 'ws':
        return search_ws(query=querytext)
    else:
        latestshows = list_searchepisodes(query=querytext)
        litems = []
        #latestshows = Tv.get_latest()
        for show in latestshows:
            showlink = show.get('url', '')
            showpath = plugin.get_url(action='get_sources', episode=showlink)
            item = {
                'label': show.get('name', ''),
                'thumb': "DefaultVideo.png",
                'url': plugin.get_url(action='show_sources', episode=showlink)
            }
            litems.append(item)
        return litems


@plugin.action()
#@plugin.mem_cached(10)
def show_search(params):
    return list_searchepisodes(query=params.searchterm)

@plugin.action()
#@plugin.mem_cached(10)
def show_sources(params):
    return list_sources(episode=params.episode)


@plugin.action()
#@plugin.mem_cached(10)
def show_category():
    searchtxt = ''
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = get_input(searchtxt)
    querytext = searchtxt.replace(' ', '+')
    plugin.set_setting('lastsearch', searchtxt)
    return list_category(category=searchtxt)


#@plugin.action()
#@plugin.mem_cached(10)
def list_latest():
    litems = []
    latestshows = Tv.latest()
    for show in latestshows:
        showname = show.get('name', '')
        showlink = show.get('video', '')
        showpath = plugin.get_url(action='show_sources', episode=showlink)
        item = {
            'label': showname,
            'label2': showlink,
            'is_folder': True,
            'thumb': "DefaultVideo.png",
            'url': showpath
        }
        litems.append(item)
    return litems


#@plugin.action()
#@plugin.mem_cached(10)
def list_sources(episode=''):
    litems = []
    videos = Tv.get_sources(episode)
    for video in videos:
        item = {
            'label': video['name'],
            'label2': "{0}: {1}".format(video['hoster'], video['videoid']),
            'thumb': 'defaultfolder.png',
            'url': plugin.get_url(action='play', video=video['video']),
            'is_folder': False }
        litems.append(item)
    return litems


#@plugin.action()
#@plugin.mem_cached(10)
def list_searchepisodes(query=''):
    litems = []
    #eplist = Tv.get_searchresults(query=query)
    eplist = Tv.dosearch(url="http://tvseries4u.com/?s="+query)
    for show in eplist:        
        showlink = show.get('video', '')
        showname = show.get('name', '')
        showthumb = show.get('thumb', 'DefaultVideo.png')
        showpath = plugin.get_url(action='show_sources', episode=showlink)
        item = {
            'label': showname,
            'thumb': showthumb,
            'url': showpath,
            'is_folder': True
        }
        litems.append(item)
    return litems


#@plugin.action()
#@plugin.mem_cached(10)
def list_category(category=''):
    VIDEOS = Tv.get_catepisodes(category)
    litems = []
    for show in VIDEOS:        
        showlink = show.get('video', '')
        showname = show.get('name', '')
        showthumb = 'DefaultVideo.png'
        showpath = plugin.get_url(action='show_sources', episode=showlink)
        item = {
            'label': showname,
            'thumb': showthumb,
            'url': showpath,
            'is_folder': True
        }
        litems.append(item)
    return litems


def get_input(default=''):
    kb = xbmc.Keyboard(default, 'Search TVSeries4u')
    kb.setDefault(default)
    kb.setHeading('TVSeries4u Search')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term = kb.getText()
        return(search_term)
    else:
        return None

if __name__ == '__main__':
    # Run our plugin
    plugin.run()
