# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Created on: 3.12.2017
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import sys, re, os.path as path
try:
    import xbmc
except:
    import Kodistubs.xbmc as xbmc
from resources import lib as Lib
try:
    import urllib, urllib2
except:
    import urllib3.util as urllib2
quote_plus = urllib.quote_plus
quote = urllib.quote

plugin = Lib.simpleplugin.Plugin()
__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
Tv = Lib.tv4u.Tv4u(cookiepath=__cookie__)

VIDEOS = {
    'Latest': [
        {'name': 'Crab', 'thumb': 'http://www.vidsplay.com/vids/crab.jpg', 'video': 'http://www.vidsplay.com/vids/crab.mp4'},
        {'name': 'Alligator', 'thumb': 'http://www.vidsplay.com/vids/alligator.jpg',  'video': 'http://www.vidsplay.com/vids/alligator.mp4'},
        {'name': 'Turtle', 'thumb': 'http://www.vidsplay.com/vids/turtle.jpg', 'video': 'http://www.vidsplay.com/vids/turtle.mp4'}],
    'Search': [
        {'name': 'Postal', 'thumb': 'http://www.vidsplay.com/vids/us_postal.jpg', 'video': 'http://www.vidsplay.com/vids/us_postal.mp4'},
        {'name': 'Traffic', 'thumb': 'http://www.vidsplay.com/vids/traffic1.jpg', 'video': 'http://www.vidsplay.com/vids/traffic1.avi'},
        {'name': 'Traffic', 'thumb': 'http://www.vidsplay.com/vids/traffic_arrows.jpg', 'video': 'http://www.vidsplay.com/vids/traffic_arrows.mp4'} ]
}

@plugin.action()
def root():
    rootmenu = {
        "Home": [
            {'label': 'Latest', 'url': plugin.get_url(action='show_latest'), 'thumb': 'DefaultVideo.png', 'is_folder': True, 'is_playable': False},
            {'label': 'Search', 'url': plugin.get_url(action='show_searchbox'), 'thumb': 'DefaultVideo.png', 'is_folder': True, 'is_playable': False},
            {'label': 'Categories', 'url': plugin.get_url(action='show_category'), 'thumb': 'DefaultVideo.png', 'is_folder': True, 'is_playable': False}
        ]
    }
    return rootmenu["Home"]


def showMessage(self, header='', msg=''):
    try:
        header = str(header.encode('utf-8', 'ignore'))
        msg = str(msg.encode('utf-8', 'ignore'))
        xbmc.executebuiltin('Notification({0},{1})'.format(header, msg))
    except:
        print(header + '\n' + msg)


@plugin.action()
def play(params):
    urlvid = params.video
    url = Tv.resolve(urlvid)
    url2 = plugin.resolve_url(url, succeeded=True)
    #xbmc.executebuiltin('Notification({0}, {1})'.format(str(url), str(url2)))
    showMessage(url, url2)
    print(str(url) + ' ' + str(url2))
    item = {'label': urlvid, 'url': url2, 'thumb': 'DefaultVideo.png', 'is_folder': False, 'is_playable': True, 'path': url}
    xbmc.Player().play(url)
    return item


def show_latest(params):
    return list_latest()

@plugin.action()
def show_searchbox(params):
    searchtxt = ''
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = get_input(searchtxt)
    querytext = searchtxt.replace(' ', '+')
    plugin.set_setting(key='lastsearch', val=searchtxt)
    searchurl = plugin.get_url(action='show_search', searchterm=querytext)
    #xbmc.executebuiltin("RunPlugin({0})".format(searchurl))
    show_search(params=Lib.simpleplugin.Params({'searchterm': querytext}))


@plugin.action()
def show_search(params):
    return list_searchepisodes(query=params.searchterm)

@plugin.action()
def show_sources(params):
    return list_sources(episode=params.episode)

@plugin.action()
def show_category(params):
    return list_category(category=params.searchterm)

@plugin.mem_cached(10)
def list_latest():
    litems = []
    latestshows = Tv.get_latest()
    for show in latestshows:
        showlink = show.get('url', '')
        showpath = plugin.get_url(action='get_sources', episode=showlink)
        item = {
            'label': show.get('name', ''),
            'thumb': "DefaultVideo.png",
            'url': plugin.get_url(action='show_sources', episode=showlink)
        }
        litems.append(item)
    return litems

@plugin.mem_cached(10)
def list_sources(episode=''):
    litems = []
    videos = Tv.get_sources(episode)
    for video in videos:
        item = {
            'label': video['name'],
            'thumb': 'defaultfolder.png',
            'url': plugin.get_url(action='play', video=video.get('url', '')),
            'is_playable': True }
        litems.append(item)
    return litems

@plugin.mem_cached(10)
def list_searchepisodes(query=''):
    litems = []
    eplist = Tv.get_searchresults(query=query)
    for show in eplist:
        item = {
            'label': show.get('name', ''),
            'thumb': show.get('thumb', 'DefaultVideo.png'),
            'url': plugin.get_url(action='show_sources', episode=show.get('video', show.get('url', '')))
        }
        litems.append(item)
    return litems

@plugin.mem_cached(10)
def list_category(category=''):
    VIDEOS = Tv.get_catepisodes(category)
    litems = []
    for video in VIDEOS:
        item = {
            'label': video['name'],
            'thumb': 'defaultvideo.png',
            'url': plugin.get_url(action='listvideos', episode=videos.get('video', ''))
        }
        litems.append(item)
    return litems


def get_input(default=''):
    kb = xbmc.Keyboard(default, 'Search TVSeries4u')
    kb.setDefault(default)
    kb.setHeading('TVSeries4u Search')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term = kb.getText()
        return(search_term)
    else:
        return None

if __name__ == '__main__':
    # Run our plugin
    plugin.run()
