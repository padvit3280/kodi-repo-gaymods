from . import webutil
to_unicode = webutil.to_unicode
wsgi_decoding_dance = webutil.wsgi_decoding_dance
wsgi_encoding_dance = webutil.wsgi_encoding_dance
try_coerce_native = webutil.try_coerce_native
import os.path as Path
import re, sys

class Tv4u:

    def __init__(self, cookiepath=None):
        self.plug = None
        self.BASEURL = "http://tvseries4u.com"
        self.HOST = self.BASEURL.split('//', 1)[-1]
        self.URL_latest = "/last-350-posts/"
        self.URL_search = "/?s={0}"
        self.URL_category = "/category/{0}"
        self.PATH = Path.realpath(Path.curdir)
        if cookiepath is not None:
            self.COOKIES = cookiepath
        else:
            self.COOKIES = Path.join(self.PATH, 'cookies.dat')
        if sys.version_info < (3, 0):
            DemystifiedWebRequest = webutil.DemystifiedWebRequest
            self.getWeb = DemystifiedWebRequest(cookiePath=self.COOKIES)
        else:
            self.getWeb = None

    def getsource(self, url):
        import http.client as webclient
        con = webclient.HTTPConnection(self.HOST)
        con.request(method='GET', url=url)
        resp = con.getresponse()
        rawhtml = resp.read()
        html = rawhtml.decode('utf8')
        return html.split('<body',1)[-1]

    def setup(self, path='.', plugin=None):
        self.PATH = Path.realpath(path)
        self.COOKIES = Path.join(self.PATH, 'cookies.dat')
        self.getWeb = DemystifiedWebRequest(cookiePath=self.COOKIES)
        try:
            import simpleplugin
            assert isinstance(self.plug, simpleplugin.Plugin)
        except:
            self.plug = simpleplugin.Plugin('plugin.video.tvseries4u')
            assert isinstance(self.plug, simpleplugin.Plugin)

    def DL(self, url):
        if sys.version_info.major < 3:
            html = u''
            try:
                html = to_unicode(
                    self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False,
                                          ignoreCache=False, demystify=True).encode('latin-1', errors='ignore'))
            except:
                try:
                    html = wsgi_decoding_dance(
                        self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False))
                except:
                    html = wsgi_encoding_dance(
                        self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False))
            try:
                if html is None or len(html) < 1:
                    html = try_coerce_native(self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False,
                                                              mobile=False))
            except:
                return self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False).encode(
                    'latin-1', errors='ignore')
        else:
            html = self.getsource(url)
        html = html.decode('utf8', 'ignore') # src = r.content.decode(r.encoding, 'ignore')
        return html

    def get_sources(self, url_episode=""):
        litems = []
        catitem = None
        src = self.DL(url_episode)
        html = src.split('class="filmicerik linkcontent"', 1)[-1]
        shtml = html.split('</div>',1)[0]
        reSources = re.compile('href="(.+?)"') # re.compile('href="(.+?)" title="(.+?)"')
        matches = reSources.findall(shtml)
        count = 1
        if matches is not None and len(matches) > 0:
            for vidurl in matches:
                uparts = vidurl.partition('//')[-1].split('/', 1).split(' ')[0]
                hoster = uparts[0]
                vkey = uparts[-1].replace('/', ' ').replace('.html', '').replace('.htm', '').strip()
                sourcename = "#{0}: {1} ({2})".format(str(count), hoster, vkey)
                item = {'name': sourcename, 'video': vidurl, 'hoster': hoster, 'videoid': vkey}
                litems.append(item)
                count += 1
        if catitem is not None:
            litems.append(catitem)
        return litems

    def get_catepisodes(self, category=""):
        url = self.BASEURL + self.URL_category.format(category.replace(' ', '-'))
        litems = []
        src = self.DL(url)
        html = src.split('class="wt-cat"', 1)[-1]
        matches = re.compile('href="(.+?)">(.+?)</a>').findall(html) #re.compile('href="(.+?)" title="(.+?)"')
        if matches is not None and len(matches) > 0:
            for eplink, epname in matches:
                item = {'name': epname, 'video': eplink}
                litems.append(item)
        return litems

    def get_url(self, **kwargs):
        if self.plug is not None:
            return self.plug.get_url(**kwargs)
        else:
            try:
                from urllib.parse import urlencode
            except:
                from urllib import urlencode
            plugurl = 'plugin://plugin.video.tvseries4u/?'
            return plugurl + urlencode(kwargs)

    def latest(self):
        litems = []
        url = self.BASEURL + self.URL_latest
        src = self.DL(url)
        html = src.split('class="wt-cat"', 1)[-1]
        matches = re.compile('href="(.+?)">(.+?)</a>').findall(html)
        if matches is not None and len(matches) > 0:
            for eplink, epname in matches:
                item = {'name': epname, 'video': eplink}
                litems.append(item)
        return litems

    def get_latest(self):
        litems = []
        url = self.BASEURL + self.URL_latest
        #try:
        #    src = self.getsource(url)
        #except:
        #    src = self.DL(url)
        src = self.DL(url)
        html = src.split('class="lcp_catlist" id="lcp_instance_0">', 1)[-1]
        #html = html.rpartition("<span class='pages'")[0]
        reLatest = re.compile('<li.+?<a href="(http://tvseries4u.com/.+?)" title="(.+?)".+?</li>') #, re.DOTALL)
        matches = reLatest.findall(html)
        if matches is not None and len(matches) > 0:
            maxlen = 100
            if len(matches) < 100:
                maxlen = len(matches)
            for showlink, showname in matches[:maxlen]:
                #showpath = self.get_url(action='get_sources', name=showname, url=showlink)
                item = {'name': showname, 'url': showlink, 'video': showlink}
                litems.append(item)
        return litems

    def get_searchresults(self, query=''):
        litems = []
        item = {}
        showthumb = 'DefaultVideo.png'
        url = self.BASEURL + self.URL_search.format(query)
        url2 = self.BASEURL + '/{0}' + self.URL_search.format(query)
        litems = self.dosearch(url)
        if len(litems) < 10:
            return litems
        for page in range(2,6):
            url = url2.format(str(page))
            litems.extend(self.dosearch(url))
        return litems

    def dosearch(self, url):
        litems = []
        try:
            src = self.getsource(url)
        except:
            src = self.DL(url)
        html = src.split('="filmcontent"',1)[-1]
        html = html.rpartition("<span class='pages'")[0]
        reEpisode = re.compile('href="(http://tvseries4u.com/.+?)">.+?<img src="(.+?)" alt="(.+?)"' )#, re.DOTALL)
        matches = reEpisode.findall(html)
        for showlink, showThumb, showname in matches:
            #showpath = self.get_url(action='list_sources', name=showname, url=showlink)
            item = {'name': showname, 'video': showlink, 'thumb': showThumb}
            litems.append(item)
        return litems
        # reShow = re.compile('<div class="moviefilm">(.*?)class="movies".', re.DOTALL)
        # reLink = re.compile('href="(http://tvseries4u.com/.+?)"')
        # reImgTitle = re.compile('img src="(http://tvseries4u.com/.+?)" alt="(.+?)"')

    def resolve(self, url):
        resolved = ''
        stream_url = ''
        item = None
        try:
            import urlresolver
            resolved = urlresolver.HostedMediaFile(url).resolve()
            if not resolved or resolved == False or len(resolved) < 1:
                resolved = urlresolver.resolve(url)
                if resolved is None or len(resolved) < 1:
                    resolved = urlresolver.resolve(webutil.unescape(url))
            if len(resolved) > 1:
                print(resolved)
                return resolved
        except:
            resolved = ''
        try:
            import YDStreamExtractor
            info = YDStreamExtractor.getVideoInfo(url, resolve_redirects=True)
            resolved = info.streamURL()
            for s in info.streams():
                try:
                    stream_url = s['xbmc_url'].encode('utf-8', 'ignore')
                except:
                    pass
            if len(stream_url) > 1:
                resolved = stream_url
            if len(resolved) > 1:
                return resolved
        except:
            pass

        if len(resolved) > 1:
            return resolved
        else:
            return url