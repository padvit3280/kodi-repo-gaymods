# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Created on: 3.12.2017
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import sys, re, os.path as path
try:
    import xbmc
except:
    import Kodistubs.xbmc as xbmc
from resources import lib as Lib # import tv4u, simpleplugin, webutil
try:
    import urllib, urllib2
except:
    import urllib3.util as urllib2
quote_plus = urllib.quote_plus
quote = urllib.quote



plugin = Lib.simpleplugin.Plugin()
__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
Tv = Lib.tv4u.Tv4u(cookiepath=__cookie__)
#Tv.setup(path=plugin.path, plugin=plugin)

VIDEOS = {
    'Latest': [
        {'name': 'Crab', 'thumb': 'http://www.vidsplay.com/vids/crab.jpg', 'video': 'http://www.vidsplay.com/vids/crab.mp4'},
        {'name': 'Alligator', 'thumb': 'http://www.vidsplay.com/vids/alligator.jpg',  'video': 'http://www.vidsplay.com/vids/alligator.mp4'},
        {'name': 'Turtle', 'thumb': 'http://www.vidsplay.com/vids/turtle.jpg', 'video': 'http://www.vidsplay.com/vids/turtle.mp4'}],
    'Search': [
        {'name': 'Postal', 'thumb': 'http://www.vidsplay.com/vids/us_postal.jpg', 'video': 'http://www.vidsplay.com/vids/us_postal.mp4'},
        {'name': 'Traffic', 'thumb': 'http://www.vidsplay.com/vids/traffic1.jpg', 'video': 'http://www.vidsplay.com/vids/traffic1.avi'},
        {'name': 'Traffic', 'thumb': 'http://www.vidsplay.com/vids/traffic_arrows.jpg', 'video': 'http://www.vidsplay.com/vids/traffic_arrows.mp4'} ]
}


def list_category(category=''):
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.
    """
    VIDEOS = Tv.get_catepisodes(category)
    return VIDEOS


def list_sources(episode):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of videostreams in a given category from some site or server.
    """
    litems = []
    litems = Tv.get_sources(episode)
    return litems


@plugin.mem_cached(10)
def list_latest():
    items = []
    items = Tv.get_latest()
    return items


@plugin.action()
def root():
    """
    Create the list of video categories in the Kodi interface.
    """
    latestshows = list_latest()
    # Get video categories
    #categories = get_categories()
    # Iterate through categories and yield list items for Kodi to display
    for show in latestshows:
        yield {
            'label': show.get('name', ''),
            'thumb': "DefaultVideo.png",  # Item thumbnail
            'url': plugin.get_url(action='list_videos', episode=show.get('url', ''))
            # Since this item will open a sub-listing,
            # we don't specify 'is_folder' and 'is_playable' parameters explicitly,
            # leaving them to their default values (True and False respectively).
        }


@plugin.action()
def list_category(params):
    videos = Tv.get_catepisodes(params.url)
    for videos in videos:
        yield {
            'label': video['name'],
            'thumb': 'defaultvideo.png',
            'url': plugin.get_url(action='listvideos', episode=videos.get('url', ''))
        }

@plugin.action()
def list_videos(params):
    """
    Create the list of playable videos in the Kodi interface.
    """
    # Get the list of videos in the category.
    videos = Tv.get_sources(params.episode)
    # Iterate through videos and yield list items for Kodi to display
    for video in videos:
        yield {
            'label': video['name'],
            'thumb': 'defaultfolder.png',
            'url': plugin.get_url(action='play', video=video.get('url', '')),
            'is_playable': True
        }

@plugin.action()
def play(params):
    """
    Play a video by the provided path.
    """
    urlvid = params.video
    path = Tv.resolve(urlvid)
    if path is None:
        path = urlvid
    return path
    #vidurl = params.url
    # Return a path for Kodi to play
    #playpath = 'plugin://plugin.video.wsonline/play/' + quote_plus(path)
    #return playpath


if __name__ == '__main__':
    # Run our plugin
    plugin.run()
