from . import wsovf, simpleplugin, urlquick, kodisearch
