import json
from urllib import urlencode
from xbmcswift2 import Plugin, xbmc, xbmcaddon, ListItem, download_page as DL
try:
    from urlresolver import HostedMediaFile as HMF
except:
    HMF = None

APIKEY = "be4548a385c354cc02ca6135ae57b65f"
urlsearch = "http://pron.tv/api/search/stream/?apikey={0}&count=10&from=0&getmeta=0&query=".format(APIKEY)
plugin = Plugin()

def searchstreams(query='staxus'):
    res = json.loads(DL(urlsearch+urlencode(query)))
    vids = []
    if isinstance(res, dict):
        items = res.get('result')
        for item in items:
            datemod = item.get('modified')
            title = item.get('sourcetitle')
            filename = item.get('title')
            url = item.get('hosterurls')[0].get('url')
            path = plugin.url_for(play, url)
            img = 'DefaultVideo.png'
            litem = ListItem(label=title, label2=filename, icon=img, thumbnail=img, path=path)
            litem.is_folder = False
            litem.playable = True
            litem.set_info(type='video', info_labels={'Title': title})
            vids.append(litem)
    return vids


@plugin.route('/play/<url>')
def play(url):
    resolved = HMF(url).resolve()
    vitem = {'path': resolved, 'is_playable': True}
    plugin.play_video(vitem)

@plugin.route('/')
def index():
    return searchstreams()


if __name__ == '__main__':
    plugin.run()
