from kodiswift import Plugin, xbmc, ListItem, download_page, clean_dict, SortMethod
from resources.lib.addontools import WsolUtils, utils as WebUtils
import ssl, os.path as path, json, re
import webutil as WebUtils
try:
    import web_pdb
except:
    web_pdb = object(Exception)
    web_pdb.set_trace = callable(NotImplementedError)
ssl._create_default_https_context = ssl._create_unverified_context
plugin = Plugin()
ws = WsolUtils(kodiplugin=plugin)
__imgsearch__ = ws.imgsearch #'https://watchseries-online.pl'


@plugin.route('/')
def index():
    litems = []
    plugin.set_content('episodes')
    itemlatest = {'label': 'Latest Episodes', 'icon': 'DefaultFolder.png', 'thumbnail': 'DefaultFolder.png',
                  'path': plugin.url_for(latest, offset=0, urlpath='last-350-episodes')}
    itemlatest2 = {'label': 'Other Shows', 'icon': 'DefaultFolder.png', 'thumbnail': 'DefaultFolder.png',
                   'path': plugin.url_for(category, name="not-in-homepage", url="category/not-in-homepage")}
    itemsaved = {'label': 'Saved Shows', 'path': plugin.url_for(saved), 'icon': 'DefaultFolder.png',
                 'thumbnail': 'DefaultFolder.png'}
    itemplay = {'label': 'Resolve URL and Play (URLresolver required)',
                'path': plugin.url_for(endpoint=resolveurl),
                'icon': 'DefaultFolder.png', 'thumbnail': 'DefaultFolder.png'}
    itemsearch = {'label': 'Search', 'icon': __imgsearch__, 'thumbnail': __imgsearch__,
                  'path': plugin.url_for(search)}
    litems.append(itemlatest)
    litems.append(itemlatest2)
    litems.append(itemsaved)
    litems.append(itemsearch)
    litems.append(itemplay)
    return litems


@plugin.route('/category/<name>/<url>')
def category(name='', url=''):
    html = ''
    if not str(url).startswith('http') and len(url) > 8:
        url = ws.BASEURL + '/' + url
        html = DL(url)
    banner = None
    try:
        banner = str(html.split('id="banner_single"', 1)[0].rpartition('src="')[2].split('"', 1)[0])
        if banner.startswith('/'): banner = ws.BASEURL + banner
    except:
        pass
    if banner is None: banner = 'DefaultVideoFolder.png'
    epre = re.compile(ur"href='(https?://watchseries-online.[a-z]+/episode/.+?)' .+?<span.+?</span>(.+?)</a>",
                      re.DOTALL)
    matches = epre.findall(html)
    litems = []
    if len(matches) > 1000: matches = matches[0:1000]
    for eplink, epname in matches:
        item = ws.episode_makeitem(epname, eplink)
        item.path = plugin.url_for(episode, name=epname, url=eplink)
        litems.append(item)
    litems.sort(key=lambda litems: litems.label, reverse=True)
    return litems


@plugin.route('/episode/<name>/<url>')
def episode(name=None, url=None):
    waserror = False
    linklist = []
    litems = []
    if len(url) == '':
        waserror = True
    else:
        html = DL(url)
        linklist = ws.findvidlinks(html)
        itemparent = None
    if len(linklist) > 0:
        for name, link in linklist:
            itempath = plugin.url_for(play, url=link)
            item = dict(label=name, label2=link, icon='DefaultFolder.png', thumbnail='DefaultFolder.png', path=itempath)
            item.setdefault(item.keys()[0])
            litems.append(item)
        vitems = ws.sortSourceItems(litems)
        litems = []
        for li in vitems:
            item = ListItem.from_dict(**li)
            item.set_is_playable(True)
            item.set_info(type='video', info_labels={'Title': item.label, 'Plot': item.label2})
            item.add_stream_info(stream_type='video', stream_values={})
            litems.append(item)
    else:
        waserror = True
    if waserror:
        plugin.notify(title="ERROR No links: {0}".format(name), msg=url)
        return []
    return litems


@plugin.route('/latest/<offset>/<urlpath>')
def latest(offset=0, urlpath='last-350-episodes'):    
    # reDate = re.compile(strDate) #ur"<li class='listEpisode'>(\d+ \d+ \d+) :") reUrl = re.compile(strUrl)
    # ur'<a.+?href="([^"]*?)">') reName = re.compile(strName) #ur'</span>([^<]*?)</a>')
    url = ws.BASEURL + '/' + urlpath  # '/last-350-episodes'
    fullhtml = ws.DL(url)
    html = fullhtml.partition("</nav>")[-1].split("</ul>", 1)[0]
    strDate = ur"<li class='listEpisode'>(\d+ \d+ \d+) : "
    strUrl = ur'<a.+?href="([^"]*?)">'
    strName = ur'</span>([^<]*?)</a>'
    regexstr = "{0}{1}.+?{2}".format(strDate, strUrl, strName)
    matches = re.compile(regexstr).findall(html)
    litems = []
    epdate = ''
    eptitle = ''
    filtertxt = plugin.get_setting('filtertext')
    itemnext = {'label': 'Next ->', 'icon': 'DefaultFolder.png', 'thumbnail': 'DefaultFolder.png',
                'path': plugin.url_for(latest, offset=int(offset) + 400, urlpath=urlpath)}
    if len(matches) > 1000:
        matches = matches[0:1000]
    with web_pdb.catch_post_mortem():
        try:
            for epdate, eplink, epname in matches:
                item = ws.episode_makeitem(epname, eplink, epdate)
                #itempath = plugin.url_for(endpoint=episode, name=epname, url=eplink)                
                dateout = epdate.replace(' ', '-').strip()
                item.label += " [I][B][COLOR orange]{0}[/COLOR][/B][/I]".format(dateout)
                litems.append(item)
            litems.append(itemnext)
        except Exception as ex:
            print('ADDON ERROR: {0}'.format(str(repr(ex.message))))
            print(str(repr(ex)))
            #raise RuntimeError('ADDON ERROR: {0} {1}'.format(str(repr(ex.message)), str(repr(ex.args)))
    return litems


@plugin.route('/resolveurl')
def resolveurl():
    url = plugin.keyboard(default='', heading='Video Page URL')
    if url is not None:
        name = url
        if len(url) > 0:
            item = ListItem(label=name, label2=url, icon='DefaultVideo.png', thumbnail='DefaultVideo.png',
                            path=plugin.url_for(endpoint=play, url=url))
            item.playable = True
            item.set_info(type='video', info_labels={'Title': url, 'Plot': url})
            item.add_stream_info(stream_type='video', stream_values={})
            playable = play(url)
            plugin.notify(msg=playable.path, title="Playing..")
            plugin.play_video(playable)
    plugin.clear_added_items()
    plugin.end_of_directory()


@plugin.route('/saved')
def saved():
    litems = []
    sitems = []
    sitems = ws.loadsaved()
    noitem = {'label': "No Saved Shows", 'icon': 'DefaultFolder.png', 'path': plugin.url_for('index')}
    if len(sitems) < 1:
        return [noitem]
    else:
        return sitems


@plugin.route('/search/')
def search():
    searchtxt = plugin.get_setting('lastsearch')
    searchtxt = plugin.keyboard(searchtxt, 'Search Watchseries-Online', False)
    if len(searchtxt) > 1:
        plugin.set_setting(key='lastsearch', val=searchtxt)
        return ws.query(searchquery=searchtxt)
    else:
        return []


@plugin.route('/saveshow/<name>/<link>')
def saveshow(name='', link=''):
    sitems = []
    litems = []
    try:
        savedpath = ws.savedpath  # path.join(ws, "saved.json")
        if path.exists(savedpath):
            fpin = file(savedpath)
            rawjson = fpin.read()
            sitems = json.loads(rawjson)
            fpin.close()
        saveitem = {'label': name, 'path': plugin.url_for(endpoint=category, name=name, url=link)}
        saveitem.setdefault(saveitem.keys()[0])
        sitems.insert(0, saveitem)
        fpout = file(savedpath, mode='w')
        json.dump(sitems, fpout)
        fpout.close()
        plugin.notify(msg="SAVED {0}".format(name), title=link)
    except:
        plugin.notify(msg="ERROR save failed for {0}".format(name), title=link)


@plugin.route('/removeshow/<name>/<link>')
def removeshow(name='', link=''):
    sitems = []
    litems = []
    sitems = ws.loadsaved()
    for item in sitems:
        if item.get('name') == name or item.get('link') == link:
            plugin.notify(title='Removed {0}'.format(name), msg='Removed "{0}": {1}'.format(name, link))
        else:
            litems.append(item)
    jsout = json.dumps(litems)
    plugin.addon.setSetting('savedshows', jsout)
    plugin.notify(title='Removed {0}'.format(name), msg='{0} Removed Show link: {1}'.format(name, link))


@plugin.route('/playfirst/<url>')
def autoplay(url=''):
    if len(url) < 1:
        return None
    sourceslist = []
    litems = []
    idx = 0
    prefhost = ''
    html = ws.DL(url)
    selItem = None
    outtxt = "Not Found"
    thispath = plugin.url_for(endpoint=play, url=url)
    stext = plugin.get_setting('topSources')
    if len(stext) < 1:
        prefhost = 'thevideo'
    else:
        sourceslist = stext.split(',')
        prefhost = sourceslist[0]
    try:
        for fitem in plugin.added_items:
            if fitem.selected == True or fitem.path.find(thispath) != -1:
                try:
                    plugin.set_resolved_url(fitem)
                    fitem.is_playable(True)
                    fitem.played(True)
                except:
                    pass
                selItem = fitem
                plugin.notify(msg=selItem.label, title="Found item")
                break
    except:
        selItem = None
    if selItem is not None:
        try:
            selItem.set_is_playable(True)
            selItem.set_played(was_played=True)
            outtxt = selItem.label + " " + selItem.label2
        except:
            outtxt = str(repr(selItem))
    linklist = ws.findvidlinks(html, findhost=prefhost)
    if len(linklist) > 0:
        name, link = linklist[0]
        itempath = plugin.url_for(play, url=link)
        sitem = dict(label=name, label2=link, icon='DefaultFolder.png', thumbnail='DefaultFolder.png', path=itempath)
        sitem.setdefault(sitem.keys()[0])
        item = ListItem.from_dict(**sitem)
        item.set_is_playable(True)
        item.set_info(type='video', info_labels={'Title': item.label, 'Plot': item.label2})
        item.add_stream_info(stream_type='video', stream_values={})
        plugin.notify(msg=link, title=name)
        item.set_played(was_played=True)
        plugin.play_video(item)
        return [plugin.set_resolved_url(item)]


@plugin.route('/play/<url>')
def play(url):
    resolved = ''
    stream_url = ''
    item = None
    try:
        import urlresolver
        resolved = urlresolver.HostedMediaFile(url).resolve()
        if not resolved or resolved == False or len(resolved) < 1:
            resolved = urlresolver.resolve(url)
            if resolved is None or len(resolved) < 1:
                resolved = urlresolver.resolve(WebUtils.unescape(url))
        if len(resolved) > 1:
            plugin.notify(msg="PLAY {0}".format(resolved.partition('.')[-1]), title="URLRESOLVER", delay=1000)
            plugin.set_resolved_url(resolved)
            item = ListItem.from_dict(path=resolved)
            item.add_stream_info('video', stream_values={})
            item.set_is_playable(True)
            return item
    except:
        resolved = ''
        plugin.notify(msg="FAILED {0}".format(url.partition('.')[-1]), title="URLRESOLVER", delay=1000)
    try:
        import YDStreamExtractor
        info = YDStreamExtractor.getVideoInfo(url, resolve_redirects=True)
        resolved = info.streamURL()
        for s in info.streams():
            try:
                stream_url = s['xbmc_url'].encode('utf-8', 'ignore')
                xbmc.log(msg="**YOUTUBE-DL Stream found: {0}".format(stream_url))
            except:
                pass
        if len(stream_url) > 1:
            resolved = stream_url
        if len(resolved) > 1:
            plugin.notify(msg="Playing: {0}".format(resolved.partition('.')[-1]), title="YOUTUBE-DL", delay=1000)
            plugin.set_resolved_url(resolved)
            item = ListItem.from_dict(path=resolved)
            item.add_stream_info('video', stream_values={})
            item.set_is_playable(True)
            return item
    except:
        plugin.notify(msg="Failed: {0}".format(resolved.partition('.')[-1]), title="YOUTUBE-DL", delay=1000)

    if len(resolved) > 1:
        plugin.set_resolved_url(resolved)
        item = ListItem.from_dict(path=resolved)
        return item
    else:
        plugin.set_resolved_url(url)  # url)
        # plugurl = 'plugin://plugin.video.live.streamspro/?url={0}'.format(urllib.quote_plus(url))
        # item = ListItem.from_dict(path=plugurl)
        # item.add_stream_info('video', stream_values={})
        # item.set_is_playable(True)
        # plugin.notify(msg="RESOLVE FAIL: {0}".format(url.split('.', 1)[-1]),title="Trying {0}".format(item.path.split('.', 1)[-1]), delay=2000)
        return None


if __name__ == '__main__':    
    web_pdb.set_trace()
    viewmode = 0
    hostname = ''
    hostname = plugin.get_setting('setHostname')
    if len(hostname) > 1:
        hostname = hostname.strip()
        hostname = hostname.strip('/')
        if str(hostname).startswith('http'):
            __BASEURL__ = hostname
        else:
            __BASEURL__ = 'https://' + hostname
    ws.BASEURL = __BASEURL__
    ws.Plugin = plugin
    ws.Remove = removeshow
    ws.Episode = episode
    ws.Category = category
    ws.Save = saveshow
    ws.Autoplay = autoplay
    ws.Play = play
    #funcmaps = {'episode': episode, 'category': category, 'save': saveshow, 'autoplay': autoplay, 'play': play, 'remove': reemoveshow, 'search': search}
    #ws = WsolUtils(kodiplugin=plugin, **funcmaps)
    plugin.run()
    plugin.set_content('episodes')
    viewmode = plugin.get_setting('viewmode', converter=int)
    plugin.set_view_mode(view_mode_id=viewmode)
    #plugin.set_view_mode(plugin.get_setting('viewmode'))
