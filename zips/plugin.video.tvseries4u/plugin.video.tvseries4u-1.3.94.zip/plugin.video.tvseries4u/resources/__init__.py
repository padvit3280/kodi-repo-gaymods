from . import lib as Lib

#import imageio as imageio
#from lib import tv4u, webutil, simpleplugin
#import tv4u, webutil
#from tv4u import Tv4u
#from webutil import *
__API__ = Lib.tv4u.Tv4u()