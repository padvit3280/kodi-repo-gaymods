from . import pyNewtumbl

newtumbl = pyNewtumbl.newTumbl