
class BlogPost(object):

    def _init__(self):
        """
        : attribute szSource : string
        : attribute dwBlogIx : float
        : attribute dwBlogIxSubmit : float
        : attribute nCountComment : float
        : attribute dtActive : string
        : attribute dwBlogIxFrom : float
        : attribute dwBlogIxOrig : float
        : attribute bTier : float
        : attribute bStatus : float
        : attribute szExternal : string
        : attribute bRatingIx : float
        : attribute szURL : string
        : attribute bPostTypeIx : float
        : attribute dtLike : string
        : attribute qwPostIx : float
        : attribute nCountPost : float
        : attribute dwChecksum : float
        : attribute dtScheduled : string
        : attribute nCountLike : float
        : attribute qwPostIxFrom : float
        : attribute dtCreated : string
        : attribute dtFavorite : string
        : attribute nCountMark : float
        : attribute qwPostIxOrig : float
        : attribute bState : float
        """
        self.dtFlag = None
        self.szSource = None
        self.dwBlogIx = None
        self.dwBlogIxSubmit = None
        self.nCountComment = None
        self.dtActive = None
        self.dwBlogIxFrom = None
        self.dwBlogIxOrig = None
        self.bTier = None
        self.bStatus = None
        self.szExternal = None
        self.dtModified = None
        self.bRatingIx = None
        self.szURL = None
        self.bPostTypeIx = None
        self.dtLike = None
        self.qwPostIx = None
        self.nCountPost = None
        self.dwChecksum = None
        self.dtScheduled = None
        self.nCountLike = None
        self.qwPostIxFrom = None
        self.dtCreated = None
        self.dtFavorite = None
        self.nCountMark = None
        self.qwPostIxOrig = None
        self.bState = None
        self.dtDeleted = None

