#!/usr/bin/python

class Thumbnail_url:
	def __init__(self, type):
		self.type = type

