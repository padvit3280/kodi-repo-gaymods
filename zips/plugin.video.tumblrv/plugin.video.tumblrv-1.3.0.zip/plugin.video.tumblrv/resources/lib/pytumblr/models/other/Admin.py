#!/usr/bin/python

class Admin:
	def __init__(self, type):
		self.type = type

