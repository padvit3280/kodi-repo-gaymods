#!/usr/bin/python

class __value__:
	def __init__(self, audio):
		self.audio = audio

