#!/usr/bin/python

class Show_header_image:
	def __init__(self, type):
		self.type = type

