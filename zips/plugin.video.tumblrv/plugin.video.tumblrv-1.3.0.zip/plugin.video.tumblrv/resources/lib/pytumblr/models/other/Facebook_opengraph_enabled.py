#!/usr/bin/python

class Facebook_opengraph_enabled:
	def __init__(self, type):
		self.type = type

