#!/usr/bin/python

class Post:
	def __init__(self, id):
		self.id = id

