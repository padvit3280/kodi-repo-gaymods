#!/usr/bin/python

class Post_type:
	def __init__(self, __value__, __type__, __name__, __class__):
		self.__value__ = __value__
		self.__type__ = __type__
		self.__name__ = __name__
		self.__class__ = __class__

