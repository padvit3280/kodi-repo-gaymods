#!/usr/bin/python

class Reblog:
	def __init__(self, type, properties):
		self.type = type
		self.properties = properties

