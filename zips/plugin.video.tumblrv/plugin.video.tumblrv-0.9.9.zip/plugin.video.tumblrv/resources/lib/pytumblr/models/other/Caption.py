#!/usr/bin/python

class Caption:
	def __init__(self, type):
		self.type = type

