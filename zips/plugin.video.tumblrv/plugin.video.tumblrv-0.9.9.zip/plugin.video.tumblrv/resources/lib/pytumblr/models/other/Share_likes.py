#!/usr/bin/python

class Share_likes:
	def __init__(self, type):
		self.type = type

