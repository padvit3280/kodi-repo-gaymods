#!/usr/bin/python

class Total_posts:
	def __init__(self, type):
		self.type = type

