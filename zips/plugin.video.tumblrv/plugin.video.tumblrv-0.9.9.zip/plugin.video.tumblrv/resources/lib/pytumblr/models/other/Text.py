#!/usr/bin/python

class Text:
	def __init__(self, type):
		self.type = type

