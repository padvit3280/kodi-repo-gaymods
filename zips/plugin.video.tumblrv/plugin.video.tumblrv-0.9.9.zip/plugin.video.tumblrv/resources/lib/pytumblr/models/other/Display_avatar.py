#!/usr/bin/python

class Display_avatar:
	def __init__(self, type):
		self.type = type

