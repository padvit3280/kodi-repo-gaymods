#!/usr/bin/python

class Messages:
	def __init__(self, type):
		self.type = type

