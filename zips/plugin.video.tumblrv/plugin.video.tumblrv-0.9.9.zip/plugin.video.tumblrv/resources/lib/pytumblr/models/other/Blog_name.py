#!/usr/bin/python

class Blog_name:
	def __init__(self, type):
		self.type = type

