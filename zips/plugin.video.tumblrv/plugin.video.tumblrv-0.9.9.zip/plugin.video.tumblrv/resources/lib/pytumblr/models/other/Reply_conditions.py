#!/usr/bin/python

class Reply_conditions:
	def __init__(self, type):
		self.type = type

