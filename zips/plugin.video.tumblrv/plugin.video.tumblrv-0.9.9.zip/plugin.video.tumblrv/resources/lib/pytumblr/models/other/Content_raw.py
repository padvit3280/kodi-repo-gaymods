#!/usr/bin/python

class Content_raw:
	def __init__(self, type):
		self.type = type

