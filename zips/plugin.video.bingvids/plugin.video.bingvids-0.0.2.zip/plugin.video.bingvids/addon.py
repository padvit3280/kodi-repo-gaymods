# -*- coding: utf-8 -*-
from kodiswift import Plugin
#import xbmcswift2
#from xbmcswift2 import Plugin
from resources.lib import bingSearch
# https://api.cognitive.microsoft.com/bing/v7.0/videos
# Key 1: a2bbbe20b19543b9ab6dee3bac81d3da
# Key 2: 81988a7549c0424488a6fe87f48ddba9
plugin = Plugin()
APIKEY='81988a7549c0424488a6fe87f48ddba9'

@plugin.route('/')
def index():
    item = {
        'label': 'Bing Video Search!',
        'path': 'plugin://plugin.video.bingsearch/',
        'is_playable': True
    }
    litems = [item]
    searchq = "( aula | escuela | biblioteca | publico ) & ( novinho | chico | amigo | chavo | chavolito | hermano | cofrade ) -site:youtube.com"
    try:
        results = bingSearch("classroom wank")
        litems.append(results)
    except Exception as ex:
        plugin.notify(str(ex), "ERROR")
        print str(ex)
    return litems

def search():
    return None

if __name__ == '__main__':
    plugin.run()

