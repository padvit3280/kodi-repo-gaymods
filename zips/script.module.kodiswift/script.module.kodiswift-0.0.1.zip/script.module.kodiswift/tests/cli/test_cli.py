# -*- coding: utf-8 -*-
import unittest


class TestCLI(unittest.TestCase):
    pass
