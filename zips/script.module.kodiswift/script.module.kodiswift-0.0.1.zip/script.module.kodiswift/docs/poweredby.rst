.. _poweredby:


Addons Powered by kodiswift
===========================

Want your addon included here? Send me an email at web@jonathanbeluch.com with
your addon name and a link to a repository (Kodi's git repo is fine).

========================    =============================================================
Plugin                       Source
========================    =============================================================
`Academic Earth`_           https://github.com/jbeluch/xbmc-academic-earth
`Documentary.net`_          https://github.com/jbeluch/plugin.video.documentary.net
`VimCasts`_                 https://github.com/jbeluch/xbmc-vimcasts
`Radio`_                    https://github.com/dersphere/plugin.audio.radio_de
`Shoutcast 2`_              https://github.com/dersphere/plugin.audio.shoutcast
`Cheezburger Network`_      https://github.com/dersphere/plugin.image.cheezburger_network
`Apple Itunes Podcasts`_    https://github.com/dersphere/plugin.video.itunes_podcasts
`MyZen.tv`_                 https://github.com/dersphere/plugin.video.myzen_tv
`Rofl.to`_                  https://github.com/dersphere/plugin.video.rofl_to
`Wimp`_                     https://github.com/dersphere/plugin.video.wimp
========================    =============================================================

.. _Academic Earth: http://xbmcaddonbrowser.com/addons/frodo/plugin.video.academicearth/
.. _Documentary.net: http://xbmcaddonbrowser.com/addons/frodo/plugin.video.documentary.net/
.. _VimCasts: http://xbmcaddonbrowser.com/addons/frodo/plugin.video.vimcasts/
.. _Radio: http://xbmcaddonbrowser.com/addons/frodo/plugin.audio.radio_de/
.. _Shoutcast 2: http://xbmcaddonbrowser.com/addons/frodo/plugin.audio.shoutcast
.. _Cheezburger Network: http://xbmcaddonbrowser.com/addons/frodo/plugin.image.cheezburger_network
.. _Apple Itunes Podcasts: http://xbmcaddonbrowser.com/addons/frodo/plugin.video.itunes_podcasts
.. _MyZen.tv: http://xbmcaddonbrowser.com/addons/frodo/plugin.video.myzen_tv
.. _Rofl.to: http://xbmcaddonbrowser.com/addons/frodo/plugin.video.rofl_to
.. _Wimp: http://xbmcaddonbrowser.com/addons/frodo/plugin.video.wimp
