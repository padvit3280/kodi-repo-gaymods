Useful Links
============

* `Support thread on Kodi official forum`_
* `Example video plugin for Kodi based on SimplePlugin`_

.. _Support thread on Kodi official forum: http://forum.kodi.tv/showthread.php?tid=237532
.. _Example video plugin for Kodi based on SimplePlugin: https://github.com/romanvm/plugin.video.simpleplugin.example
