API Reference
=============

.. autosummary::
    :toctree: _autosummary

    simpleplugin
