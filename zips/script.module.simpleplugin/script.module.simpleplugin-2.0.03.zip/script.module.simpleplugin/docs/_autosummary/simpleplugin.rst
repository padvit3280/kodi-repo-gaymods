simpleplugin
============

.. automodule:: simpleplugin
   
   
   .. rubric:: Classes

   .. autosummary::
   
      Addon
      Params
      Plugin
      Storage
      MemStorage
   
   
   .. rubric:: Exceptions

   .. autosummary::
   
      SimplePluginError
