from kodiswift import xbmc, Plugin, xbmcaddon, xbmcmixin, xbmcgui, xbmcplugin, ListItem
from HTMLParser import HTMLParser
from os import path
import utils
from utils import escape, unescape, to_bytes, to_unicode, to_native, try_coerce_native, wsgi_get_bytes, wsgi_decoding_dance, wsgi_encoding_dance
import sys, os, re, json, operator, ssl
import urllib
import urlparse
import requests
import cookielib
import socket
import datetime, time
import random
import hashlib
import codecs

ssl._create_default_https_context = ssl._create_unverified_context


class WsolUtils(object):
    @property
    def Plugin(self):
        return self.plugin

    @Plugin.setter
    def Plugin(self, value):
        self.plugin = value

    @property
    def BASEURL(self):
        return self.__urlbase__

    @BASEURL.setter
    def BASEURL(self, value):
        self.__urlbase__ = value

    @property
    def addondir(self):
        return self.__addondir__

    @addondir.setter
    def addondir(self, value):
        self.__addondir__ = value

    @property
    def imgsearch(self):
        return self.__imgsearch__

    @imgsearch.setter
    def imgsearch(self, value):
        self.__imgsearch__ = value

    @property
    def savedpath(self):
        return self.__savedjson__

    @savedpath.setter
    def savedpath(self, value):
        self.__savedjson__ = value

    @property
    def datadir(self):
        return self.__datadir__

    @property
    def cookie(self):
        return self.__cookie__

    @property
    def temp(self):
        return self.__temp__

    @property
    def resdir(self):
        return self.__resdir__

    @property
    def Remove(self):
        return self.func_remove

    @Remove.setter
    def Remove(self, value):
        self.func_remove = (value)

    @property
    def Save(self):
        return self.func_save

    @Save.setter
    def Save(self, value):
        self.func_save = (value)

    @property
    def Category(self):
        return self.func_category

    @Category.setter
    def Category(self, value):
        self.func_category = (value)

    @property
    def Play(self):
        return self.func_play

    @Play.setter
    def Play(self, value):
        self.func_play = (value)

    @property
    def Autoplay(self):
        return self.func_autoplay

    @Autoplay.setter
    def Autoplay(self, value):
        self.func_autoplay = (value)

    @property
    def Episode(self):
        return self.func_ep

    @Episode.setter
    def Episode(self, value):
        self.func_ep = value

    def __init__(self, kodiplugin, **kwargs):
        self.plugin = kodiplugin
        self.__urlbase__ = to_native('https://watchseries-online.pl')
        self.__addondir__ = xbmc.translatePath(self.plugin.addon.getAddonInfo('path'))
        self.__datadir__ = path.join(xbmc.translatePath('special://profile/'), 'addon_data/', self.plugin.id)
        self.__cookie__ = path.join(self.__datadir__, 'cookies.lwp')  # path.join(__datadir__, 'cookies.lwp')
        self.__temp__ = path.join(self.__datadir__, 'temp/')
        self.__resdir__ = path.join(self.__addondir__, 'resources')
        self.__imgsearch__ = path.join(self.__resdir__, 'search.png')
        self.__savedjson__ = path.join(xbmc.translatePath(self.plugin.addon.getAddonInfo('profile')), 'saved.json')
        self.getWeb = CachedWebRequest(self.__cookie__, self.__temp__)
        self.func_category = None
        self.func_ep = None
        self.func_play = None
        self.func_autoplay = None
        self.func_save = None
        self.func_remove = None
        for key, pluginfunction in kwargs.items():
            name = key.lower()
            if 'episode' in name:
                self.func_ep = (pluginfunction)
            elif 'autoplay' in name:
                self.func_autoplay = (pluginfunction)
            elif 'category' in name:
                self.func_category = (pluginfunction)
            elif 'save' in name:
                self.func_save = (pluginfunction)
            elif 'remove' in name:
                self.func_remove = (pluginfunction)
            elif name == 'play':
                self.func_play = (pluginfunction)

    def DL_nocheck(self, url):
        html = u''
        getWeb = CachedWebRequest(self.cookie, self.temp)
        html = getWeb.getSource(url, form_data=None, referer=self.BASEURL, xml=False, mobile=False, ignoreCache=False,
                                demystify=True).encode('latin',
                                                                                                           errors='ignore')
        return html

    def DL(self, url):
        html = u''
        getWeb = CachedWebRequest(self.cookie, self.temp)
        try:
            html = to_unicode(self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False, ignoreCache=False, demystify=True).encode('latin', errors='ignore'))
        except:
            try:
                html = wsgi_decoding_dance(
                    self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False))
            except:
                html = wsgi_encoding_dance(self.getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False))
        try:
            if html is None or len(html) < 1:
                html = try_coerce_native(getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False,
                                                          mobile=False))  # .encode('latin', errors='ignore')
        except:
            return getWeb.getSource(url=url, form_data="", referer=self.BASEURL, xml=False, mobile=False).encode(
                'latin', errors='ignore')
        return html

    def makecatitem(self, name, link, removelink=False):
        item = {}
        ctxitem = {}
        itempath = self.plugin.url_for('category', name=name, url=link)
        if self.plugin.get_setting('playold', converter=bool):
            itempath = itempath.replace("plugin.video.watchseries/", "plugin.video.wsonline/")

        item = {'label': name, 'label2': link, 'icon': 'DefaultFolder.png', 'thumbnail': 'DefaultFolder.png',
                'path': itempath}
        item.setdefault(item.keys()[0])
        litem = ListItem.from_dict(**item)
        #litem.add_context_menu_items([('Save Show', 'RunPlugin("{0}")'.format(self.plugin.url_for(self.Save, name=name, link=link))), ])
        return litem

    def episode_makeitem(self, episodename, episodelink, dateadded=None):
        '''
        Will return a ListItem for the given link to an episode and it's full linked name.
        Name will be sent to format show to attempt to parse out a date or season from the title.
        Infolabels are populated with any details that can be parsed from the title as well.
        Should be used anytime an item needs to be created that is an item for one specific episode of a show.
        Latest 350, Saved Show, Category (Show listing of all episodes for that series) would all use this.
        '''
        infolbl = {}
        spath = self.plugin.url_for(self.Episode, name=episodename, url=episodelink)
        img = "DefaultVideoFolder.png"
        seasonstr = ''
        try:
            eptitle, epdate, epnum = self.formatshow(episodename)
            eplbl = self.formatlabel(eptitle, epdate, epnum)
            plotstr = "{0} ({1}): {2} {3}".format(epdate, epnum, eptitle, episodelink)
            infolbl = {'EpisodeName': epdate, 'Title': eptitle, 'Plot': plotstr}
            if len(epnum) > 0:
                showS, showE = self.findepseason(epnum)
                snum = int(showS)
                epnum = int(showE)
                infolbl.update({'Episode': showE, 'Season': showS})
                if snum > 0 and epnum > 0:
                    epdate = "S{0}e{1}".format(snum, epnum)
                    infolbl.update({'PlotOutline': epdate})
            if dateadded is not None:
                dateout = str(dateadded.replace(' ', '-')).strip()
                infolbl.update({"Date": dateout})
            item = {'label': eplbl, 'label2': epdate, 'icon': img, 'thumbnail': img, 'path': spath}
            item.setdefault(item.keys()[0])
            li = ListItem.from_dict(**item)
            li.set_is_playable(is_playable=True)
            li.is_folder = True
            li.set_info(type='video', info_labels=infolbl)
            li.add_context_menu_items(
                [('Autoplay', 'RunPlugin("{0}")'.format(self.plugin.url_for(self.Autoplay, urllib=episodelink))), ])
        except:
            li = ListItem(label=episodename, label2=episodelink, icon=img, thumbnail=img, path=spath)
        return li

    def formatshow(self, name=""):
        epname = name.replace('&#8211;', '-')
        epnum = ''
        epname = ''
        epdate = ''
        numparts = re.compile(r'[Ss]\d+[Ee]\d+').findall(name)
        if len(numparts) > 0:
            epnum = numparts.pop()
        datematch = re.compile(r'[12][0-9][0-9][0-9].[0-9][0-9]?.[0-9][0-9]?').findall(name)
        if len(datematch) > 0:
            epdate = datematch[0]
        name = name.replace('  ', ' ').strip()
        name = name.replace(epnum, '').strip()
        name = name.replace(epdate, '').strip()
        if epdate == '':
            # Let's see if we can find the date in the form of a string of Month_Abbr Daynum Year
            try:
                from calendar import month_abbr, month_name
                monthlist = month_name[:]
                monthlist.extend(month_abbr)
                monthlist.pop(13)
                monthlist.pop(0)
                regex = "{0}.(\d\d).(\d\d\d\d)"
                nummonth = 1
                for mon in monthlist:
                    matches = re.compile(regex.format(mon)).findall(name)
                    if len(matches) > 0:
                        day, year = matches.pop()
                        if nummonth < 10:
                            epdate = "{0} 0{1} {2}".format(year, nummonth, day)
                        else:
                            epdate = "{0} {1} {2}".format(year, nummonth, day)
                        name = name.replace(mon, '').strip()
                        name = name.replace(year, '').strip()
                        name = name.replace(day, '').strip()
                        break
                    nummonth += 1
                    if nummonth > 12: nummonth = 1
                if epdate == '':
                    year = re.split(r'\d\d\d\d', name, 1)[0]
                    epdate = name.replace(year, '').strip()
                    name = name.replace(epdate, '').strip()
            except:
                pass
        epname = name.replace('(', '').replace(')', '').strip()
        epdate = epdate.replace('(', '').replace(')', '').strip()
        epnum = epnum.replace('(', '').replace(')', '').strip()
        return epname.strip(), epdate.strip(), epnum.strip()

    def formatlabel(self, epname, epdate, epnum):
        eplbl = ''
        epname = epname.replace('!', '')
        try:
            if len(epdate) == 0 and len(epnum) == 0:
                return epname
            else:
                if len(epdate) > 0 and len(epnum) > 0:
                    eplbl = "{0} ([COLOR blue]{1}[/COLOR] [COLOR cyan]{2}[/COLOR])".format(epname, epdate, epnum)
                else:
                    if len(epdate) > 0:
                        eplbl = "{0} ([COLOR blue]{1}[/COLOR])".format(epname, epdate)
                    else:
                        eplbl = "{0} ([COLOR cyan]{1}[/COLOR])".format(epname, epnum)
        except:
            eplbl = epname + ' ' + epdate + ' ' + epnum
        return eplbl

    def findepseason(self, epnum):
        numseason = ''
        numep = ''
        parts = epnum.lower().split('e', 1)
        numseason = parts[0].replace('s', '').strip()
        numep = parts[-1].replace('e', '').strip()
        return numseason, numep

    def filterout(self, text, filtertxt=''):
        filterwords = []
        if len(filtertxt) < 1:
            return False
        if filtertxt.find(',') != -1:
            filterwords = filtertxt.lower().split(',')
        else:
            return False
        if text.lower() in filterwords:
            return True
        return False

    def find_episodes(self, fullhtml='', noDate=False):
        html = fullhtml.partition(u'</nav>')[-1].split(u'</ul>', 1)[0]
        strDate = r"<li class='listEpisode'>(\d+ \d+ \d+) : "
        strUrl = r'<a.+?href="([^"]*?)">'
        strName = r"</span>([^<]*?)</a>"
        regexstr = r"{0}{1}.+?{2}".format(strDate, strUrl, strName)
        if noDate:
            regexstr = "{0}.+?{1}".format(strUrl, strName)
        matches = re.compile(regexstr).findall(html)
        epdate = ''
        eptitle = ''
        litems = []
        if noDate:
            for eplink, epname in matches:
                item = self.episode_makeitem(episodename=epname, episodelink=eplink)  # episode_makeitem(epname, eplink)
                # item.set_path(self.plugin
                litems.append(item)
        else:
            for epdate, eplink, epname in matches:
                item = self.episode_makeitem(epname, eplink, epdate)
                # item.set_path(self.plugin
                dateout = epdate.replace(' ', '-').strip()
                item.label += " [I][B][COLOR orange]{0}[/COLOR][/B][/I]".format(dateout)
                litems.append(item)
        return litems

    def findvidlinks(self, html='', findhost=None):
        matches = re.compile(ur'<div class="play-btn">.*?</div>', re.DOTALL).findall(html)
        vids = []
        if findhost is not None:
            findhost = findhost.lower()
        for link in matches:
            url = re.compile(ur'href="(.+)">', re.DOTALL + re.S).findall(str(link))[0]
            if url is not None:
                host = str(url.lower().split('://', 1)[-1])
                host = host.replace('www.', '')
                host = str(host.split('.', 1)[0]).title()
                label = "{0} [COLOR blue]{1}[/COLOR]".format(host, url.rpartition('/')[-1])
                vids.append((label, url,))
                if findhost is not None:
                    if url.lower().find(findhost) != -1:
                        return [(label, url,)]
        return vids

    def sortSourceItems(self, litems=[]):
        try:
            litems.sort(key=lambda litems: litems['label'], reverse=False)
            sourceslist = []
            stext = self.plugin.get_setting('topSources')
            if len(stext) < 1:
                sourceslist.append('thevideo')
                sourceslist.append('movpod')
                sourceslist.append('daclip')
            else:
                sourceslist = stext.split(',')
            sorteditems = []
            for sortsource in sourceslist:
                for item in litems:
                    if str(item['label2']).find(sortsource) != -1: sorteditems.append(item)
            for item in sorteditems:
                try:
                    litems.remove(item)
                except:
                    pass
            sorteditems.extend(litems)
            return sorteditems
        except:
            self.plugin.notify(msg="ERROR SORTING: #{0}".format(str(len(litems))), title="Source Sorting", delay=20000)
            return litems

    def loadsaved(self):
        sitems = []
        litems = []
        items = []
        savedpath = ''
        try:
            if not path.exists(self.savedpath):
                self.savedpath = path.join(self.datadir, "saved.json")
            if path.exists(self.savedpath):
                fpin = file(self.savedpath)
                rawjson = fpin.read()
                sitems = json.loads(rawjson)
                fpin.close()
            else:
                return []
            for item in sitems:
                li = ListItem.from_dict(**item)
                li.add_context_menu_items(
                    [('Remove Saved Show',
                      'RunPlugin("{0}")'.format(self.plugin.url_for(self.Remove, name=li.label, link=li.label2))), ])
                litems.append(li)
        except:
            pass
        return litems

    def query(self, searchquery):
        if len(searchquery) > 0:
            searchquery = unescape(searchquery)  # .replace(' ', '+')
        urlsearch = self.BASEURL + '/?s={0}&search='.format(escape(searchquery))
        fullhtml = self.DL(urlsearch)
        html = fullhtml
        htmlres = html.partition('<div class="ddmcc">')[2].split('</div>', 1)[0]
        matches = re.compile(ur'href="(https?.+?watchseries-online\.[a-z]+/category.+?[^"])".+?[^>]>(.+?[^<])<.a>').findall(htmlres)
        litems = []
        for slink, sname in matches:
            litems.append(self.makecatitem(sname, slink))
        return litems

    def episode_makeitem(self, urlep):
        fullhtml = self.DL(urlep)
        html = fullhtml.partition("</nav>")[-1].split("</ul>", 1)[0]
        strDate = ur"<li class='listEpisode'>(\d+ \d+ \d+) : "
        strUrl = ur'<a.+?href="([^"]*?)">'
        strName = ur'</span>([^<]*?)</a>'
        regexstr = "{0}{1}.+?{2}".format(strDate, strUrl, strName)
        matches = re.compile(regexstr).findall(html)
        epdate = ''
        eptitle = ''
        litems = []
        for epdate, eplink, epname in matches:
            item = self.episode_makeitem(epname, eplink, epdate)
            item.path = self.plugin.url_for(self.Episode, name=epname, url=eplink)
            dateout = epdate.replace(' ', '-').strip()
            item.label += " [I][B][COLOR orange]{0}[/COLOR][/B][/I]".format(dateout)
            litems.append(item)
        #self.plugin.notify(msg="Search {0}".format(urlsearch), title="{0} {1}".format(str(len(litems)), searchquery))
        return litems


    def category_episodemake(self, episodename, episodelink, dateadded=None):
        '''
        Will return a ListItem for the given link to an episode and it's full linked name.
        Name will be sent to format show to attempt to parse out a date or season from the title.
        Infolabels are populated with any details that can be parsed from the title as well.
        Should be used anytime an item needs to be created that is an item for one specific episode of a show.
        Latest 350, Saved Show, Category (Show listing of all episodes for that series) would all use this.
        '''
        infolbl = {}
        spath = self.Plugin.url_for('episode', name=episodename, url=episodelink)
        if self.Plugin.get_setting('playold', converter=bool):
            spath = spath.replace("plugin.video.watchseries/", "plugin.video.wsonline/")
        img = "DefaultVideoFolder.png"
        seasonstr = ''
        try:
            eptitle, epdate, epnum = self.formatshow(episodename)
            eplbl = self.formatlabel(eptitle, epdate, epnum)
            plotstr = "{0} ({1}): {2} {3}".format(epdate, epnum, eptitle, episodelink)
            infolbl = {'EpisodeName': epdate, 'Title': eptitle, 'Plot': plotstr}
            if len(epnum) > 0:
                showS, showE = self.findepseason(epnum)
                snum = int(showS)
                epnum = int(showE)
                infolbl.update({'Episode': showE, 'Season': showS})
                if snum > 0 and epnum > 0:
                    epdate = "S{0}e{1}".format(snum, epnum)
                    infolbl.update({'PlotOutline': epdate})
            if dateadded is not None:
                dateout = str(dateadded.replace(' ', '-')).strip()
                infolbl.update({"Date": dateout})
            item = {'label': eplbl, 'label2': epdate, 'icon': img, 'thumbnail': img, 'path': spath}
            item.setdefault(item.keys()[0])
            li = ListItem.from_dict(**item)
            li.set_is_playable(is_playable=True)
            li.is_folder = True
            li.set_info(type='video', info_labels=infolbl)
            li.add_context_menu_items(
                [('Autoplay', 'RunPlugin("{0}")'.format(self.Plugin.url_for(endpoint='playfirst', url=episodelink)),)])
        except:
            li = ListItem(label=episodename, label2=episodelink, icon=img, thumbnail=img, path=spath)
        return li


class FileUtils(object):
    """docstring for FileUtils - File Helpers"""

    def fileExists(self, filename):
        return os.path.isfile(filename)

    def getFileExtension(self, filename):
        ext_pos = filename.rfind('.')
        if ext_pos != -1:
            return filename[ext_pos + 1:]
        else:
            return ''

    def get_immediate_subdirectories(self, directory):
        return [name for name in os.listdir(directory)
                if os.path.isdir(os.path.join(directory, name))]

    def findInSubdirectory(self, filename, subdirectory=''):
        if subdirectory:
            path = subdirectory
        else:
            path = os.getcwd()
        for root, _, names in os.walk(path):
            if filename in names:
                return os.path.join(root, filename)
        raise 'File not found'

    def cleanFilename(self, s):
        if not s:
            return ''
        badchars = '\\/:*?\"<>|'
        for c in badchars:
            s = s.replace(c, '')
        return s;

    def randomFilename(self, directory, chars='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
                       length=8, prefix='', suffix='', attempts=10000):
        for _ in range(attempts):
            filename = ''.join([random.choice(chars) for _ in range(length)])
            filename = prefix + filename + suffix
            if not os.path.exists(os.path.join(directory, filename)):
                return filename
        return None

    def getFileContent(self, filename):
        try:
            f = codecs.open(filename, 'r', 'utf-8')
            txt = f.read()
            f.close()
            return txt
        except:
            return ''

    def setFileContent(self, filename, txt, createFolders=False):
        try:
            if createFolders:
                folderPath = os.path.dirname(filename)
                if not os.path.exists(folderPath):
                    os.makedirs(folderPath, 0777)

            f = codecs.open(filename, 'w', 'utf-8')
            f.write(txt)
            f.close()
            return True
        except:
            return False

    def appendFileContent(self, filename, txt):
        try:
            f = codecs.open(filename, 'a', 'utf-8')
            f.write(txt)
            f.close()
            return True
        except:
            return False

    def md5(self, fileName, excludeLine="", includeLine=""):
        """Compute md5 hash of the specified file"""
        m = hashlib.md5()
        try:
            fd = codecs.open(fileName, "rb", 'utf-8')
        except IOError:
            print "Unable to open the file in readmode:", fileName
            return
        content = fd.readlines()
        fd.close()
        for eachLine in content:
            if excludeLine and eachLine.startswith(excludeLine):
                continue
            m.update(eachLine)
        m.update(includeLine)
        return m.hexdigest()

    def lastModifiedAt(self, path):
        return datetime.datetime.utcfromtimestamp(os.path.getmtime(path))

    def setLastModifiedAt(self, path, date):
        try:
            stinfo = os.stat(path)
            atime = stinfo.st_atime
            mtime = int(time.mktime(date.timetuple()))
            os.utime(path, (atime, mtime))
            return True
        except:
            pass

        return False

    def clearDirectory(self, path):
        try:
            for root, _, files in os.walk(path, topdown=False):
                for name in files:
                    os.remove(os.path.join(root, name))
        except:
            return False

        return True

    def GetHashofDirs(self, directory, verbose=0):

        SHAhash = hashlib.sha1()
        if not os.path.exists(directory):
            return -1

        try:
            for root, _, files in os.walk(directory):
                for names in files:
                    if verbose == 1:
                        print 'Hashing', names
                    filepath = os.path.join(root, names)
                    try:
                        f1 = codecs.open(filepath, 'rb', 'utf-8')
                    except:
                        # You can't open the file for some reason
                        f1.close()
                        continue

            while 1:
                # Read file in as little chunks
                buf = f1.read(4096)
                if not buf:
                    break
                SHAhash.update(hashlib.sha1(buf).hexdigest())
                f1.close()

        except:
            import traceback
            # Print the stack traceback
            traceback.print_exc()
            return -2
        # GetHashofDirs - http://akiscode.com/articles/sha-1directoryhash.shtml
        # Copyright (c) 2009 Stephen Akiki
        # MIT License (Means you can do whatever you want with this)
        #  See http://www.opensource.org/licenses/mit-license.php
        return SHAhash.hexdigest()


class BaseRequest(object):
    ''' HTTP REQUEST HELPER cooking handling, call BaseRequest.getSource(url,form_data,referer) '''

    def __init__(self, cookie_file=None):
        self._regex = r'<a href="([^"]*)".*?<img.+src="([^"]*)".+alt="([^"]*)".+?>.*?/a>'
        self._fileUtils = FileUtils()
        self.fileExists = self._fileUtils.fileExists
        self.setFileContent = self._fileUtils.setFileContent
        self.getFileContent = self._fileUtils.getFileContent
        self.cookietemplate = '#LWP-Cookies-2.0'
        if cookie_file is None:
            cookie_file = 'cookies.lwp'
            self.setFileContent(cookie_file, self.cookietemplate)
        self.cookie_file = cookie_file
        self.s = requests.Session()
        if self.fileExists(self.cookie_file):
            self.s.cookies = self.load_cookies_from_lwp(self.cookie_file)
        self.s.headers.update({
                                  'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36'})
        self.s.headers.update({'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'})
        self.s.headers.update({'Accept-Language': 'en-US,en;q=0.5'})
        self.s.keep_alive = False
        self.url = ''

    def save_cookies_lwp(self, cookiejar, filename):
        lwp_cookiejar = cookielib.LWPCookieJar()
        for c in cookiejar:
            args = dict(vars(c).items())
            args['rest'] = args['_rest']
            del args['_rest']
            c = cookielib.Cookie(**args)
            lwp_cookiejar.set_cookie(c)
        lwp_cookiejar.save(filename, ignore_discard=True)

    def load_cookies_from_lwp(self, filename):
        lwp_cookiejar = cookielib.LWPCookieJar()
        lwp_cookiejar.load(filename, ignore_discard=True)
        return lwp_cookiejar

    def fixurl(self, url):
        # url is unicode (quoted or unquoted)
        try:
            # url is already quoted
            url = url.encode('ascii')
        except:
            # quote url if it is unicode
            parsed_link = urlparse.urlsplit(url)
            parsed_link = parsed_link._replace(netloc=parsed_link.netloc.encode('idna'),
                                               path=urllib.quote(parsed_link.path.encode('utf-8')))
            url = parsed_link.geturl().encode('ascii')
        # url is str (quoted)
        self.url = url
        return url

    def getSource(self, url, form_data="", referer="", xml=False, mobile=False):
        url = self.fixurl(url)
        if len(referer) < 1 or referer is None:
            referer = 'http://' + urlparse.urlsplit(url).hostname
        if 'arenavision.in' in urlparse.urlsplit(url).netloc:
            self.s.headers.update({'Cookie': 'beget=begetok'})
        if 'pushpublish' in urlparse.urlsplit(url).netloc:
            del self.s.headers['Accept-Encoding']

        if not referer:
            referer = url
        else:
            referer = self.fixurl(referer)

        headers = {'Referer': referer}
        if mobile:
            self.s.headers.update({
                                      'User-Agent': 'Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'})

        if xml:
            headers['X-Requested-With'] = 'XMLHttpRequest'

        if form_data:
            r = self.s.post(url, headers=headers, data=form_data, timeout=20)
            response = r.text
        else:
            try:
                r = self.s.get(url, headers=headers, timeout=20)
                response = r.text
            except (requests.exceptions.MissingSchema):
                response = 'pass'

        if len(response) > 10:
            if self.cookie_file:
                self.save_cookies_lwp(self.s.cookies, self.cookie_file)
        return HTMLParser().unescape(response)

    def getThumbs(self, url, regex=""):
        html = self.getSource(url)
        iregex = ur'[(<p)|(<div)|(<span)](.*?href=.*?<img.*?[(</a)|(</p)|(</div)|(</span)].+[^>])'
        if regex == "": regex = self._regex
        matches = re.compile(regex, re.IGNORECASE + re.DOTALL + re.MULTILINE + re.UNICODE).findall(html)
        vblocks = re.compile(iregex, re.IGNORECASE + re.DOTALL + re.MULTILINE + re.UNICODE).findall(html)
        allmatches = []
        if vblocks is None:
            matchresult = dict(html=html, videos={}, matches=matches)
            matchresult.setdefault(matchresult.keys()[0])
            return matchresult
        else:
            listvids = []
            for vid in vblocks:
                vmatch = re.compile(ur'href="([^"]+)".*?src="([^"]+)".+?alt="([^"]+)"',
                                    re.IGNORECASE + re.DOTALL + re.MULTILINE + re.UNICODE).findall(vid)
                if vmatch is not None:
                    vids = []
                    for m1, m2, m3 in vmatch:
                        link = m1
                        img = m2
                        text = m3
                        dictvid = dict(url=link, thumb=img, label=text)
                        dictvid.setdefault(dictvid.keys()[0])
                        vids.append(dictvid)
                    listvids.extend(vids)
            matchresult = dict(html=html, videos=self._cleanlist(listvids))  # , matches=vblocks)
            matchresult.setdefault(matchresult.keys()[0])
            return matchresult
        return html

    def _cleanlist(self, listvids):
        resultlist = []
        for vid in listvids:
            assert isinstance(vid, dict)
            vid.setdefault(vid.keys()[0])
            url = str(vid.get('url'))
            thumb = str(vid.get('thumb'))
            label = str(vid.get('label'))
            upr = urlparse.urlparse(self.url)
            vbase = upr.scheme + '://' + upr.netloc + '/'
            if not url.startswith('http'):
                url = urlparse.urlparse(vbase + url.lstrip('/')).geturl()
            if not thumb.startswith('http'):
                thumb = urlparse.urlparse(vbase + thumb.lstrip('/')).geturl()
            if thumb.endswith('.jpg') or thumb.endswith('.png') or thumb.endswith('.jpeg'):
                newvid = dict(url=url, thumb=thumb, label=label)
                newvid.setdefault(newvid.keys()[0])
                resultlist.append(newvid)
        return resultlist


# ------------------------------------------------------------------------------
class DemystifiedWebRequest(BaseRequest):
    def __init__(self, cookiePath):
        super(DemystifiedWebRequest, self).__init__(cookiePath)

    def getSource(self, url, form_data, referer='', xml=False, mobile=False, demystify=False):
        data = super(DemystifiedWebRequest, self).getSource(url, form_data, referer, xml, mobile)
        if not data:
            return None

        if not demystify:
            # remove comments
            r = re.compile('<!--.*?(?!//)--!*>', re.IGNORECASE + re.DOTALL + re.MULTILINE)
            m = r.findall(data)
            if m:
                for comment in m:
                    data = data.replace(comment, '')
        else:
            import decryptionUtils as crypt
            data = crypt.doDemystify(data)

        return data


# ------------------------------------------------------------------------------

class CachedWebRequest(DemystifiedWebRequest):
    def __init__(self, cookiePath, cachePath):
        super(CachedWebRequest, self).__init__(cookiePath)
        self._fileUtils = FileUtils()
        self.cachePath = cachePath
        self.cachedSourcePath = os.path.join(self.cachePath, 'page.html')
        self.currentUrlPath = os.path.join(self.cachePath, 'currenturl')
        self.lastUrlPath = os.path.join(self.cachePath, 'lasturl')

    def __setLastUrl(self, url):
        self._fileUtils.setFileContent(self.lastUrlPath, url)

    def __getCachedSource(self):
        try:
            data = self._fileUtils.getFileContent(self.cachedSourcePath)
        except:
            pass
        return data

    def getLastUrl(self):
        return self._fileUtils.getFileContent(self.lastUrlPath)

    def getSource(self, url, form_data, referer='', xml=False, mobile=False, ignoreCache=False, demystify=False):

        if url == self.getLastUrl() and not ignoreCache:
            data = self.__getCachedSource()
        else:
            data = super(CachedWebRequest, self).getSource(url, form_data, referer, xml, mobile, demystify)
            if data:
                # Cache url
                self.__setLastUrl(url)
                # Cache page
                self._fileUtils.setFileContent(self.cachedSourcePath, data)
        return data
