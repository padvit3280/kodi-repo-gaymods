import urlquick
import json
import hashlib
import re
import os
import nTobjects as nTobj
from collections import namedtuple

media = namedtuple("media", ['VIDEO', 'PHOTO', 'ALL'])(*[7,5,0])

class newTumbl():
    '''
    API Methods
    ["get_Blog_Marquee",
    "search_Site_Blogs",
    "search_Site_Posts",
    "search_Dash_Activity",
    "search_Dash_Posts",
    "search_Blog_Posts",
    "search_User_Posts_Like",
    "search_User_Posts_Favorite",
    "search_Post_Notes"]
    '''
    BASEURL = "https://api-ro.newtumbl.com/sp/NewTumbl/"
    headerdict = {'Host': 'api-ro.newtumbl.com',
                  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:69.0) Gecko/20100101 Firefox/69.0',
                  'Accept': '*/*', 'Accept-Language': 'en-US,en;q=0.5', 'Accept-Encoding': 'gzip, deflate, br',
                  'Referer': 'https://newtumbl.com/tagged/twink',
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Pragma': 'no-cache',
                  'Cache-Control': 'no-cache', 'Origin': 'https://newtumbl.com'}

    def __init__(self, datadir=''):
        if datadir == '':
            datadir = os.path.join(os.path.abspath(os.path.expanduser("~")), '.kodi/temp')
        if os.path.exists(datadir) and os.path.isdir(datadir):
            urlquick.CACHE_LOCATION = datadir
        else:
            try:
                os.mkdir(datadir)
            except:
                print("Could not find data directory or create it: " + datadir)
        self.results = None


    def base32path(self, imgpath="", **kwargs):
        '''
        Parameters:
        BlogID
        PostID
        PartID
        MediaID
        or imgpath in form of imgpath="/blogid/postid/partid/mediaid" or as much as imgpath="https://dn0.newtumbl.com/img/blogid/postid/partid/mediaid/nT_"
        blogid=265936 postid=6180659 partid=1 mediaID=9257871
        Returns:
        URL to image in format of:
        https://dn0.newtumbl.com/img/{BlogID}/{PostID}/{PartID}/{MediaID}/nT_{Base32(SHA256("/{blogid}/{postid}/{partid}/{mediaid}/nT_"))}.jpg
        Example: https://dn0.newtumbl.com/img/265936/6180659/1/9257871/nT_bjkrnkq6tjk8j62a05hrzks0.jpg
        '''
        ids = dict(blogid=0, postid=0, partid=0, mediaid=0)
        ids.update(**kwargs)
        if kwargs.has_key('qwMediaIx'):
            blogid = kwargs.get('dwBlogIx', kwargs.get('dwBlogIx_From', kwargs.get('dwBlogIx_Orig', kwargs.get('dwBlogIx_Submit'))))
            ids = {'mediaid': ids.get('qwMediaIx', ''), 'partid': ids.get('nPartIz', ''), 'postid': ids.get('qwPostIx',''), 'blogid': blogid}
        sMap = "abcdefghijknpqrstuvxyz0123456789"
        sOutput = ""
        i = -1
        b = 0
        c = 0
        d = None
        shalist = []
        abInput = []
        BASEIMGURL = "https://dn0.newtumbl.com/img"
        if imgpath is not "":
            try:
                if imgpath.startswith('http') or imgpath.find('img/') != -1:
                    ids['blogid'],ids['postid'],ids['partid'],ids['mediaid'] = imgpath.split('img/',1)[-1].rpartition('/nT_')[0].split('/',4)
                else:
                    if not imgpath.startswith('/'):
                        imgpath = "/" + imgpath
                    if not imgpath.endswith('/') and not imgpath.endswith('nT_'):
                        imgpath = imgpath + '/nT_'
                    if not imgpath.endswith('nT_'):
                        imgpath = imgpath + 'nT_'
                    imgpath = imgpath.replace('/nT_', '').replace('/nT','')
                    ids['blogid'],ids['postid'],ids['partid'],ids['mediaid'] = imgpath.partition('/')[-1].strip('/').split('/',4)
            except:
                return None
        sPath = "/" + str(ids['blogid']) + "/" + str(ids['postid']) + "/" + str(ids['partid']) + "/" + str(ids['mediaid']) + "/nT_"
        sha = hashlib.sha256(sPath)
        hexdigest = sha.hexdigest()
        for t in range(0,len(hexdigest),2): shalist.append(hexdigest[t:t+2])
        for num in shalist: abInput.append(int(num,16))
        # Based on Base32 Javascript method from newtumbl original function runs on a WordArray of 16 pairs of HEX digits returned from SHA256
        # https://newtumbl.com/v1.6.22/js/common.js
        while (i < len(abInput) or b > 0):
            if b < 5:
                i = i+1
                if i < len(abInput):
                    c = (c << 8) + int(abInput[i])
                    b += 8
            d = c % 32
            c = c >> 5
            b = b - 5
            sOutput += sMap[d]
        sOutput = sOutput[0:24]
        imgurl = BASEIMGURL + sPath + sOutput + ".jpg"
        return imgurl


    def getDashPosts(self):
        litems = []
        dashitems = []
        apiurl = self.BASEURL + "search_Dash_Posts"
        reqdata = 'json=%7B%22Params%22%3A%5B%22%5B%7BIPADDRESS%7D%5D%22%2C%22FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I%22%2C391932%2Cnull%2Cnull%2C0%2C25%2C0%2Cnull%2C0%2C%22%22%2C0%2C0%2C0%2C0%2C0%2Cnull%2Cnull%5D%7D'
        resp = urlquick.post(url=apiurl, data=reqdata, headers=self.headerdict)
        dashresult = resp.json().get('aResultSet', [])
        if len(dashresult) > 1:
            dashdict = dashresult[2].get('aRow', [])[0]
            apost = Post(**dashdict)
            dashitems.append(apost)
        else:
            return None
        for post in dashitems:
            thumb = self.base32path(**post.__dict__)
            label = post.szTitle
            label2 = post.szDescription
            if post.szBody is not None:
                label = label + "\n" + post.szBody
            else:
                label = label + "\n" + label2
            label2 += "\nhttp://" + post.szBlogId + ".newtumbl.com/"
            litem = {'label': label, 'label2': label2, 'thumb': thumb, 'icon': thumb, 'url': 'http://newtumbl.com/post/'}
            litems.append(litem)
        return litems


    def getBlog(self, blogid=0):
        apiurlblog = self.BASEURL + "get_Blog_Marquee"
        blogreqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,' + str(blogid) + ']}'
        resp = urlquick.post(url=apiurlblog, data=blogreqdata, headers=self.headerdict)
        #resp = urlquick.request(method="POST", url=apiurlblog, data=blogreqdata, headers=self.headerdict)
        blogresult = resp.json().get('aResultSet', [])
        if len(blogresult) > 1:
            blogdict = blogresult[2].get('aRow', [])[0]
            ablog = Blog(**blogdict)
            return ablog
        else:
            return None


    def getVidsTag(self, tagname=""):
        apiurl = self.BASEURL+"search_Site_Posts"
        litems = []
        reqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,null,null,0,50,0,null,0,"#'+tagname+'",1,5,7,0,0,null,null]}'
        resp = urlquick.post(url=apiurl, data=reqdata, headers=self.headerdict)
        #resp = urlquick.request(method="POST", url=apiurl, data=reqdata, headers=self.headerdict)
        results = resp.json().get('aResultSet', [])
        if len(results) == 0:
            return []
        else:
            items = results[4]['aRow']
            posts = results[3]['aRow']
            for item in items:
                label = ""
                label2 = ""
                posturl = ""
                blogname = ""
                thumb = self.base32path(**item)
                vidurl = thumb.rpartition('.')[0] + ".mp4"
                postid = item.get('qwPostIx', '')
                blogid = item.get('dwBlogIx', item.get('dwBlogIx_From', item.get('dwBlogIx_Orig', item.get('dwBlogIx_Submit'))))
                ablog = self.getBlog(blogid)
                if ablog is not None:
                    item.update(ablog.__dict__)
                    if ablog.szBlogId is not None:
                        blogname = ablog.szBlogId
                label = item.get('szTitle', '') # + " " + item.get('szBody', '')
                if len(blogname) > 0:
                    label2 = "https://" + blogname + ".newtumbl.com/"
                    posturl = label2 + "post/" + str(postid)
                litems.append({'label': label, 'label2': label2, 'thumb': thumb, 'icon': thumb, 'url': vidurl, 'is_folder': False, 'is_playable': True})
        return litems


    def getBlogPosts(self, blogid=0, filterby=media.VIDEO, filterdate=""):
        apiurl = self.BASEURL +  "search_Site_Posts"
        # filterdate = "2019-07-31T23:00:00.0000000"
        reqparams = reqparams = {"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",blogid,None,None,0,50,0,filterdate,0,"",1,5,filterby,0,0,None,None]}
        resp = urlquick.request(method="POST", url=apiurl,data={'json': json.dumps(reqparams)})
        results = resp.json()


    def getLiked(self):
        litems = []
        likedResults = None

        return litems

    def getFavs(self):
        litems = []
        return litems


    def old_getByTag(self, tagname=""):
        apiurl = self.BASEURL+"search_Site_Posts"
        apiurlblog = self.BASEURL+"get_Blog_Marquee"
        litems = []
        reqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,null,null,0,50,0,null,0,"#'+tagname+'",1,5,7,0,0,null,null]}'
        resp = urlquick.request(method="POST", url=apiurl, data=reqdata, headers=self.headerdict)
        results = resp.json().get('aResultSet', [])
        if len(results) == 0:
            return []
        else:
            items = results[4]['aRow']
            posts = results[3]['aRow']
            for item in items:
                label = ""
                label2 = ""
                posturl = ""                
                thumb = self.base32path(**item)
                postid = item['qwPostIx']
                blogid = item['dwBlogIx_From']
                blogreqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,'+str(blogid)+']}'
                resp = urlquick.request(method="POST", url=apiurlblog, data=blogreqdata, headers=self.headerdict)
                blogresult = resp.json().get('aResultSet', [])
                if len(blogresult) > 2:
                    blogitem = blogresult[2]['aRow'][0]
                    item.update(**blogitem)
                label=item['szTitle'] + " " + item.get('szBody', '')
                if item.has_key('szBlogId'):
                    label2 = "https://" + item['szBlogId'] + ".newtumbl.com/"
                    posturl = label2 + "post/" + str(postid)
                litems.append({'label': label, 'label2': label2,'thumb': thumb, 'icon': thumb, 'url': posturl})
        return litems


class Blog(dict):


    def __init__(self, **kwargs):
        """
        : attribute nWidth : float
        : attribute szTitle : string
        : attribute bIconShape : float
        : attribute qwMediaIxBanner : float
        : attribute dtCreated : string
        : attribute bMediaTypeIx : float
        : attribute nCountBlogMessage : float
        : attribute dtOrigin : string
        : attribute acLanguage : string
        : attribute bRatingBlogLinks : float
        : attribute dwUserIx : float
        : attribute nBirthYear : float
        : attribute qwMediaIxBackground : float
        : attribute dwAdmin : float
        : attribute qwMediaIx : float
        : attribute bRatingBlogs : float
        : attribute bLoggedIn : float
        : attribute nCountPostAsk : float
        : attribute szName : string
        : attribute nHeight : float
        : attribute nCountPostFlagged : float
        : attribute szBody : string
        : attribute bStatus : float
        : attribute bHide : float
        : attribute dwColorBackground : float
        : attribute bTerms : float
        : attribute acCountry : string
        : attribute bMinor : float
        : attribute nCountPostOutOfRange : float
        : attribute szLocation : string
        : attribute bNoIndex : float
        : attribute szBlogId : string
        : attribute bVerified : float
        : attribute bPrivate : float
        : attribute bActive : float
        : attribute bRatingIx : float
        : attribute nCountPostSubmit : float
        : attribute bPrimary : float
        : attribute bBlock : float
        : attribute dwBlogIx : float
        : attribute bOnline : float
        : attribute szDescription : string
        : attribute dwColorForeground : float
        : attribute qwMediaIxIcon : float
        : attribute szSub : string
        : attribute nSize : float
        : attribute bFollow : float
        : attribute dwIPAddressIx : float
        : attribute bTOS : float
        """
        super(Blog, self).__init__(**kwargs)
        self.nWidth = None
        self.szTitle = None
        self.bIconShape = None
        self.qwMediaIxBanner = None
        self.dtCreated = None
        self.bMediaTypeIx = None
        self.nCountBlogMessage = None
        self.dtOrigin = None
        self.acLanguage = None
        self.bRatingBlogLinks = None
        self.dwUserIx = None
        self.nBirthYear = None
        self.qwMediaIxBackground = None
        self.dwAdmin = None
        self.qwMediaIx = None
        self.bRatingBlogs = None
        self.bLoggedIn = None
        self.nCountPostAsk = None
        self.szName = None
        self.nHeight = None
        self.nCountPostFlagged = None
        self.szBody = None
        self.bStatus = None
        self.bHide = None
        self.dwColorBackground = None
        self.bTerms = None
        self.acCountry = None
        self.bMinor = None
        self.nCountPostOutOfRange = None
        self.szLocation = None
        self.bNoIndex = None
        self.szBlogId = None
        self.bVerified = None
        self.bPrivate = None
        self.bActive = None
        self.bRatingIx = None
        self.nCountPostSubmit = None
        self.bPrimary = None
        self.bAge = None
        self.bBlock = None
        self.dwBlogIx = None
        self.bGender = None
        self.bOnline = None
        self.szDescription = None
        self.dwColorForeground = None
        self.qwMediaIxIcon = None
        self.szSub = None
        self.nSize = None
        self.bFollow = None
        self.dwIPAddressIx = None
        self.bTOS = None
        for k, v in kwargs.iteritems():
            super.__setattr__(self, k, v)


class Post(dict):

    def __init__(self, **kwargs):
        """
        : attribute dtFavorite : string
        : attribute bFlag : float
        : attribute bPartTypeIx : float
        : attribute dwBlogIx : float
        : attribute qwMediaIxBackground : float
        : attribute bPrimary : float
        : attribute bStatus : float
        : attribute szURL : string
        : attribute dwColorForeground : float
        : attribute bTier : float
        : attribute bOrder : float
        : attribute qwMediaIx : float
        : attribute bState : float
        : attribute bFavorite : float
        : attribute dwUserIx : float
        : attribute dtLike : string
        : attribute bFollow : float
        : attribute dtCreated : string
        : attribute qwPostIxFrom : float
        : attribute bBlock : float
        : attribute bLike : float
        : attribute qwPostIx : float
        : attribute bPostTypeIx : float
        : attribute qwPostIxOrig : float
        : attribute nPartIz : float
        : attribute szSub : string
        : attribute bPrivate : float
        : attribute szTitle : string
        : attribute bMediaTypeIx : float
        : attribute dwIPAddressIx : float
        : attribute szTag : string
        : attribute dtActive : string
        : attribute szBody : string
        : attribute dwBlogIxSubmit : float
        : attribute bRatingIx : float
        : attribute szDescription : string
        : attribute nHeight : float
        : attribute bIconShape : float
        : attribute szExternal : string
        : attribute dwBlogIxFrom : float
        : attribute nCountPost : float
        : attribute nSize : float
        : attribute dwBlogIxOrig : float
        : attribute dtScheduled : string
        : attribute nCountLike : float
        : attribute dwChecksum : float
        : attribute bNoIndex : float
        : attribute szSource : string
        : attribute nWidth : float
        : attribute qwMediaIxBanner : float
        : attribute bHide : float
        : attribute nCountComment : float
        : attribute qwMediaIxIcon : float
        : attribute szBlogId : string
        : attribute dtOrigin : string
        : attribute dwColorBackground : float
        """
        super(Post, self).__init__(**kwargs)
        self.dtFavorite = None
        self.bFlag = None
        self.bPartTypeIx = None
        self.dwBlogIx = None
        self.qwMediaIxBackground = None
        self.bPrimary = None
        self.bStatus = None
        self.szURL = None
        self.dtDeleted = None
        self.dwColorForeground = None
        self.bTier = None
        self.bOrder = None
        self.qwMediaIx = None
        self.bState = None
        self.bFavorite = None
        self.dwUserIx = None
        self.dtLike = None
        self.bFollow = None
        self.dtModified = None
        self.dtCreated = None
        self.qwPostIxFrom = None
        self.bBlock = None
        self.bLike = None
        self.qwPostIx = None
        self.bPostTypeIx = None
        self.qwPostIxOrig = None
        self.nPartIz = None
        self.szSub = None
        self.bPrivate = None
        self.szTitle = None
        self.bMediaTypeIx = None
        self.dwIPAddressIx = None
        self.szTag = None
        self.dtActive = None
        self.szBody = None
        self.dwBlogIxSubmit = None
        self.bRatingIx = None
        self.szDescription = None
        self.nHeight = None
        self.bIconShape = None
        self.szExternal = None
        self.dwBlogIxFrom = None
        self.nCountPost = None
        self.nSize = None
        self.dwBlogIxOrig = None
        self.dtScheduled = None
        self.nCountLike = None
        self.dwChecksum = None
        self.bNoIndex = None
        self.szSource = None
        self.nWidth = None
        self.qwMediaIxBanner = None
        self.bHide = None
        self.nCountComment = None
        self.qwMediaIxIcon = None
        self.szBlogId = None
        self.dtFlag = None
        self.dtOrigin = None
        self.dwColorBackground = None
        for k, v in kwargs.iteritems():
            super.__setattr__(self, k, v)
