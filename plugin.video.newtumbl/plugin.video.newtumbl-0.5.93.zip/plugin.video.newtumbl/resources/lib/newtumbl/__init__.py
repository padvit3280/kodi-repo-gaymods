#from nT import newTumbl
from nT import *
#import nT
#import ntBlog
