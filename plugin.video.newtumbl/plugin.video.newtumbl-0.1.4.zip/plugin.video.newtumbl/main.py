# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Github: https://github.com/moedje/
# Updated on: June 23, 2019
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import ssl, re, datetime, time, os, sys
import base64
try:
    import xbmc, xbmcplugin
except:
    import Kodistubs.xbmc as xbmc
    import Kodistubs.xbmcplugin as xbmcplugin
from resources.lib import newtumbl, urlquick, simpleplugin

path = os.path
ssl._create_default_https_context = ssl._create_unverified_context
plugin = simpleplugin.Plugin()
__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
__next__ = path.join(xbmc.translatePath('special://home/addons/{0}/resources/'.format(plugin.id)), 'next.png')
#API = Lib.vidster.MyVidster(path_addon=__datadir__)
API = newtumbl.newTumbl()


@plugin.action()
def root():
    tagnamelast = plugin.get_setting(id='lastsearch')
    rootmenu = {
        "Home": [
            {'label': 'Dashboard Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_dashboard")},
            {'label': 'Tagged Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_tag", tagname=tagnamelast)}
        ]
    }
    return rootmenu["Home"]


@plugin.action()
def get_dashboard():
    items = API.getDashPosts()
    #plugin.log(msg=str(items[:]), level=xbmc.LOGINFO)
    return items


@plugin.action()
def get_tag(params):
    if params.tagname is not None:
        tag = params.tagname
    else:
        tag = "public"
    items = API.getVidsTag(tagname=tag)
    #plugin.log(msg=str(items[:]), level=xbmc.LOGINFO)
    return items

@plugin.action()
#@plugin.mem_cached(10)
def root2():
    imgVidster = __next__.replace('next', 'myvidster')
    vidsterNameChan = 'GayPublic'
    lblTpl = '[COLOR green]{0}[/COLOR] ([COLOR white][I]{1}[/I][/COLOR])\n[COLOR yellow]{2}[/COLOR]'
    lblVidsterNew = lblTpl.format('MyVidster', 'Latest', vidsterNameChan)
    lblVidsterChan = lblTpl.format('MyVidster', 'View Channel', vidsterNameChan) #'[COLOR green]MyVidster[/COLOR] - [COLOR white][I]View Channel[/I][/COLOR]\n[COLOR yellow]{0}[/COLOR]'.format(vidsterNameChan)
    lblVidsterGetChan = lblTpl.format('MyVidster Channel', vidsterNameChan, '')
    lblWs = lblTpl.format("Watch Series", "Latest", "")
    lblWsAll = lblTpl.format("Watch Series", "Full List", "")
    rootmenu = {
        "Home": [
            {'label': lblVidsterGetChan, 'url': plugin.get_url(action='get_channel', id=1533786, page=1), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False},
            {'label': lblVidsterNew, 'url': plugin.get_url(action='home_myvidster', id=1533786), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False},             
            {'label': lblVidsterChan, 'url': plugin.get_url(action='list_vidster', id=1533786), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False},
            {'label': "Search MyVidster", 'url': plugin.get_url(action='search_vidster', query="public"), 'thumb': imgVidster,
             'is_folder': True, 'is_playable': False}]
    }
    return rootmenu["Home"]


@plugin.action()
def get_channel(params):
    items = []
    litems = []
    linext = {}
    chanid = "1533786"
    if params.id is not None:
        chanid = params.id
    page = 1
    if params.page is not None:
        page = params.page
    nextpage = int(page) + 1
    nextlbl = 'Next -> {0}'.format(nextpage.__str__())
    linext = {'label': nextlbl, 'url': plugin.get_url(action='get_channel', page=nextpage, id=chanid), 'thumb': __next__, 'icon': __next__, 'is_folder': True}
    items = API.get_channel(channel=chanid, page=page)
    for li in items:
        playpath = plugin.get_url(action='playvidster', video=li.get('url'))
        li.update({'url': playpath})
        litems.append(li)
    if len(litems) == 250:
        litems.append(linext)
    return litems


@plugin.action()
def home_myvidster(params):
    items = []
    litems = []
    cid = 1533786
    if params.id is not None:
        cid = params.id
    urlrss = 'https://www.myvidster.com/rss/channel/' + str(cid) # https://www.myvidster.com/user/manage.php?level=video&id=1533786&entries_per_page=300
    resp = urlquick.get(urlrss)
    for item in resp.xml().iter('item'):
        items.append(item)
    for item in items:
        litem = {'is_folder': False} #, 'is_playable': True}
        gif = ''
        for kid in item.getchildren():
            if kid.tag == 'link':
                vurl = kid.text
                vid = vurl.replace('/video/','').split('/',1)[0]
                pathdl = plugin.get_url(action='download', video=vurl)
                images = API.vidster_images(id=vid)
                gif = "" # create_gif(images)
                litem.update({'url': plugin.get_url(action='play', video=vurl), 'art': {'AnimatedPoster': gif}, 'context_menu': [('Download', 'RunPlugin({0})'.format(pathdl)), ]})  # {'url': plugin.get_url(action=sources_ws, url=kid.text)})
                #{'context_menu': [('Download', 'RunPlugin({0})'.format(pathdl)), ]}
            elif kid.tag == 'title':
                name = kid.text.encode('latin', 'ignore')
                litem.update({'label': name.strip()})
            if kid.tag == '{http://search.yahoo.com/mrss/}thumbnail':
                    attr = kid.attrib
                    img = attr.get('url')
                    litem.update({'thumb': img, 'icon': img})
            elif kid.tag == 'description':
                lbl2 = kid.text.strip() + '\n' + litem.get('label2', '')
                litem.update({'label2': lbl2})
            elif kid.tag == 'pubdate':
                lbl2 = kid.text.strip() + '\n' + litem.get('label2', '')
                litem.update({'label2': lbl2})
        #if path.isfile(gif):
        #    img = gif
        #    litem.update({'thumb': img, 'icon': img})
        litems.append(litem)
    return litems


@plugin.action()
def search_vidster(params):
    if params.query is not None:
        query = params.query
    urlthumb = 'http://www.myvidster.com/user/api.php?action=fetch&password=46c53b8a852c4ee94f458dc99786e23ebd666bd1&email=alljer@gmail.com&video_id='
    surl = 'https://www.myvidster.com/search/?password=46c53b8a852c4ee94f458dc99786e23ebd666bd1&email=alljer@gmail.com&filter_by=myvidster&sortby=utc_posted&cfilter_by=gay&q='+query.replace(' ', '+')
    resp = urlquick.get(surl, params={'user_id': 2219807, 'email': 'alljer@gmail.com', 'password': '46c53b8a852c4ee94f458dc99786e23ebd666bd1', 'adult_filter': 0})
    src = resp.content
    litems = []
    items = []
    matches = []
    vidster_headers = {'Cookie': '__cfduid=d913c54b56fe95616689ce1f1fc683a231559474798; sm_dapi_session=1; _gat=1; PHPSESSID=r1aptmhcmicd179f94v7o72id2; referral=myvidster.com; _ga=GA1.2.638511231.1559474803; _gid=GA1.2.142664491.1559474803; __atuvc=1%7C23; __atuvs=5cf3b2727692eeb9000; user_name=Skyler32UK; user_id=2219807; password=46c53b8a852c4ee94f458dc99786e23ebd666bd1; cc_data=2219807; auto_refresh=1',
        'referer': 'https://www.myvidster.com/'}
    html = src.rpartition('id="search-content"')[-1].split('id="search-header"',1)[0]
    matches = re.compile('class="viddetails">\n.+?href="(.+?)">(.+?)</a>.+?\n.+?Bookmarked (.+?) ago').findall(html)
    for link, vid_title, posted in matches:
        vurl = "https://www.myvidster.com" + link
        vid = link.replace('/video/','').split('/',1)[0]
        resp = urlquick.get(urlthumb+vid)
        img = resp.content.partition('<thumbnail_url1>')[-1].split('</thumbnail_url1>')[0].strip()
        #img = images[0]
        #if len(images) > 1:
        #    img = images[1]
        lbl = '[COLOR yellow][B]{0}[/B][/COLOR] [I]{1}[/I]'.format(vid_title.title(), posted) 
        lbl2 = "{0}\n{1}\n{2}".format(vurl, posted, img)
        pathdl = plugin.get_url(action='download', video=vurl)
        playpath = plugin.get_url(action='play', video=vurl)
        images = API.vidster_images(vid)
        gif = '' # '¢create_gif(images)
        item = {'label': lbl, 'label2': lbl2, 'thumb': img, 'icon': img, 'art': {'AnimatedPoster': gif}, 'is_folder': False, 'url': plugin.get_url(action='play', video=vurl), 'info': {'video': {}}, 'context_menu': [('Play', 'RunPlugin({0})'.format(playpath)), ('Download', 'RunPlugin({0})'.format(pathdl)), ]}
        #if GIF:
        #    resp = Lib.urlquick.get(urlgetimg+vid, params={'headers': vidster_headers})
        #    images = resp.json()
        #    gifimage = create_gif(images)
        #    item.update(art={'AnimatedPoster': gifimage, 'AnimatedFanart': gifimage})
        litems.append(item)
    return litems


@plugin.action()
def download(params):
    vurl = ''
    vurl = params.video
    try:
        from YDStreamExtractor import getVideoInfo
        from YDStreamExtractor import handleDownload
        info = getVideoInfo(vurl, resolve_redirects=True)
        dlpath = plugin.get_setting('downloadpath')
        if not path.exists(dlpath):
            dlpath = xbmc.translatePath("home://")
        handleDownload(info, bg=True, path=dlpath)
    except:
        plugin.notify(vurl, "Download Failed")


@plugin.action()
def playvidster(params):
    urlvid = params.video
    resolvedurl = urlvid
    url = "plugin://plugin.video.wsonline/play/{0}".format(urlquick.quote(urlvid))
    try:
        xbmc.executebuiltin("Notification({0}, {1})".format("Trying To Play...", urlvid))
        resolvedurl = API.resolve(urlvid)
        plugin.log_notice(resolvedurl)
        xbmc.executebuiltin("Notification({0}, {1})".format(urlvid, resolvedurl))
    except:
        plugin.log_notice("ERROR RESOLVING " + url)
    item = {'label': urlvid, 'label2': resolvedurl, 'thumb': 'DefaultVideo.png', 'is_folder': False, 'is_playable': True, 'url': resolvedurl}
    plugin.resolve_url(resolvedurl, item)
    xbmc.Player().play(resolvedurl)
    return [item]


@plugin.action()
def play(params):
    urlvid = params.video
    resolvedurl = urlvid
    url = "plugin://plugin.video.wsonline/play/{0}".format(urlvid)
    try:
        xbmc.executebuiltin("Notification({0}, {1})".format("Trying To Play...", urlvid))
        resolvedurl = API.resolve(urlvid)
        plugin.log_notice(resolvedurl)
        xbmc.executebuiltin("Notification({0}, {1})".format(urlvid, resolvedurl))
    except:
        plugin.log_notice("ERROR RESOLVING " + url)
    item = {'label': urlvid, 'label2': resolvedurl, 'thumb': 'DefaultVideo.png', 'is_folder': False, 'is_playable': True, 'url': resolvedurl}
    plugin.resolve_url(resolvedurl, item)
    xbmc.Player().play(resolvedurl)
    return [item]


def showMessage(self, header='', msg=''):
    try:
        header = str(header.encode('utf-8', 'ignore'))
        msg = str(msg.encode('utf-8', 'ignore'))
        xbmc.executebuiltin('Notification({0},{1})'.format(header, msg))
    except:
        print(header + '\n' + msg)


def get_input(default=''):
    kb = xbmc.Keyboard(default, 'Search MyVidster')
    kb.setDefault(default)
    kb.setHeading('MyVidster Search')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term = kb.getText()
        return(search_term)
    else:
        return None

if __name__ == '__main__':
    # Run our plugin
    plugin.run()
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmc.executebuiltin('Skin.SetBool(SkinHelper.EnableAnimatedPosters)')
