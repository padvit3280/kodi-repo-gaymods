# -*- coding: utf-8 -*-
# Module: main
# Author: moedje
# Github: https://github.com/moedje/
# Updated on: August 2019
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import ssl, re, os, sys
try:
    import xbmc, xbmcplugin
except:
    import Kodistubs.xbmc as xbmc
    import Kodistubs.xbmcplugin as xbmcplugin
from resources.lib import newtumbl, urlquick, simpleplugin
handle = int(sys.argv[1])
path = os.path
ssl._create_default_https_context = ssl._create_unverified_context
plugin = simpleplugin.Plugin()
__datadir__ = xbmc.translatePath('special://profile/addon_data/{0}/'.format(plugin.id))
__cookie__ = path.join(__datadir__, 'cookies.lwp')
__next__ = path.join(xbmc.translatePath('special://home/addons/{0}/resources/'.format(plugin.id)), 'next.png')
__search__ = __next__.replace('next', 'search')

API = newtumbl.newTumbl(datadir=__datadir__)


@plugin.action()
def root():
    xbmc.executebuiltin('xbmc.executebuiltin("Container.SetViewMode(51)')
    tagnamelast = plugin.get_setting('lastsearch')
    rootmenu = {
        "Home": [
            {'label': 'Dashboard Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_dashboard")},
            {'label': 'Search Tagged Videos', 'thumb': __search__, 'icon': __search__, 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="prompt_tag")},
            {'label': 'Gay Tagged Videos', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="get_tag", tagname='gay')},
            {'label': 'Search Blogs', 'is_folder': True, 'is_playable': False, 'url': plugin.get_url(action="find_blogs")},
        ]
    }
    return rootmenu["Home"]


@plugin.action()
def get_dashboard():
    items = API.getDashPosts()
    xbmc.executebuiltin('xbmc.executebuiltin("Container.SetViewMode(501)')
    return items


@plugin.action()
def get_tag(params):
    if params.tagname is not None:
        tag = params.tagname
    else:
        tag = "gay"
    items = API.getVidsTag(tagname=tag)
    xbmc.executebuiltin('xbmc.executebuiltin("Container.SetViewMode(501)')
    #plugin.log(msg=str(items[:]), level=xbmc.LOGINFO)
    return items


@plugin.action()
def find_blogs():
    litems = []
    txt = ''
    txt = plugin.get_setting('lastblogsearch')
    txt = get_input(default=txt)
    xbmc.executebuiltin('xbmc.executebuiltin("Container.SetViewMode(501)')
    bloglist = API.SearchForBlog(keyword=txt)
    for item in bloglist:
        url = item.get('url')
        blogix = url.rpartition('/')[-1]
        url = url.replace('/'+blogix,'')
        ctx = [('Follow Blog', 'RunPlugin("{0}")'.format(plugin.get_url(action='follow_blog', blogid=blogix)),)]
        item.update({"context_menu": ctx, "url": plugin.get_url(action="view_blog", blogid=blogix)})
        litems.append(item)
    return litems


@plugin.action()
def follow_blog(params):
    blogix = 0
    if params.blogid is not None:
        blogix = params.blogid
    API.FollowBlog(blogix)
    showMessage(header="NewTumbl", msg="Blog Followed: " + str(blogix))


@plugin.action()
def view_blog(params):
    blogix = 0
    if params.blogid is not None:
        blogix = params.blogid
    litems = []
    blogposts = []
    blogposts = API.getBlogPosts(blogid=blogix)
    for post in blogposts:
        postid = post.get('properties', {}).get('postix', 0)
        ctx = [("Like Post", 'RunPlugin("{0}")'.format(plugin.url(action='like_post', postix=postid)))]
        post.update({"context_menu": ctx})
        litems.append(post)
    return litems


@plugin.action()
def prompt_tag():
    txt = ''
    txt = plugin.get_setting('lastsearch')
    txt = get_input(default=txt)
    xbmc.executebuiltin('xbmc.executebuiltin("Container.SetViewMode(501)')
    return API.getVidsTag(tagname=txt)


@plugin.action()
def download(params):
    vurl = ''
    vurl = params.video
    try:
        from YDStreamExtractor import getVideoInfo
        from YDStreamExtractor import handleDownload
        info = getVideoInfo(vurl, resolve_redirects=True)
        dlpath = plugin.get_setting('downloadpath')
        if not path.exists(dlpath):
            dlpath = xbmc.translatePath("home://")
        handleDownload(info, bg=True, path=dlpath)
    except:
        plugin.notify(vurl, "Download Failed")


def showMessage(self, header='', msg=''):
    try:
        header = str(header.encode('utf-8', 'ignore'))
        msg = str(msg.encode('utf-8', 'ignore'))
        xbmc.executebuiltin('Notification({0},{1})'.format(header, msg))
    except:
        print(header + '\n' + msg)


def get_input(default=''):
    kb = xbmc.Keyboard(default, 'Search MyVidster')
    kb.setDefault(default)
    kb.setHeading('MyVidster Search')
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        search_term = kb.getText()
        plugin.set_setting('lastsearch', search_term)
        return(search_term)
    else:
        return None

if __name__ == '__main__':
    # Run our plugin
    plugin.run()
    xbmcplugin.setContent(handle, 'episodes')
    xbmcplugin.setPluginCategory(handle, 'porn')
    #xbmc.executebuiltin('Skin.SetBool(SkinHelper.EnableAnimatedPosters)')