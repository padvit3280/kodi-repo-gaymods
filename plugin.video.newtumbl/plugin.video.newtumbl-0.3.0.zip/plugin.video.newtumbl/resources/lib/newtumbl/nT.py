import urlquick
import json
import hashlib
import re
import os
import nTobjects as nTobj
from collections import namedtuple

media = namedtuple("media", ['VIDEO', 'PHOTO', 'ALL'])(*[7,5,0])

class nTparams():

    def __init__(self, usertoken="", userid=0):
        #"[{IPADDRESS}]","' + self.userToken + '",' + str(self.userIx) + ',null,null,0,50,' + str(page) + ',null,0,"",0,0,"7",0,0,null,null]
        self.IpAddress='"[{IPADDRESS}]"'
        self.Usertoken='"{0}"'
        if len(usertoken) > 0:
            self.Usertoken = self.Usertoken.format(usertoken)
        self.UserId=0
        if userid != 0:
            self.UserId = userid
        self.BlogId='null'
        self.Field4='null'
        self.Field5=0
        self.NumResults=50
        self.OffsetResults=0
        self.Field8='null'
        self.Field9=0
        self.Tag='"#{0}'
        self.Field11=0
        self.Field12=0
        self.FilterBy=media.VIDEO
        self.Field13=0
        self.Field14=0
        self.Category='null'
        self.Field16='null'

    @property
    def Offset(self, num=0):
        self.OffsetResults=num

    @property
    def NumResults(self, num=50):
        self.NumResults = num
    
    @property
    def Params(self):
        return 'json={"Params":[{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16}]}'.format(self.IpAddress, self.Usertoken, self.UserId, self.BlogId, self.Field4, self.Field5, self.NumResults, self.OffsetResults, self.Field8, self.Field9, self.Tag, self.Field11, self.Field12, self.FilterBy, self.Field13, self.Field14, self.Category, self.Field16)

    @NumResults.setter
    def NumResults(self, value):
        self._NumResults = value


class newTumbl():
    '''
    API Methods
    ["get_Blog_Marquee",
    "search_Site_Blogs",
    "search_Site_Posts",
    "search_Dash_Activity",
    "search_Dash_Posts",
    "search_Blog_Posts",
    "search_User_Posts_Like",
    "search_User_Posts_Favorite",
    "search_Post_Notes"]
    '''
    BASEURL = "https://api-ro.newtumbl.com/sp/NewTumbl/"
    headerdict = {'Host': 'api-ro.newtumbl.com',
                  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:69.0) Gecko/20100101 Firefox/69.0',
                  'Accept': '*/*', 'Accept-Language': 'en-US,en;q=0.5', 'Accept-Encoding': 'gzip, deflate, br',
                  'Referer': 'https://newtumbl.com/feed',
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Pragma': 'no-cache',
                  'Cache-Control': 'no-cache', 'Origin': 'https://newtumbl.com'}

    def __init__(self, datadir='', usertoken='FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I', userid=391932):
        self.userToken = usertoken
        self.userIx = userid
        if datadir == '':
            datadir = os.path.join(os.path.abspath(os.path.expanduser("~")), '.kodi/temp')
        if os.path.exists(datadir) and os.path.isdir(datadir):
            urlquick.CACHE_LOCATION = datadir
        else:
            try:
                os.mkdir(datadir)
            except:
                print("Could not find data directory or create it: " + datadir)
        self.aResultSet = None

    def getImage(self, **kwargs):
        if not kwargs.has_key('qwMediaIx'):
            if kwargs.has_key('qwMediaIx_Icon'):
                kwargs.update({'qwMediaIx': kwargs['qwMediaIx_Icon']})
        return self.base32path(imgpath='', **kwargs)

    def base32path(self, imgpath="", **kwargs):
        '''
        Parameters:
        BlogID
        PostID
        PartID
        MediaID
        or imgpath in form of imgpath="/blogid/postid/partid/mediaid" or as much as imgpath="https://dn0.newtumbl.com/img/blogid/postid/partid/mediaid/nT_"
        blogid=265936 postid=6180659 partid=1 mediaID=9257871
        Returns:
        URL to image in format of:
        https://dn0.newtumbl.com/img/{BlogID}/{PostID}/{PartID}/{MediaID}/nT_{Base32(SHA256("/{blogid}/{postid}/{partid}/{mediaid}/nT_"))}.jpg
        Example: https://dn0.newtumbl.com/img/265936/6180659/1/9257871/nT_bjkrnkq6tjk8j62a05hrzks0.jpg
        '''
        ids = dict(blogid=0, postid=0, partid=0, mediaid=0)
        ids.update(**kwargs)
        if kwargs.has_key('qwMediaIx'):
            blogid = kwargs.get('dwBlogIx', kwargs.get('dwBlogIx_From', kwargs.get('dwBlogIx_Orig', kwargs.get('dwBlogIx_Submit', '0'))))
            ids = {'mediaid': ids.get('qwMediaIx', ids.get('qwMediaIx_Icon', '0')), 'partid': ids.get('nPartIz', '0'), 'postid': ids.get('qwPostIx','0'), 'blogid': blogid}
        sMap = "abcdefghijknpqrstuvxyz0123456789"
        sOutput = ""
        i = -1
        b = 0
        c = 0
        d = None
        shalist = []
        abInput = []
        BASEIMGURL = "https://dn0.newtumbl.com/img"
        if imgpath is not "":
            try:
                if imgpath.startswith('http') or imgpath.find('img/') != -1:
                    ids['blogid'],ids['postid'],ids['partid'],ids['mediaid'] = imgpath.split('img/',1)[-1].rpartition('/nT_')[0].split('/',4)
                else:
                    if not imgpath.startswith('/'):
                        imgpath = "/" + imgpath
                    if not imgpath.endswith('/') and not imgpath.endswith('nT_'):
                        imgpath = imgpath + '/nT_'
                    if not imgpath.endswith('nT_'):
                        imgpath = imgpath + 'nT_'
                    imgpath = imgpath.replace('/nT_', '').replace('/nT','')
                    ids['blogid'],ids['postid'],ids['partid'],ids['mediaid'] = imgpath.partition('/')[-1].strip('/').split('/',4)
            except:
                return None
        sPath = "/" + str(ids['blogid']) + "/" + str(ids['postid']) + "/" + str(ids['partid']) + "/" + str(ids['mediaid']) + "/nT_"
        sha = hashlib.sha256(sPath)
        hexdigest = sha.hexdigest()
        for t in range(0,len(hexdigest),2): shalist.append(hexdigest[t:t+2])
        for num in shalist: abInput.append(int(num,16))
        # Based on Base32 Javascript method from newtumbl original function runs on a WordArray of 16 pairs of HEX digits returned from SHA256
        # https://newtumbl.com/v1.6.22/js/common.js
        while (i < len(abInput) or b > 0):
            if b < 5:
                i = i+1
                if i < len(abInput):
                    c = (c << 8) + int(abInput[i])
                    b += 8
            d = c % 32
            c = c >> 5
            b = b - 5
            sOutput += sMap[d]
        sOutput = sOutput[0:24]
        imgurl = BASEIMGURL + sPath + sOutput + ".jpg"
        return imgurl


    def getDashPosts(self, page=0):
        litems = []
        dashitems = []
        tags = []
        apiurl = self.BASEURL + "search_Dash_Posts"
        reqdata = 'json={"Params":["[{IPADDRESS}]","' + self.userToken + '",' + str(self.userIx) + ',null,null,0,50,' + str(page) + ',null,0,"",0,0,"7",0,0,null,null]}'
        resp = urlquick.post(url=apiurl, data=reqdata, headers=self.headerdict)
        dashresult = resp.json().get('aResultSet', [])
        self.aResultSet = dashresult
        if len(dashresult) > 1:
            dashlist = dashresult[3].get('aRow', [])
            for post in dashlist:
                postid = post.get('qwPostIx', post.get('qwPostIx_From', post.get('qwPostIx_Orig', 0)))
                blogid = post.get('dwBlogIx', post.get('dwBlogIx_From', post.get('dwBlogIx_Orig', 0)))
                mediadict = self.getPostMedia(postid=postid, results=dashresult)
                blogdict = self.getPostBlog(blogid=blogid, results=dashresult)
                tags = self.getPostTags(postid)
                #postdict = self.getPost(postid=post.get('qwPostIx', 0), results=dashresult)
                post.update(blogdict)
                post.update(mediadict)
                post.update({"tags": ','.join(tags)})
                dashitems.append(post)
        else:
            return None
        about = ""
        label = ""
        label2 = ""
        blogname = ""
        title = ""
        for post in dashitems:
            assert isinstance(post, dict)
            thumb = post.get("thumb", "")
            vurl = post.get("video", "")
            if len(thumb) < 1:
                thumb = self.base32path(**post)
                vurl = thumb.rpartition('.')[0] + ".mp4"
                post.update({"thumb": thumb, "video": vurl})
            blogname = post.get('szBlogId', '')
            title = post.get('szTitle', '')
            about = post.get('szDescription', blogname)
            if len(title) > 1:
                label = label + "\n" + post.get('tags', '')
            else:
                label = post.get('tags', '')
            label2 = blogname + ' ' + title + ' ' + about + "\n" + unicode(post.viewvalues())
            infotag = {'plot': str(dashlist[0].viewitems())[13:-3].replace("u'", "'").replace("), (", ",").replace("', ", "':")}
            infolabel = {'video': infotag}
            litem = {'label': label, 'label2': label2, 'thumb': thumb, 'icon': thumb, 'url': vurl, 'is_folder': False, 'is_playable': True, 'info': infolabel}
            litems.append(litem)
        return litems


    def followBlog(self, blogix=0):
        apiurl = self.BASEURL + 'follow_Blog'
        apiurl = apiurl.replace('-ro', '-rw')
        reqdata = 'json={"Params":["[{IPADDRESS}]","' + self.userToken + '",' + str(self.userIx) + ',' + str(blogix) + ']}'
        resp = urlquick.post(apiurl, data=reqdata, headers=self.headerdict)


    def getPost(self, postid=0, results=None):
        if results is None:
            if self.aResultSet is None:
                return None
            else:
                results = self.aResultSet
        postlist = []
        postlist = results[3].get('aRow', [])
        for post in postlist:
            if post.get('qwPostIx', 0) == postid:
                return post
        return {}


    def getPostBlog(self, blogid=0, results=None):
        if results is None:
            if self.aResultSet is None:
                return None
            else:
                results = self.aResultSet
        bloglist = []
        bloglist = results[2].get('aRow', [])
        for blog in bloglist:
            if blog.get('qwBlogIx', 0) == blogid:
                return blog
        return {}


    def getPostMedia(self, postid=0, results=None):
        if results is None:
            if self.aResultSet is None:
                return None
            else:
                results = self.aResultSet
        medialist = []
        medialist = results[4].get('aRow', [])
        for media in medialist:
            if media.get('qwPostIx', 0) == postid:
                thumb = self.base32path(**media)
                vurl = thumb.rpartition('.')[0] + ".mp4"
                media.update({'thumb': thumb, 'video': vurl})
                return media
        return {}


    def getPostTags(self, postid=0, results=None):
        if results is None:
            if self.aResultSet is None:
                return None
            else:
                results = self.aResultSet
        alltagslist = []
        posttags = []
        alltagslist = results[5].get('aRow', [])
        for tag in alltagslist:
            if tag.get('qwPostIx', 0) == postid:
                posttags.append(tag.get('szTag', ''))
        return posttags


    def getBlogDetails(self, blogid=0):
        apiurlblog = self.BASEURL + "get_Blog_Marquee"
        blogreqdata = 'json={"Params":["[{IPADDRESS}]","' + self.userToken + '",' + str(self.userIx) + ',' + str(blogid) + ']}'
        resp = urlquick.post(url=apiurlblog, data=blogreqdata, headers=self.headerdict)
        #resp = urlquick.request(method="POST", url=apiurlblog, data=blogreqdata, headers=self.headerdict)
        blogresult = resp.json().get('aResultSet', [])
        if len(blogresult) > 1:
            blogdict = blogresult[2].get('aRow', [])[0]
            ablog = Blog(**blogdict)
            return ablog
        else:
            return None


    def getVidsTag(self, tagname="", page=0):
        apiurl = self.BASEURL+"search_Site_Posts"
        litems = []
        tags = []
        reqdata = 'json={"Params":["[{IPADDRESS}]","' + self.userToken + '",' + str(self.userIx) + ',null,null,0,50,' + str(page) + ',null,0,"#'+tagname+'",1,5,7,0,0,null,null]}'
        resp = urlquick.post(url=apiurl, data=reqdata, headers=self.headerdict)
        #resp = urlquick.request(method="POST", url=apiurl, data=reqdata, headers=self.headerdict)
        results = resp.json().get('aResultSet', [])
        self.aResultSet = results
        if len(results) == 0:
            return []
        else:
            items = results[4]['aRow']
            posts = results[3]['aRow']
            for item in items:
                label = ""
                label2 = ""
                posturl = ""
                blogname = ""
                thumb = self.base32path(**item)
                vidurl = thumb.rpartition('.')[0] + ".mp4"
                postid = item.get('qwPostIx', item.get('qwPostIx_From', item.get('qwPostIx_Orig', 0)))
                blogid = item.get('dwBlogIx', item.get('dwBlogIx_From', item.get('dwBlogIx_Orig', item.get('dwBlogIx_Submit'))))
                tags = self.getPostTags(postid)
                item.update({'tags': ','.join(tags)})
                ablog = self.getBlogDetails(blogid)
                if ablog is not None:
                    item.update(ablog.__dict__)
                    if ablog.szBlogId is not None:
                        blogname = ablog.szBlogId
                label = item.get('szTitle', '') # + " " + item.get('szBody', '')
                if len(label) > 1:
                    label += '\n[I]' + item.get('tags', '') + '[/I]'
                else:
                    label = item.get('tags', '')
                if len(blogname) > 0:
                    label2 = "https://" + blogname + ".newtumbl.com/"
                    posturl = label2 + "post/" + str(postid)
                litems.append({'label': label, 'label2': label2, 'thumb': thumb, 'icon': thumb, 'url': vidurl, 'is_folder': False, 'is_playable': True})
        return litems


    def getBlogPosts(self, blogid=0, filterby=media.VIDEO, filterdate=""):
        apiurl = self.BASEURL +  "search_Site_Posts"
        # filterdate = "2019-07-31T23:00:00.0000000"
        litems = []
        reqparams = 'json={"Params":["[{IPADDRESS}]","' + self.userToken + '",' + str(self.userIx) + ',' + str(blogid) + ',null,null,0,50,0,null,0,"",1,5,7,0,0,null,null]}'
        #reqparams = reqparams = {"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",blogid,None,None,0,50,0,filterdate,0,"",1,5,filterby,0,0,None,None]}
        resp = urlquick.post(url=apiurl, data=reqparams, headers=self.headerdict)
        results = resp.json().get('aResultSet', [])
        self.aResultSet = results
        if len(results) == 0:
            return []
        else:
            items = results[4]['aRow']
            posts = results[3]['aRow']
            for item in items:
                label = ""
                label2 = ""
                posturl = ""
                blogname = ""
                thumb = self.base32path(**item)
                vidurl = thumb.rpartition('.')[0] + ".mp4"
                postid = item.get('qwPostIx', item.get('qwPostIx_From', item.get('qwPostIx_Orig', 0)))
                blogid = item.get('dwBlogIx', item.get('dwBlogIx_From', item.get('dwBlogIx_Orig', item.get('dwBlogIx_Submit'))))
                tags = self.getPostTags(postid)
                item.update({'tags': ','.join(tags)})
                ablog = self.getBlogDetails(blogid)
                if ablog is not None:
                    item.update(ablog.__dict__)
                    if ablog.szBlogId is not None:
                        blogname = ablog.szBlogId
                label = item.get('szTitle', '') # + " " + item.get('szBody', '')
                if len(label) > 1:
                    label += '\n[I]' + item.get('tags', '') + '[/I]'
                else:
                    label = item.get('tags', '')
                if len(blogname) > 0:
                    label2 = "https://" + blogname + ".newtumbl.com/"
                    posturl = label2 + "post/" + str(postid)
                litems.append({'label': label, 'label2': label2, 'thumb': thumb, 'icon': thumb, 'url': vidurl, 'is_folder': False, 'is_playable': True})
        return litems


    def SearchForBlog(self, keyword, pagenum=0):
        # blog icon format: https://dn0.newtumbl.com/img/163769/0/0/4545774/nT_5huakyb46vui0z09rin7ptgi_150.jpg
        # https://dn0.newtumbl.com/img/{blogid}/0/0/{qwMediaIx_Icon}/nT_{Base32(Sha256(path))}.jpg
        # Blogs List aResultSet[0][2]['aRow']
        # Blog Icons aResultSet[0][1]['aRow']
        # curl 'https://api-ro.newtumbl.com/sp/NewTumbl/search_Site_Blogs' -H 'Accept: */*' -H 'Referer: https://newtumbl.com/search' -H 'DNT: 1' -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36' -H 'Sec-Fetch-Mode: cors' -H 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' --data 'json=%7B%22Params%22%3A%5B%22%5B%7BIPADDRESS%7D%5D%22%2C%22FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I%22%2C391932%2Cnull%2Cnull%2C0%2C25%2C0%2C%22public%22%2C0%2C0%5D%7D' --compressed

        litems = []
        headers = self.headerdict
        headers.update({'Referer': 'https://newwtumbl.com/search'})
        reqparams = '{"Params":["[{IPADDRESS}]","' + self.userToken + '",' + str(self.userIx) + ',null,null,0,25,' + str(pagenum) + ',"' + keyword + '",0,0]}'
        apiurl = self.BASEURL + "search_Site_Blogs"
        resp = urlquick.post(url=apiurl, data="json="+reqparams, headers=headers)
        try:
            aResultSet = resp.json()
        except:
            aResultSet = {}
        if aResultSet.has_key('aResultSet'):
            results = aResultSet.get('aResultSet', [])
            self.aResultSet = results
        if len(results) > 0:
            blogs = results[2]['aRow']
            for blog in blogs:
                blogix = blog.get('dwBlogIx', '')
                mediaix = blog.get('qwMediaIx_Icon', '')
                blogid = blog.get('szBlogId', '')
                blogname = blog.get('szTitle', blogid)
                blogurl = "https://{0}.newtumbl.com/{1}".format(blogid, str(blogix))
                about = blog.get('szDescription','')
                if len(about) > 0:
                    about = about + "\n" + blogname + " ("+blogid+")\n" + blogurl
                else:
                    about = blogname + " (" + blogid + ")\n" + blogurl
                idargs = {'blogid': blogix, 'partid': 0, 'postid': 0, 'mediaid': mediaix}
                img = self.getImage(**idargs)
                label = "[COLOR yellow]{0}[/COLOR] [I]({1})[/I]".format(blogname, blogid)
                label2 = about
                infolabel = {'video': {'plot': about}}
                litem = {'label': label, 'label2': label2, 'thumb': img, 'icon': img, 'url': blogurl, 'is_folder': True, 'info': infolabel, 'properties': {'blogix': str(blogix), 'mediaix': str(mediaix)}}
                litems.append(litem)
        return litems


    def getLiked(self):
        litems = []
        likedResults = None
        return litems

    def getFavs(self):
        litems = []
        return litems

    def old_getByTag(self, tagname=""):
        apiurl = self.BASEURL+"search_Site_Posts"
        apiurlblog = self.BASEURL+"get_Blog_Marquee"
        litems = []
        reqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,null,null,0,50,0,null,0,"#'+tagname+'",1,5,7,0,0,null,null]}'
        resp = urlquick.request(method="POST", url=apiurl, data=reqdata, headers=self.headerdict)
        results = resp.json().get('aResultSet', [])
        if len(results) == 0:
            return []
        else:
            items = results[4]['aRow']
            posts = results[3]['aRow']
            for item in items:
                label = ""
                label2 = ""
                posturl = ""                
                thumb = self.base32path(**item)
                postid = item['qwPostIx']
                blogid = item['dwBlogIx_From']
                blogreqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,'+str(blogid)+']}'
                resp = urlquick.request(method="POST", url=apiurlblog, data=blogreqdata, headers=self.headerdict)
                blogresult = resp.json().get('aResultSet', [])
                if len(blogresult) > 2:
                    blogitem = blogresult[2]['aRow'][0]
                    item.update(**blogitem)
                label=item['szTitle'] + " " + item.get('szBody', '')
                if item.has_key('szBlogId'):
                    label2 = "https://" + item['szBlogId'] + ".newtumbl.com/"
                    posturl = label2 + "post/" + str(postid)
                litems.append({'label': label, 'label2': label2,'thumb': thumb, 'icon': thumb, 'url': posturl})
        return litems


class Blog(dict):


    def __init__(self, **kwargs):
        """
        : attribute nWidth : float
        : attribute szTitle : string
        : attribute bIconShape : float
        : attribute qwMediaIxBanner : float
        : attribute dtCreated : string
        : attribute bMediaTypeIx : float
        : attribute nCountBlogMessage : float
        : attribute dtOrigin : string
        : attribute acLanguage : string
        : attribute bRatingBlogLinks : float
        : attribute dwUserIx : float
        : attribute nBirthYear : float
        : attribute qwMediaIxBackground : float
        : attribute dwAdmin : float
        : attribute qwMediaIx : float
        : attribute bRatingBlogs : float
        : attribute bLoggedIn : float
        : attribute nCountPostAsk : float
        : attribute szName : string
        : attribute nHeight : float
        : attribute nCountPostFlagged : float
        : attribute szBody : string
        : attribute bStatus : float
        : attribute bHide : float
        : attribute dwColorBackground : float
        : attribute bTerms : float
        : attribute acCountry : string
        : attribute bMinor : float
        : attribute nCountPostOutOfRange : float
        : attribute szLocation : string
        : attribute bNoIndex : float
        : attribute szBlogId : string
        : attribute bVerified : float
        : attribute bPrivate : float
        : attribute bActive : float
        : attribute bRatingIx : float
        : attribute nCountPostSubmit : float
        : attribute bPrimary : float
        : attribute bBlock : float
        : attribute dwBlogIx : float
        : attribute bOnline : float
        : attribute szDescription : string
        : attribute dwColorForeground : float
        : attribute qwMediaIxIcon : float
        : attribute szSub : string
        : attribute nSize : float
        : attribute bFollow : float
        : attribute dwIPAddressIx : float
        : attribute bTOS : float
        """
        super(Blog, self).__init__(**kwargs)
        self.nWidth = None
        self.szTitle = None
        self.bIconShape = None
        self.qwMediaIxBanner = None
        self.dtCreated = None
        self.bMediaTypeIx = None
        self.nCountBlogMessage = None
        self.dtOrigin = None
        self.acLanguage = None
        self.bRatingBlogLinks = None
        self.dwUserIx = None
        self.nBirthYear = None
        self.qwMediaIxBackground = None
        self.dwAdmin = None
        self.qwMediaIx = None
        self.bRatingBlogs = None
        self.bLoggedIn = None
        self.nCountPostAsk = None
        self.szName = None
        self.nHeight = None
        self.nCountPostFlagged = None
        self.szBody = None
        self.bStatus = None
        self.bHide = None
        self.dwColorBackground = None
        self.bTerms = None
        self.acCountry = None
        self.bMinor = None
        self.nCountPostOutOfRange = None
        self.szLocation = None
        self.bNoIndex = None
        self.szBlogId = None
        self.bVerified = None
        self.bPrivate = None
        self.bActive = None
        self.bRatingIx = None
        self.nCountPostSubmit = None
        self.bPrimary = None
        self.bAge = None
        self.bBlock = None
        self.dwBlogIx = None
        self.bGender = None
        self.bOnline = None
        self.szDescription = None
        self.dwColorForeground = None
        self.qwMediaIxIcon = None
        self.szSub = None
        self.nSize = None
        self.bFollow = None
        self.dwIPAddressIx = None
        self.bTOS = None
        for k, v in kwargs.iteritems():
            super.__setattr__(self, k, v)

class Post(dict):

    def __init__(self, **kwargs):
        """
        : attribute dtFavorite : string
        : attribute bFlag : float
        : attribute bPartTypeIx : float
        : attribute dwBlogIx : float
        : attribute qwMediaIxBackground : float
        : attribute bPrimary : float
        : attribute bStatus : float
        : attribute szURL : string
        : attribute dwColorForeground : float
        : attribute bTier : float
        : attribute bOrder : float
        : attribute qwMediaIx : float
        : attribute bState : float
        : attribute bFavorite : float
        : attribute dwUserIx : float
        : attribute dtLike : string
        : attribute bFollow : float
        : attribute dtCreated : string
        : attribute qwPostIxFrom : float
        : attribute bBlock : float
        : attribute bLike : float
        : attribute qwPostIx : float
        : attribute bPostTypeIx : float
        : attribute qwPostIxOrig : float
        : attribute nPartIz : float
        : attribute szSub : string
        : attribute bPrivate : float
        : attribute szTitle : string
        : attribute bMediaTypeIx : float
        : attribute dwIPAddressIx : float
        : attribute szTag : string
        : attribute dtActive : string
        : attribute szBody : string
        : attribute dwBlogIxSubmit : float
        : attribute bRatingIx : float
        : attribute szDescription : string
        : attribute nHeight : float
        : attribute bIconShape : float
        : attribute szExternal : string
        : attribute dwBlogIxFrom : float
        : attribute nCountPost : float
        : attribute nSize : float
        : attribute dwBlogIxOrig : float
        : attribute dtScheduled : string
        : attribute nCountLike : float
        : attribute dwChecksum : float
        : attribute bNoIndex : float
        : attribute szSource : string
        : attribute nWidth : float
        : attribute qwMediaIxBanner : float
        : attribute bHide : float
        : attribute nCountComment : float
        : attribute qwMediaIxIcon : float
        : attribute szBlogId : string
        : attribute dtOrigin : string
        : attribute dwColorBackground : float
        """
        super(Post, self).__init__(**kwargs)
        self.dtFavorite = None
        self.bFlag = None
        self.bPartTypeIx = None
        self.dwBlogIx = None
        self.qwMediaIxBackground = None
        self.bPrimary = None
        self.bStatus = None
        self.szURL = None
        self.dtDeleted = None
        self.dwColorForeground = None
        self.bTier = None
        self.bOrder = None
        self.qwMediaIx = None
        self.bState = None
        self.bFavorite = None
        self.dwUserIx = None
        self.dtLike = None
        self.bFollow = None
        self.dtModified = None
        self.dtCreated = None
        self.qwPostIxFrom = None
        self.bBlock = None
        self.bLike = None
        self.qwPostIx = None
        self.bPostTypeIx = None
        self.qwPostIxOrig = None
        self.nPartIz = None
        self.szSub = None
        self.bPrivate = None
        self.szTitle = None
        self.bMediaTypeIx = None
        self.dwIPAddressIx = None
        self.szTag = None
        self.dtActive = None
        self.szBody = None
        self.dwBlogIxSubmit = None
        self.bRatingIx = None
        self.szDescription = None
        self.nHeight = None
        self.bIconShape = None
        self.szExternal = None
        self.dwBlogIxFrom = None
        self.nCountPost = None
        self.nSize = None
        self.dwBlogIxOrig = None
        self.dtScheduled = None
        self.nCountLike = None
        self.dwChecksum = None
        self.bNoIndex = None
        self.szSource = None
        self.nWidth = None
        self.qwMediaIxBanner = None
        self.bHide = None
        self.nCountComment = None
        self.qwMediaIxIcon = None
        self.szBlogId = None
        self.dtFlag = None
        self.dtOrigin = None
        self.dwColorBackground = None
        for k, v in kwargs.iteritems():
            super.__setattr__(self, k, v)
