class BlogItem(object):

    def _init__(self):
        """
        : attribute bPrimary : float
        : attribute dwBlogIx : float
        : attribute bStatus : float
        : attribute qwMediaIxIcon : float
        : attribute qwMediaIxBackground : float
        : attribute bHide : float
        : attribute bPrivate : float
        : attribute bRatingIx : float
        : attribute szTitle : string
        : attribute bFollow : float
        : attribute szBlogId : string
        : attribute qwMediaIxBanner : float
        : attribute szDescription : string
        : attribute bIconShape : float
        : attribute dwColorForeground : float
        : attribute bBlock : float
        : attribute dtCreated : string
        : attribute dwUserIx : float
        : attribute dwColorBackground : float
        : attribute bNoIndex : float
        """
        self.bPrimary = None
        self.dwBlogIx = None
        self.bStatus = None
        self.qwMediaIxIcon = None
        self.qwMediaIxBackground = None
        self.bHide = None
        self.bPrivate = None
        self.bRatingIx = None
        self.szTitle = None
        self.bFollow = None
        self.szBlogId = None
        self.qwMediaIxBanner = None
        self.szDescription = None
        self.bIconShape = None
        self.dwColorForeground = None
        self.bBlock = None
        self.dtCreated = None
        self.dwUserIx = None
        self.dwColorBackground = None
        self.bNoIndex = None

