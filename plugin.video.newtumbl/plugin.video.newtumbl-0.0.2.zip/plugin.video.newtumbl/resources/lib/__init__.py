from . import newtumbl, simpleplugin
try:
    from . import urlquick
    Get = urlquick.get
except:
    Get = None
Plugin = simpleplugin.Plugin
