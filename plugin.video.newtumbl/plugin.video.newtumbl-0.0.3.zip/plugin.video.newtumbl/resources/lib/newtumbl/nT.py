import urlquick
import json
import hashlib
import re
import os
from collections import namedtuple
#from .. import urlquick

class AField(object):

    def __init__(self, **kwargs):
        """
        : attribute o_min : string
        : attribute o_max : string
        : attribute s_name : string
        : attribute s_type : string
        : attribute b_numeric : bool
        """
        self.oMin = kwargs.get('oMin', '')
        self.oMax = kwargs.get('oMax', '')
        self.sName = kwargs.get('sName', '')
        self.sType = kwargs.get('sType', '')
        self.bNumeric = kwargs.get('oMin', False)


class Results(dict):

    def __init__(self, **kwargs):
        super(Results, self).__init__(**kwargs)
        self.aResultSet = []
        self.nResult = kwargs.get('nResult', '0')


class AResultSet(object):

    def __init__(self, t):
        """
        : attribute a_field : array
        : attribute a_row : array
        : attribute n_total_rows : float
        """
        if type is None:
            self.a_field = []
            self.a_row = []
        else:
            if isinstance(type, RowBlog):
                for row in rows:
                    self.a_row.append(RowBlog(**row))
            self.a_field = Fields(fields)
        self.n_total_rows = total


class Field(object):

    def __init__(self, min="", max="", name="", type="", numeric=False):
        """
        : attribute o_min : string
        : attribute o_max : string
        : attribute s_name : string
        : attribute s_type : string
        : attribute b_numeric : bool
        """
        self.o_min = min
        self.o_max = max
        self.s_name = name
        self.s_type = type
        self.b_numeric = numeric


class Fields(list):

    def __init__(self, afields=[]):
        super(Fields, self).__init__()
        for field in afields:
            assert isinstance(field, AField)
            self.append(AField(min=field.o_min, max=field.o_max, name=field.s_name, type=field.s_type, numeric=field.b_numeric))


class RowTag(object):

    def __init__(self):
        """
        : attribute dt_created : string
        : attribute dt_origin : string
        : attribute n_count_tag_hide : float
        : attribute dw_tag_ix_dst : float
        : attribute n_count_blog_hide : float
        : attribute dw_user_ix : float
        : attribute n_count_blog_follow : float
        : attribute n_count_tag_follow : float
        : attribute sz_tag_id_dst : string
        """
        self.dt_created = None
        self.dt_origin = None
        self.n_count_tag_hide = None
        self.b_order = None
        self.dw_tag_ix_dst = None
        self.n_count_blog_hide = None
        self.dw_user_ix = None
        self.n_count_blog_follow = None
        self.n_count_tag_follow = None
        self.sz_tag_id = None
        self.dw_tag_ix = None
        self.sz_tag_id_dst = None


class RowBlog(object):

    def __init__(self):
        """
        : attribute n_width : float
        : attribute sz_title : string
        : attribute b_icon_shape : float
        : attribute qw_media_ix_banner : float
        : attribute dt_created : string
        : attribute b_media_type_ix : float
        : attribute n_count_blog_message : float
        : attribute dt_origin : string
        : attribute ac_language : string
        : attribute b_rating_blog_links : float
        : attribute dw_user_ix : float
        : attribute n_birth_year : float
        : attribute qw_media_ix_background : float
        : attribute dw_admin : float
        : attribute qw_media_ix : float
        : attribute b_rating_blogs : float
        : attribute b_logged_in : float
        : attribute n_count_post_ask : float
        : attribute sz_name : string
        : attribute n_height : float
        : attribute n_count_post_flagged : float
        : attribute sz_body : string
        : attribute b_status : float
        : attribute b_hide : float
        : attribute dw_color_background : float
        : attribute b_terms : float
        : attribute ac_country : string
        : attribute b_minor : float
        : attribute n_count_post_out_of_range : float
        : attribute sz_location : string
        : attribute b_no_index : float
        : attribute sz_blog_id : string
        : attribute b_verified : float
        : attribute b_private : float
        : attribute b_active : float
        : attribute b_rating_ix : float
        : attribute n_count_post_submit : float
        : attribute b_primary : float
        : attribute b_block : float
        : attribute dw_blog_ix : float
        : attribute b_online : float
        : attribute sz_description : string
        : attribute dw_color_foreground : float
        : attribute qw_media_ix_icon : float
        : attribute sz_sub : string
        : attribute n_size : float
        : attribute b_follow : float
        : attribute dw_i_p_address_ix : float
        : attribute b_t_o_s : float
        """
        self.n_width = None
        self.sz_title = None
        self.b_icon_shape = None
        self.qw_media_ix_banner = None
        self.dt_created = None
        self.b_media_type_ix = None
        self.n_count_blog_message = None
        self.dt_origin = None
        self.ac_language = None
        self.b_rating_blog_links = None
        self.dw_user_ix = None
        self.n_birth_year = None
        self.qw_media_ix_background = None
        self.dw_admin = None
        self.qw_media_ix = None
        self.b_rating_blogs = None
        self.b_logged_in = None
        self.n_count_post_ask = None
        self.sz_name = None
        self.n_height = None
        self.n_count_post_flagged = None
        self.sz_body = None
        self.b_status = None
        self.b_hide = None
        self.dw_color_background = None
        self.b_terms = None
        self.ac_country = None
        self.b_minor = None
        self.n_count_post_out_of_range = None
        self.sz_location = None
        self.b_no_index = None
        self.sz_blog_id = None
        self.b_verified = None
        self.b_private = None
        self.b_active = None
        self.b_rating_ix = None
        self.n_count_post_submit = None
        self.b_primary = None
        self.b_age = None
        self.b_block = None
        self.dw_blog_ix = None
        self.b_gender = None
        self.b_online = None
        self.sz_description = None
        self.dw_color_foreground = None
        self.qw_media_ix_icon = None
        self.sz_sub = None
        self.n_size = None
        self.b_follow = None
        self.dw_i_p_address_ix = None
        self.b_t_o_s = None


class RowPost(object):

    def __init__(self):
        """
        : attribute b_flag : float
        : attribute b_part_type_ix : float
        : attribute dw_blog_ix : float
        : attribute qw_media_ix_background : float
        : attribute b_primary : float
        : attribute b_status : float
        : attribute sz_u_r_l : string
        : attribute dw_color_foreground : float
        : attribute b_tier : float
        : attribute b_order : float
        : attribute qw_media_ix : float
        : attribute b_state : float
        : attribute b_favorite : float
        : attribute dw_user_ix : float
        : attribute b_follow : float
        : attribute dt_created : string
        : attribute qw_post_ix_from : float
        : attribute b_block : float
        : attribute b_like : float
        : attribute qw_post_ix : float
        : attribute b_post_type_ix : float
        : attribute qw_post_ix_orig : float
        : attribute n_part_iz : float
        : attribute sz_sub : string
        : attribute b_private : float
        : attribute sz_title : string
        : attribute b_media_type_ix : float
        : attribute dw_i_p_address_ix : float
        : attribute sz_tag : string
        : attribute dt_active : string
        : attribute sz_body : string
        : attribute dw_blog_ix_submit : float
        : attribute b_rating_ix : float
        : attribute sz_description : string
        : attribute n_height : float
        : attribute b_icon_shape : float
        : attribute sz_external : string
        : attribute dw_blog_ix_from : float
        : attribute n_count_post : float
        : attribute n_size : float
        : attribute dw_blog_ix_orig : float
        : attribute dt_scheduled : string
        : attribute n_count_like : float
        : attribute dw_checksum : float
        : attribute b_no_index : float
        : attribute sz_source : string
        : attribute n_width : float
        : attribute qw_media_ix_banner : float
        : attribute b_hide : float
        : attribute n_count_comment : float
        : attribute qw_media_ix_icon : float
        : attribute sz_blog_id : string
        : attribute dt_origin : string
        : attribute dw_color_background : float
        """
        self.dt_favorite = None
        self.b_flag = None
        self.b_part_type_ix = None
        self.dw_blog_ix = None
        self.qw_media_ix_background = None
        self.b_primary = None
        self.b_status = None
        self.sz_u_r_l = None
        self.dt_deleted = None
        self.dw_color_foreground = None
        self.b_tier = None
        self.b_order = None
        self.qw_media_ix = None
        self.b_state = None
        self.b_favorite = None
        self.dw_user_ix = None
        self.dt_like = None
        self.b_follow = None
        self.dt_modified = None
        self.dt_created = None
        self.qw_post_ix_from = None
        self.b_block = None
        self.b_like = None
        self.qw_post_ix = None
        self.b_post_type_ix = None
        self.qw_post_ix_orig = None
        self.n_part_iz = None
        self.sz_sub = None
        self.b_private = None
        self.sz_title = None
        self.b_media_type_ix = None
        self.dw_i_p_address_ix = None
        self.sz_tag = None
        self.dt_active = None
        self.sz_body = None
        self.dw_blog_ix_submit = None
        self.b_rating_ix = None
        self.sz_description = None
        self.n_height = None
        self.b_icon_shape = None
        self.sz_external = None
        self.dw_blog_ix_from = None
        self.n_count_post = None
        self.n_size = None
        self.dw_blog_ix_orig = None
        self.dt_scheduled = None
        self.n_count_like = None
        self.dw_checksum = None
        self.b_no_index = None
        self.sz_source = None
        self.n_width = None
        self.qw_media_ix_banner = None
        self.b_hide = None
        self.n_count_comment = None
        self.qw_media_ix_icon = None
        self.sz_blog_id = None
        self.dt_flag = None
        self.dt_origin = None
        self.dw_color_background = None


class RowBlogPost(object):

    def __init__(self):
        """
        : attribute n_size : float
        : attribute b_primary : float
        : attribute dw_blog_ix : float
        : attribute b_media_type_ix : float
        : attribute n_width : float
        : attribute sz_sub : string
        : attribute qw_media_ix_icon : float
        : attribute sz_body : string
        : attribute b_status : float
        : attribute qw_media_ix_background : float
        : attribute b_hide : float
        : attribute b_private : float
        : attribute b_rating_ix : float
        : attribute sz_title : string
        : attribute sz_blog_id : string
        : attribute qw_media_ix : float
        : attribute b_follow : float
        : attribute sz_description : string
        : attribute b_icon_shape : float
        : attribute qw_media_ix_banner : float
        : attribute dw_color_foreground : float
        : attribute dw_user_ix : float
        : attribute dt_created : string
        : attribute b_block : float
        : attribute n_height : float
        : attribute dw_i_p_address_ix : float
        : attribute dt_origin : string
        : attribute dw_color_background : float
        : attribute b_no_index : float
        """
        self.n_size = None
        self.b_primary = None
        self.dw_blog_ix = None
        self.b_media_type_ix = None
        self.n_width = None
        self.sz_sub = None
        self.qw_media_ix_icon = None
        self.sz_body = None
        self.b_status = None
        self.qw_media_ix_background = None
        self.b_hide = None
        self.b_private = None
        self.b_rating_ix = None
        self.sz_title = None
        self.sz_blog_id = None
        self.qw_media_ix = None
        self.b_follow = None
        self.sz_description = None
        self.b_icon_shape = None
        self.qw_media_ix_banner = None
        self.dw_color_foreground = None
        self.dw_user_ix = None
        self.dt_created = None
        self.b_block = None
        self.n_height = None
        self.dw_i_p_address_ix = None
        self.dt_origin = None
        self.dw_color_background = None
        self.b_no_index = None


class RowFave(object):

    def __init__(self):
        """
        : attribute dt_favorite : string
        : attribute b_flag : float
        : attribute b_part_type_ix : float
        : attribute dw_blog_ix : float
        : attribute qw_media_ix_background : float
        : attribute b_primary : float
        : attribute b_status : float
        : attribute sz_u_r_l : string
        : attribute dw_color_foreground : float
        : attribute b_tier : float
        : attribute b_order : float
        : attribute qw_media_ix : float
        : attribute b_state : float
        : attribute b_favorite : float
        : attribute dw_user_ix : float
        : attribute b_follow : float
        : attribute dt_modified : string
        : attribute dt_created : string
        : attribute qw_post_ix_from : float
        : attribute b_block : float
        : attribute b_like : float
        : attribute qw_post_ix : float
        : attribute b_post_type_ix : float
        : attribute qw_post_ix_orig : float
        : attribute n_part_iz : float
        : attribute sz_sub : string
        : attribute b_private : float
        : attribute sz_title : string
        : attribute b_media_type_ix : float
        : attribute dw_i_p_address_ix : float
        : attribute sz_tag : string
        : attribute dt_active : string
        : attribute sz_body : string
        : attribute dw_blog_ix_submit : float
        : attribute b_rating_ix : float
        : attribute sz_description : string
        : attribute n_height : float
        : attribute b_icon_shape : float
        : attribute sz_external : string
        : attribute dw_blog_ix_from : float
        : attribute n_count_post : float
        : attribute n_size : float
        : attribute dw_blog_ix_orig : float
        : attribute dt_scheduled : string
        : attribute n_count_like : float
        : attribute dw_checksum : float
        : attribute b_no_index : float
        : attribute sz_source : string
        : attribute n_width : float
        : attribute qw_media_ix_banner : float
        : attribute b_hide : float
        : attribute n_count_comment : float
        : attribute qw_media_ix_icon : float
        : attribute sz_blog_id : string
        : attribute dt_origin : string
        : attribute dw_color_background : float
        """
        self.dt_favorite = None
        self.b_flag = None
        self.b_part_type_ix = None
        self.dw_blog_ix = None
        self.qw_media_ix_background = None
        self.b_primary = None
        self.b_status = None
        self.sz_u_r_l = None
        self.dt_deleted = None
        self.dw_color_foreground = None
        self.b_tier = None
        self.b_order = None
        self.qw_media_ix = None
        self.b_state = None
        self.b_favorite = None
        self.dw_user_ix = None
        self.dt_like = None
        self.b_follow = None
        self.dt_modified = None
        self.dt_created = None
        self.qw_post_ix_from = None
        self.b_block = None
        self.b_like = None
        self.qw_post_ix = None
        self.b_post_type_ix = None
        self.qw_post_ix_orig = None
        self.n_part_iz = None
        self.sz_sub = None
        self.b_private = None
        self.sz_title = None
        self.b_media_type_ix = None
        self.dw_i_p_address_ix = None
        self.sz_tag = None
        self.dt_active = None
        self.sz_body = None
        self.dw_blog_ix_submit = None
        self.b_rating_ix = None
        self.sz_description = None
        self.n_height = None
        self.b_icon_shape = None
        self.sz_external = None
        self.dw_blog_ix_from = None
        self.n_count_post = None
        self.n_size = None
        self.dw_blog_ix_orig = None
        self.dt_scheduled = None
        self.n_count_like = None
        self.dw_checksum = None
        self.b_no_index = None
        self.sz_source = None
        self.n_width = None
        self.qw_media_ix_banner = None
        self.b_hide = None
        self.n_count_comment = None
        self.qw_media_ix_icon = None
        self.sz_blog_id = None
        self.dt_flag = None
        self.dt_origin = None
        self.dw_color_background = None


class RowLiked(object):

    def __init__(self):
        """
        : attribute dt_favorite : string
        : attribute b_flag : float
        : attribute b_part_type_ix : float
        : attribute dw_blog_ix : float
        : attribute qw_media_ix_background : float
        : attribute b_primary : float
        : attribute b_status : float
        : attribute sz_u_r_l : string
        : attribute dw_color_foreground : float
        : attribute b_tier : float
        : attribute b_order : float
        : attribute qw_media_ix : float
        : attribute b_state : float
        : attribute b_favorite : float
        : attribute dw_user_ix : float
        : attribute dt_like : string
        : attribute b_follow : float
        : attribute dt_created : string
        : attribute qw_post_ix_from : float
        : attribute b_block : float
        : attribute b_like : float
        : attribute qw_post_ix : float
        : attribute b_post_type_ix : float
        : attribute qw_post_ix_orig : float
        : attribute n_part_iz : float
        : attribute sz_sub : string
        : attribute b_private : float
        : attribute sz_title : string
        : attribute b_media_type_ix : float
        : attribute dw_i_p_address_ix : float
        : attribute sz_tag : string
        : attribute dt_active : string
        : attribute sz_body : string
        : attribute dw_blog_ix_submit : float
        : attribute b_rating_ix : float
        : attribute sz_description : string
        : attribute n_height : float
        : attribute b_icon_shape : float
        : attribute sz_external : string
        : attribute dw_blog_ix_from : float
        : attribute n_count_post : float
        : attribute n_size : float
        : attribute dw_blog_ix_orig : float
        : attribute dt_scheduled : string
        : attribute n_count_like : float
        : attribute dw_checksum : float
        : attribute b_no_index : float
        : attribute sz_source : string
        : attribute n_width : float
        : attribute qw_media_ix_banner : float
        : attribute b_hide : float
        : attribute n_count_comment : float
        : attribute qw_media_ix_icon : float
        : attribute sz_blog_id : string
        : attribute dt_origin : string
        : attribute dw_color_background : float
        """
        self.dt_favorite = None
        self.b_flag = None
        self.b_part_type_ix = None
        self.dw_blog_ix = None
        self.qw_media_ix_background = None
        self.b_primary = None
        self.b_status = None
        self.sz_u_r_l = None
        self.dt_deleted = None
        self.dw_color_foreground = None
        self.b_tier = None
        self.b_order = None
        self.qw_media_ix = None
        self.b_state = None
        self.b_favorite = None
        self.dw_user_ix = None
        self.dt_like = None
        self.b_follow = None
        self.dt_modified = None
        self.dt_created = None
        self.qw_post_ix_from = None
        self.b_block = None
        self.b_like = None
        self.qw_post_ix = None
        self.b_post_type_ix = None
        self.qw_post_ix_orig = None
        self.n_part_iz = None
        self.sz_sub = None
        self.b_private = None
        self.sz_title = None
        self.b_media_type_ix = None
        self.dw_i_p_address_ix = None
        self.sz_tag = None
        self.dt_active = None
        self.sz_body = None
        self.dw_blog_ix_submit = None
        self.b_rating_ix = None
        self.sz_description = None
        self.n_height = None
        self.b_icon_shape = None
        self.sz_external = None
        self.dw_blog_ix_from = None
        self.n_count_post = None
        self.n_size = None
        self.dw_blog_ix_orig = None
        self.dt_scheduled = None
        self.n_count_like = None
        self.dw_checksum = None
        self.b_no_index = None
        self.sz_source = None
        self.n_width = None
        self.qw_media_ix_banner = None
        self.b_hide = None
        self.n_count_comment = None
        self.qw_media_ix_icon = None
        self.sz_blog_id = None
        self.dt_flag = None
        self.dt_origin = None
        self.dw_color_background = None

media = namedtuple("media", ['VIDEO', 'PHOTO', 'ALL'])(*[7,5,0])

class newTumbl():
    '''
    API Methods
    ["get_Blog_Marquee",
    "search_Site_Blogs",
    "search_Site_Posts",
    "search_Dash_Activity",
    "search_Dash_Posts",
    "search_Blog_Posts",
    "search_User_Posts_Like",
    "search_User_Posts_Favorite",
    "search_Post_Notes"]
    '''
    BASEURL = "https://api-ro.newtumbl.com/sp/NewTumbl/"
    headerdict = {'Host': 'api-ro.newtumbl.com',
                  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:69.0) Gecko/20100101 Firefox/69.0',
                  'Accept': '*/*', 'Accept-Language': 'en-US,en;q=0.5', 'Accept-Encoding': 'gzip, deflate, br',
                  'Referer': 'https://newtumbl.com/tagged/twink',
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'Pragma': 'no-cache',
                  'Cache-Control': 'no-cache', 'Origin': 'https://newtumbl.com'}

    def __init__(self):
        self.results = None

    def getLiked(self):
        litems = []
        likedResults = None
        return litems

    def getFavs(self):
        litems = []
        return litems

    def getBlogPosts(self, blogid=0, filterby=media.VIDEO, filterdate=""):
        apiurl = self.BASEURL +  "search_Site_Posts"
        # filterdate = "2019-07-31T23:00:00.0000000"
        reqparams = reqparams = {"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",blogid,None,None,0,50,0,filterdate,0,"",1,5,filterby,0,0,None,None]}
        resp = urlquick.request(method="POST", url=apiurl,data={'json': json.dumps(reqparams)})
        results = resp.json()


    def getBlog(self, blogid=0):
        apiurlblog = self.BASEURL + "get_Blog_Marquee"
        blogreqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,' + str(blogid) + ']}'
        resp = urlquick.request(method="POST", url=apiurlblog, data=blogreqdata, headers=self.headerdict)
        blogresult = resp.json().get('aResultSet', [])
        if len(blogresult) > 1:
            blogdict = blogresult[2].get('aRow', [])[0]
            ablog = Blog(**blogdict)
            return ablog
        else:
            return None


    def getVidsTag(self, tagname=""):
        apiurl = self.BASEURL+"search_Site_Posts"
        apiurlblog = self.BASEURL+"get_Blog_Marquee"
        litems = []
        reqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,null,null,0,50,0,null,0,"#'+tagname+'",1,5,7,0,0,null,null]}'
        resp = urlquick.request(method="POST", url=apiurl, data=reqdata, headers=self.headerdict)
        results = resp.json().get('aResultSet', [])
        if len(results) == 0:
            return []
        else:
            items = results[4]['aRow']
            posts = results[3]['aRow']
            for item in items:
                label = ""
                label2 = ""
                posturl = ""
                blogname = ""
                thumb = self.base32path(**item)
                postid = item['qwPostIx']
                blogid = item['dwBlogIx_From']
                ablog = self.getBlog(blogid)
                if ablog is not None:
                    item.update(ablog.__dict__)
                    blogname = ablog.szBlogId
                label = item['szTitle'] + " " + item.get('szBody', '')
                if len(blogname) > 0:
                    label2 = "https://" + blogname + ".newtumbl.com/"
                    posturl = label2 + "post/" + str(postid)
                litems.append({'label': label, 'label2': label2, 'thumb': thumb, 'icon': thumb, 'url': posturl, 'is_folder': False, 'is_playable': True})
        return litems



    def getByTag(self, tagname=""):
        apiurl = self.BASEURL+"search_Site_Posts"
        apiurlblog = self.BASEURL+"get_Blog_Marquee"
        litems = []
        reqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,null,null,0,50,0,null,0,"#'+tagname+'",1,5,7,0,0,null,null]}'
        resp = urlquick.request(method="POST", url=apiurl, data=reqdata, headers=self.headerdict)
        results = resp.json().get('aResultSet', [])
        if len(results) == 0:
            return []
        else:
            items = results[4]['aRow']
            posts = results[3]['aRow']
            for item in items:
                label = ""
                label2 = ""
                posturl = ""                
                thumb = self.base32path(**item)
                postid = item['qwPostIx']
                blogid = item['dwBlogIx_From']
                blogreqdata = 'json={"Params":["[{IPADDRESS}]","FzCWMJIw6mi8gl6pU6LgpGMcncAg75JIqnqBsiGK2tytG76I",391932,'+str(blogid)+']}'
                resp = urlquick.request(method="POST", url=apiurlblog, data=blogreqdata, headers=self.headerdict)
                blogresult = resp.json().get('aResultSet', [])
                if len(blogresult) > 2:
                    blogitem = blogresult[2]['aRow'][0]
                    item.update(**blogitem)
                label=item['szTitle'] + " " + item.get('szBody', '')
                if item.has_key('szBlogId'):
                    label2 = "https://" + item['szBlogId'] + ".newtumbl.com/"
                    posturl = label2 + "post/" + str(postid)
                litems.append({'label': label, 'label2': label2,'thumb': thumb, 'icon': thumb, 'url': posturl})
        return litems


    def base32path(self, imgpath="", **kwargs):
        '''
        Parameters: 
        BlogID
        PostID
        PartID
        MediaID
        or imgpath in form of imgpath="/blogid/postid/partid/mediaid" or as much as imgpath="https://dn0.newtumbl.com/img/blogid/postid/partid/mediaid/nT_"
        blogid=265936 postid=6180659 partid=1 mediaID=9257871
        Returns:
        URL to image in format of:
        https://dn0.newtumbl.com/img/{BlogID}/{PostID}/{PartID}/{MediaID}/nT_{Base32(SHA256("/{blogid}/{postid}/{partid}/{mediaid}/nT_"))}.jpg
        Example: https://dn0.newtumbl.com/img/265936/6180659/1/9257871/nT_bjkrnkq6tjk8j62a05hrzks0.jpg
        '''
        ids = dict(blogid=0, postid=0, partid=0, mediaid=0)
        ids.update(**kwargs)
        if kwargs.has_key('qwMediaIx'):
            ids = {'mediaid': ids['qwMediaIx'], 'partid': ids['nPartIz'], 'postid': ids['qwPostIx'], 'blogid': ids['dwBlogIx_From']}        
            #ids = {'mediaid': kwargs['qwMediaIx'], 'partid': kwargs['nPartIz'], 'postid': kwargs['qwPostIx'], 'blogid': kwargs['dwBlogIx_From']}        
        sMap = "abcdefghijknpqrstuvxyz0123456789"
        sOutput = ""
        i = -1
        b = 0
        c = 0
        d = None
        shalist = []
        abInput = []        
        BASEIMGURL = "https://dn0.newtumbl.com/img"
        if imgpath is not "":
            try:
                if imgpath.startswith('http') or imgpath.find('img/') != -1:
                    ids['blogid'],ids['postid'],ids['partid'],ids['mediaid'] = imgpath.split('img/',1)[-1].rpartition('/nT_')[0].split('/',4)
                else:
                    if not imgpath.startswith('/'):
                        imgpath = "/" + imgpath
                    if not imgpath.endswith('/') and not imgpath.endswith('nT_'):
                        imgpath = imgpath + '/nT_'
                    if not imgpath.endswith('nT_'):
                        imgpath = imgpath + 'nT_'
                    imgpath = imgpath.replace('/nT_', '').replace('/nT','')
                    ids['blogid'],ids['postid'],ids['partid'],ids['mediaid'] = imgpath.partition('/')[-1].strip('/').split('/',4)
            except:
                return None    
        sPath = "/" + str(ids['blogid']) + "/" + str(ids['postid']) + "/" + str(ids['partid']) + "/" + str(ids['mediaid']) + "/nT_"
        sha = hashlib.sha256(sPath)
        hexdigest = sha.hexdigest()
        for t in range(0,len(hexdigest),2): shalist.append(hexdigest[t:t+2])
        for num in shalist: abInput.append(int(num,16))
        # Based on Base32 Javascript method from newtumbl original function runs on a WordArray of 16 pairs of HEX digits returned from SHA256
        # https://newtumbl.com/v1.6.22/js/common.js
        while (i < len(abInput) or b > 0):
            if b < 5:
                i = i+1
                if i < len(abInput):
                    c = (c << 8) + int(abInput[i])
                    b += 8
            d = c % 32
            c = c >> 5
            b = b - 5
            sOutput += sMap[d]
        sOutput = sOutput[0:24]
        imgurl = BASEIMGURL + sPath + sOutput + ".jpg"
        return imgurl


class Blog(dict):


    def __init__(self, **kwargs):
        """
        : attribute nWidth : float
        : attribute szTitle : string
        : attribute bIconShape : float
        : attribute qwMediaIxBanner : float
        : attribute dtCreated : string
        : attribute bMediaTypeIx : float
        : attribute nCountBlogMessage : float
        : attribute dtOrigin : string
        : attribute acLanguage : string
        : attribute bRatingBlogLinks : float
        : attribute dwUserIx : float
        : attribute nBirthYear : float
        : attribute qwMediaIxBackground : float
        : attribute dwAdmin : float
        : attribute qwMediaIx : float
        : attribute bRatingBlogs : float
        : attribute bLoggedIn : float
        : attribute nCountPostAsk : float
        : attribute szName : string
        : attribute nHeight : float
        : attribute nCountPostFlagged : float
        : attribute szBody : string
        : attribute bStatus : float
        : attribute bHide : float
        : attribute dwColorBackground : float
        : attribute bTerms : float
        : attribute acCountry : string
        : attribute bMinor : float
        : attribute nCountPostOutOfRange : float
        : attribute szLocation : string
        : attribute bNoIndex : float
        : attribute szBlogId : string
        : attribute bVerified : float
        : attribute bPrivate : float
        : attribute bActive : float
        : attribute bRatingIx : float
        : attribute nCountPostSubmit : float
        : attribute bPrimary : float
        : attribute bBlock : float
        : attribute dwBlogIx : float
        : attribute bOnline : float
        : attribute szDescription : string
        : attribute dwColorForeground : float
        : attribute qwMediaIxIcon : float
        : attribute szSub : string
        : attribute nSize : float
        : attribute bFollow : float
        : attribute dwIPAddressIx : float
        : attribute bTOS : float
        """
        super(Blog, self).__init__(**kwargs)
        self.nWidth = None
        self.szTitle = None
        self.bIconShape = None
        self.qwMediaIxBanner = None
        self.dtCreated = None
        self.bMediaTypeIx = None
        self.nCountBlogMessage = None
        self.dtOrigin = None
        self.acLanguage = None
        self.bRatingBlogLinks = None
        self.dwUserIx = None
        self.nBirthYear = None
        self.qwMediaIxBackground = None
        self.dwAdmin = None
        self.qwMediaIx = None
        self.bRatingBlogs = None
        self.bLoggedIn = None
        self.nCountPostAsk = None
        self.szName = None
        self.nHeight = None
        self.nCountPostFlagged = None
        self.szBody = None
        self.bStatus = None
        self.bHide = None
        self.dwColorBackground = None
        self.bTerms = None
        self.acCountry = None
        self.bMinor = None
        self.nCountPostOutOfRange = None
        self.szLocation = None
        self.bNoIndex = None
        self.szBlogId = None
        self.bVerified = None
        self.bPrivate = None
        self.bActive = None
        self.bRatingIx = None
        self.nCountPostSubmit = None
        self.bPrimary = None
        self.bAge = None
        self.bBlock = None
        self.dwBlogIx = None
        self.bGender = None
        self.bOnline = None
        self.szDescription = None
        self.dwColorForeground = None
        self.qwMediaIxIcon = None
        self.szSub = None
        self.nSize = None
        self.bFollow = None
        self.dwIPAddressIx = None
        self.bTOS = None
        for k, v in kwargs.iteritems():
            super.__setattr__(self, k, v)

