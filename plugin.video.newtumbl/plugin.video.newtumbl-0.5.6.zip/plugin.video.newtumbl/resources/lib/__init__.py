from . import newtumbl, simpleplugin
try:
    from . import urlquick
except:
    pass
Plugin = simpleplugin.Plugin
