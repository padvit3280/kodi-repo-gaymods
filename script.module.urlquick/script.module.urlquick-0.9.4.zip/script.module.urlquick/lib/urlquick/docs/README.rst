.. image:: https://readthedocs.org/projects/urlquick/badge/?version=stable
    :target: http://urlquick.readthedocs.io/en/stable/?badge=stable

Please GOTO: http://urlquick.readthedocs.io/en/stable/?badge=stable
