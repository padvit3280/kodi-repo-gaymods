from . import wsovf, simpleplugin, urlquick
#Plugin = simpleplugin.Plugin
